import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { CurrentPageReference } from 'lightning/navigation';
import templatedata from '@salesforce/apex/locationSearch.templatedata_Get';
import createCandidateApplication from '@salesforce/apex/CandidateApplicationController.createCandidateApplication';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class NewTemplate extends NavigationMixin(LightningElement) {
    @track position;
    @track department;
    @track Experience;
    @track location;
    @track vacancy;
    @track ctc;
    @track Qualification;
    @track Responsibilities;
    @track skill;
    @track aboutUs;
    @track recordId;
    @track isShowModal = false;
    email = null;
    name = null;
    fileData;
    file;
    filename;
    base64;

    @api headerBackgroundColor;
    @api headerHeadingColor;
    @api headerSubHeadingColor;
    @api headerIconColor;
    @api mainPageTitleColor;
    @api mainPageSubTitleColor;

    @api buttonColor;
    @api buttonTextColor;
    @api buttonBorderColor;
    @api buttonColorOnHover;
    @api buttonTextColorOnHover;
    @api buttonBorderColorOnHover;
    

    connectedCallback() {

        // Add an event listener for the popstate event
        window.addEventListener('popstate', this.handlePopState.bind(this));
        // console.log('connectedCallback');

    }


    // --------------   Priview Button start   -------------- //


    disconnectedCallback() {
        // Remove the event listener when the component is removed
        window.removeEventListener('popstate', this.handlePopState.bind(this));
        // console.log('disconnectedCallback');

    }

    // Define the method to handle the popstate event
    handlePopState(event) {
        // Refresh the page when the system back button is clicked
        location.reload();
    }


    renderedCallback() {

        this.template
            .querySelector("Div")
            .style.setProperty("--my-headerBackgroundColor", this.headerBackgroundColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-headerHeadingColor", this.headerHeadingColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-headerSubHeadingColor", this.headerSubHeadingColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-headerIconColor", this.headerIconColor);



            this.template
            .querySelector("Div")
            .style.setProperty("--my-mainPageTitleColor", this.mainPageTitleColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-mainPageSubTitleColor", this.mainPageSubTitleColor);


            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonColor", this.buttonColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonTextColor", this.buttonTextColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonBorderColor", this.buttonBorderColor);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonColorOnHover", this.buttonColorOnHover);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonTextColorOnHover", this.buttonTextColorOnHover);

            this.template
            .querySelector("Div")
            .style.setProperty("--my-ButtonBorderColorOnHover", this.buttonBorderColorOnHover);
    }


    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.recordId = currentPageReference.state.c__divID;
            templatedata({ careerId: this.recordId })
                .then((result) => {
                    if (result && result.length > 0) {
                        const data = result[0];
                        this.position = data.Name;
                        this.department = data.Department__c;
                        this.Experience = data.Experience__c;
                        this.location = data.Location__c;
                        this.vacancy = data.No_of_Vacancy__c;
                        this.ctc = data.CTC_Slab__c;
                        this.Qualification = data.Qualification__c;
                        this.Responsibilities =
                            data.Key_Responsibilities__c;
                        this.skill = data.Required_Skill_Set__c;
                        this.aboutUs = data.What_you_will_love_about_us__c;
                    }
                })
                .catch((error) => {
                    console.error(JSON.stringify(error));
                });
        }
    }

    // showModalBox() {
    //     this.isShowModal = true;
    // }
    showModalBox(event) {
        this.selectedJobTitle = event.currentTarget.dataset.title;
        this.isShowModal = true;
    }
    
    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleFileChange(event) {
        this.file = event.target.files[0];
    }

    // handleSubmit() {
    //     let jsWrp = {
    //         name: this.name,
    //         email: this.email,
    //         fileName: this.filename,
    //         fileData: this.base64
    //     };
    //     createCandidateApplication({ wrp: jsWrp })
    //         .then((result) => {
    //             console.log('Record created successfully');
    //             this.hideModalBox();
    //         })
    //         .catch((error) => {
    //             console.error('Error creating record: ' + error.body.message);
    //             console.log('Record created successfully', JSON.stringify(error));
    //         });
    // }
    handleSubmit() {
        let jsWrp = {
            name: this.name,
            email: this.email,
            fileName: this.filename,
            fileData: this.base64,
            positionId: this.selectedJobTitle
        };
        createCandidateApplication({ wrp: jsWrp })
            .then(() => {
                this.hideModalBox();
                this.toast('Record created successfully');
            })
            .catch(error => {
                console.error('Error creating record: ' + error.body.message);
                this.toast('Error creating record');
            });
    }

    openfileUpload(event) {
        const file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = () => {
            var base64 = reader.result.split(',')[1];
            this.filename = file.name;
            this.base64 = base64;
        };
        reader.readAsDataURL(file);
    }

    toast(title) {
        const toastEvent = new ShowToastEvent({
            title,
            variant: 'success'
        });
        this.dispatchEvent(toastEvent);
    }
}