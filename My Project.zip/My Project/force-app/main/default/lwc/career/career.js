import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader'
import dropdown from '@salesforce/resourceUrl/dropdown';
import cssFile from '@salesforce/resourceUrl/careerCSS'; //Css file of Career component
import ZTWebsiteBootstrap from '@salesforce/resourceUrl/ZTWebsiteBootstrap'; //bootstrapFile import

import Objects_Type from "@salesforce/apex/locationSearch.f_Get_Types"; //fetch location data   
import Objects_Types from "@salesforce/apex/locationSearch.f_Get"; //fetch department data   
import career_data from "@salesforce/apex/locationSearch.Career_Get"; // fetch Career data

import { NavigationMixin } from 'lightning/navigation';

export default class Career extends NavigationMixin(LightningElement) {

    @api position;
    @api department;
    @api Experience;
    @api location;
    @api vacancy;
    @api ctc;
    @api Qualification;
    @api Responsibilities;
    @api skill;
    @api aboutUs;
    @api pagename;
    @track l_All_Types;
    @api positioncolor;
    @api txtcolor;
    @api hovercolor;
    @api cardtxtcolor;
    @api afterhovertxtcolor;
    @api bordercolor;
    @api posBgClr;
    
    @track All_Types;


    @track cityNameOptions = [];
    @track deptNameOptions = [];


    displayedTiles = [];

    // ????//////////////////////    new implimatations  start   /////////////////////////////////////////
    // ????//////////////////////   back button and refresh  start   /////////////////////////////////////////

    connectedCallback() {
        // Add an event listener for the popstate event
        window.addEventListener('popstate', this.handlePopState.bind(this));
        console.log('cnnectedCallbackCalled');  
    }

    disconnectedCallback() {
        // Remove the event listener when the component is removed
        window.removeEventListener('popstate', this.handlePopState.bind(this));
        console.log('DiscnnectedCallbackCalled');

    }

    // Define the method to handle the popstate event
    handlePopState(event) {
        // Refresh the page when the system back button is clicked
        location.reload();
    }


    // ????//////////////////////   back button and refresh  END   /////////////////////////////////////////

    // /////////////////////////    dropdown filter new start //////////////////////////////////////


    @wire(Objects_Type)
    wiredObjectsType({ error, data }) {
        if (data) {
            console.log('inside wiredObjectsType');
            this.cityNameOptions = [{ label: 'All Locations', value: 'All' }, ...data.map(ele => ({ label: ele.Location__c, value: ele.Location__c }))];
        } else if (error) {
            // Handle error
        }
    }

    @wire(Objects_Types)
    wiredObjectsTypes({ error, data }) {
        if (data) {
            console.log('inside wiredObjectsTypes');
            this.deptNameOptions = [{ label: 'All Department', value: 'All' }, ...data.map(ele => ({ label: ele.Department__c, value: ele.Department__c }))];
        } else if (error) {
            // Handle error
        }
    }

    get cityName() {
        return this.cityNameOptions;
    }

    get deptName() {
        return this.deptNameOptions;
    }



    handleLocationChange(event) {
        var location = event.target.value;
        var department = this.template.querySelector('.department').value;
        this.filterData(location, department);
    }

    handleDepartmentChange(event) {
        var department = event.target.value;
        var location = this.template.querySelector('.location').value;
        this.filterData(location, department);

    }

    // filterData(location, department) {
    //     const searchDiv = this.template.querySelector('.row');
    //     const cards = searchDiv.querySelectorAll('.col-6');

    //     for (let i = 0; i < cards.length; i++) {
    //         let card = cards[i];
    //         let cardLocation = card.querySelector('.cityicon').childNodes[0].nextSibling.childNodes[2].nodeValue.trim();
    //         let cardDepartment = card.className.toUpperCase();

    //         let locationMatch;
    //         let departmentMatch;

    //         if (location === 'All') {
    //             locationMatch = true;
    //         } else {
    //             locationMatch = location ? cardLocation.toUpperCase().trim() === location.toUpperCase().trim() : true;
    //         }
    //         if (department === 'All') {
    //             departmentMatch = true;
    //         } else {
    //             departmentMatch = department ? cardDepartment.includes(department.toUpperCase().trim()) : true;
    //         }

    //         if (locationMatch && departmentMatch) {
    //             card.style.display = "";
    //         } else {
    //             card.style.display = "none";
    //         }
    //     }
    // }
    filterData(location, department) {
        const searchDiv = this.template.querySelector('.row');
        const cards = searchDiv.querySelectorAll('.col-6');

        for (let i = 0; i < cards.length; i++) {
            let card = cards[i];
            let cardLocation = card.querySelector('.cityicon').childNodes[0].nextSibling.childNodes[2].nodeValue.trim();
            let cardDepartment = card.className.toUpperCase();

            let locationMatch;
            let departmentMatch;

            if (location === 'All') {
                locationMatch = true;
            } else {
                locationMatch = location ? cardLocation.toUpperCase().trim() === location.toUpperCase().trim() : true;
            }
            if (department === 'All') {
                departmentMatch = true;
            } else {
                departmentMatch = department ? cardDepartment.includes(department.toUpperCase().trim()) : true;
            }

            if (locationMatch && departmentMatch) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        }
    }

    // /////////////////////////    dropdown filter new END //////////////////////////////////////

    //--------------  Search bar funcationlity Start --------------//

    // searchPosition() {

    //     const search = this.template.querySelector('.filter').value?.trim().toUpperCase();
    //     const location = this.template.querySelector('.location').value?.trim().toUpperCase();
    //     const department = this.template.querySelector('.department').value?.trim().toUpperCase();

    //     const searchDiv = this.template.querySelector('.row');
    //     const cards = searchDiv.querySelectorAll('.col-6');

    //     for (let i = 0; i < cards.length; i++) {
    //         let cardDept = cards[i].className.toUpperCase().trim();
    //         let cardLoc = cards[i].querySelector('.cityicon').innerText.trim().toUpperCase();
    //         let title = cards[i].querySelector('.positionName').innerHTML.toUpperCase();


    //         // Check if the search matches the title
    //         let titleMatch = title.includes(search);
    //         // Check if the location matches the selected location
    //         let locationMatch = location ? location == cardLoc : true;
    //         // Check if the department matches the selected department
    //         let departmentMatch = department ? cardDept.includes(department) : true;

    //         // Display the card if any of the search criteria match
    //         if (titleMatch && locationMatch && departmentMatch) {
    //             cards[i].style.display = "";
    //         } else {
    //             cards[i].style.display = "none";
    //         }
    //     }
    // }
    searchPosition() {
        const search = this.template.querySelector('.filter').value?.trim().toUpperCase();
        const location = this.template.querySelector('.location').value?.trim().toUpperCase();
        const department = this.template.querySelector('.department').value?.trim().toUpperCase();
    
        const searchDiv = this.template.querySelector('.row');
        const cards = searchDiv.querySelectorAll('.col-6');
        let resultsFound = false;
    
        for (let i = 0; i < cards.length; i++) {
            let cardDept = cards[i].className.toUpperCase().trim();
            let cardLoc = cards[i].querySelector('.cityicon').innerText.trim().toUpperCase();
            let title = cards[i].querySelector('.positionName').innerHTML.toUpperCase();
    
            // Check if the search matches the title
            let titleMatch = title.includes(search);
            // Check if the location matches the selected location, is "All Locations", or if no location is selected
            let locationMatch = !location || location === 'ALL' || location === cardLoc;
            // Check if the department matches the selected department, is "All Department", or if no department is selected
            let departmentMatch = !department || department === 'ALL' || cardDept.includes(department);
    
            // Display the card if any of the search criteria match
            if (titleMatch && locationMatch && departmentMatch) {
                cards[i].style.display = "";
                resultsFound = true; // Set to true if any matching card is found
            } else {
                cards[i].style.display = "none";
            }
        }
    
        // Remove all existing no-result messages
        const existingMessages = searchDiv.querySelectorAll('.no-results-message');
        existingMessages.forEach(message => message.remove());
    
        // Show message if no results are found
        if (!resultsFound) {
            const noResultsMessage = document.createElement('div');
            noResultsMessage.classList.add('no-results-message'); // Add a class to identify the message
            noResultsMessage.style.textAlign = 'center'; // Center the message
            noResultsMessage.style.fontWeight = 'bold'; // Make the message bold
            noResultsMessage.style.fontSize = '30px'; // Set the font size to 36px
            noResultsMessage.style.paddingTop = '40px'; // Set the font size to 36px
            noResultsMessage.innerHTML = `<p>No results found for "${search}".</p>`;
            searchDiv.appendChild(noResultsMessage);
        }
    }
    
    
    
    
    
    
    
    //--------------  Search bar funcationlity End --------------//

    // ????//////////////////////    new implimatations   End /////////////////////////////////////////



    //-------------------------------create Div dynamically according to custom object-------------------


    @wire(career_data)
getcareerData({ error, data }) {
    if (error) {
        // TODO: Error handling
    } else if (data) {
        console.log('Inside getcareerData');
        console.log('Data: ', data);

        let boxDiv = this.template.querySelector('.row');
        if (!boxDiv) {
            // Wait for the component to finish rendering
            setTimeout(() => {
                this.getcareerData({ error, data });
            }, 0);
            return;
        }

        let cardTemplate;

        console.log('boxDiv: ', boxDiv);

        let cont = this.template.querySelector('.container');
        console.log('cont: ', cont);
        console.log('cont childnodes: ', cont.childNodes);

        for (let i = 0; i < data.length; i++) {
            cardTemplate = `<div class="box1 col-6 ${data[i].Department__c}" data-id="${data[i].Id}" >
                <div class="slds-grid box">
                    <div class="slds-col divsize" style="border-color:${this.bordercolor}">
                        <div class="slds-grid slds-grid_vertical ccd cardHover">
                            <div class="slds-col bold">
                                <h1 class="positionName">${data[i].Name}</h1>
                            </div>
                            <div class="slds-col slds-grid slds-wrap mmm">
                                <div class="slds-col slds-size_1-of-3 bttm">
                                    <span class="jobopening">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-briefcase"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>${data[i].Experience__c}</span>
                                </div>
                                <div class="slds-col slds-size_1-of-3 cityicon">
                                    <p style="font-size: 15px;"> 
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                        ${data[i].Location__c}
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;

            boxDiv.innerHTML += cardTemplate;
        }
    }
            // ---------------- Page redirection---------------------------------
            let cards = this.template.querySelectorAll('.box1');

            for (let i = 0; i < cards.length; i++) {
                cards[i].addEventListener('click', (event) => {
    
    
                    let DivId = event.target.parentNode.parentNode.parentNode.attributes['data-id'].value;
                    console.log('DivID', DivId);
    
                    this[NavigationMixin.Navigate]({
                        type: 'comm__namedPage',
                        attributes: {
                            // name: 'TemplatePage__c'
                            name: this.pagename
    
                        },
                        state: {
                            c__divID: DivId
    
                        }
                    })
    
                });
            }
            
}



    //------Reset button funcation-------------------
    resetbttn() {
        let location = this.template.querySelector('.location');
        let department = this.template.querySelector('.department');
        const searchBar = this.template.querySelector('.filter');
        const searchDiv = this.template.querySelector('.row');
        const cards = searchDiv.querySelectorAll('.col-6');
    
        // Set dropdowns to "All"
        location.value = 'All';
        department.value = 'All';
        searchBar.value = '';
    
        for (let i = 0; i < cards.length; i++) {
            let cardDept = cards[i].className.toUpperCase().trim();
            let cardLoc = cards[i].querySelector('.cityicon').innerText.trim().toUpperCase();
            let title = cards[i].querySelector('.positionName').innerHTML.toUpperCase();
            department = this.template.querySelector('.department').value.trim().toUpperCase();
            location.value.trim().toUpperCase();
    
            console.log(department, cardDept);
            console.log(location, cardLoc);
            console.log(searchBar, title);
    
            if (
                (searchBar.value.indexOf(search.toUpperCase()) > -1) ||
                (location == cardLoc) ||
                (cardDept.includes(department))
            ) {
                cards[i].style.display = "";
            } else {
                cards[i].style.display = "none";
            }
        }
    }


     resetbttn() {
        let location = this.template.querySelector('.location');
        let department = this.template.querySelector('.department');
        const searchBar = this.template.querySelector('.filter');
        const search = searchBar.value.toUpperCase(); // Define the search variable
        const searchDiv = this.template.querySelector('.row');
        const cards = searchDiv.querySelectorAll('.col-6');
    
        // Set dropdowns to "All"
        location.value = 'All';
        department.value = 'All';
        searchBar.value = '';
    
        for (let i = 0; i < cards.length; i++) {
            let cardDept = cards[i].className.toUpperCase().trim();
            let cardLoc = cards[i].querySelector('.cityicon').innerText.trim().toUpperCase();
            let title = cards[i].querySelector('.positionName').innerHTML.toUpperCase();
            department = this.template.querySelector('.department').value.trim().toUpperCase();
            location.value.trim().toUpperCase();
    
            console.log(department, cardDept);
            console.log(location, cardLoc);
            console.log(searchBar, title);
    
            if (
                (searchBar.value.indexOf(search.toUpperCase()) > -1) ||
                (location == cardLoc) ||
                (cardDept.includes(department))
            ) {
                cards[i].style.display = "";
            } else {
                cards[i].style.display = "none";
            }
        }
    }

    

    //--------------  Search bar funcationlity End--------------//

    renderedCallback() {
        Promise.all([loadStyle(this, ZTWebsiteBootstrap)]),
        Promise.all([loadStyle(this, dropdown)]),
        Promise.all([loadStyle(this, cssFile)]);
        
        const divStyle = this.template.querySelector("Div").style;
        divStyle.setProperty("--my-positionclr", this.positioncolor);
        divStyle.setProperty("--my-textclr", this.txtcolor);
        divStyle.setProperty("--my-cardHover", this.hovercolor);
        divStyle.setProperty("--my-cardtxt",this.cardtxtcolor);
        divStyle.setProperty("--my-afterhoverclr",this.afterhovertxtcolor);
        divStyle.setProperty("--my-borderclr",this.bordercolor);
        divStyle.setProperty("--my-positionBgClr",this.posBgClr);

                // Set default values for location and department
                const defaultLocation = 'All';
                const defaultDepartment = 'All';
        
                // Trigger filterData with default values
                this.filterData(defaultLocation, defaultDepartment);

    }

}