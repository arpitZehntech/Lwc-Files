import { LightningElement, api } from 'lwc';

export default class Blurb extends LightningElement {
    BlurbType1;
    BlurbType2;

    // Theme 1 variables
    @api themeoneimg1 = '';
    @api themeoneh1 = '';
    @api themeonesmalltag1 = '';

    @api themeoneimg2 = '';
    @api themeoneh2 = '';
    @api themeonesmalltag2 = '';
    
    @api themeoneimg3 = '';
    @api themeoneh3 = '';
    @api themeonesmalltag3 = '';
    
    @api themeoneimg4 = '';
    @api themeoneh4 = '';
    @api themeonesmalltag4 = '';
    
    @api themeoneimg5 = '';
    @api themeoneh5 = ''; 
    @api themeonesmalltag5 = '';

    @api themeoneimg6 = '';
    @api themeoneh6 = '';
    @api themeonesmalltag6 = '';

    // Theme 2 variables
    @api themetwoh1 = '';
    @api themetwosmalltag1 = '';

    @api themetwoh2 = '';
    @api themetwosmalltag2 = '';
    
    @api themetwoh3 = '';
    @api themetwosmalltag3 = '';
    
    @api themetwoh4 = '';
    @api themetwosmalltag4 = '';
    
    @api themetwoh5 = '';
    @api themetwosmalltag5 = '';
    
    @api themetwoh6 = '';
    @api themetwosmalltag6 = '';

    @api blurbType = 'Theme 1';

    @api containerbackgroundcolor;

    @api title;
    @api description;
    @api titleColor;
    @api descriptionColor;

    connectedCallback(){
        console.log('Blurb Theme: ',this.blurbType);
        if(this.blurbType == 'Theme 1'){
            this.BlurbType1 = true;
            this.BlurbType2 = false;
        }
        else{
            this.BlurbType1 = false;
            this.BlurbType2 = true;
        }
    }

    renderedCallback(){
         //Dynamic CSS Styling
         var css = this.template.host.style;
         css.setProperty('--containerbackgroundcolor', this.containerbackgroundcolor);
         css.setProperty('--titleColor',this.titleColor);
         css.setProperty('--descriptionColor',this.descriptionColor);
    }
}