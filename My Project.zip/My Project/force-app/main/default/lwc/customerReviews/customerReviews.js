import { LightningElement, api, track, wire } from 'lwc';
import showcustomerReviewList from '@salesforce/apex/customerReviewClass.showcustomerReview';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity1';

export default class CustomerReviews extends LightningElement {
    @api selectCustomerReview;
    @api backgroundclr1;
    @api backgroundclr2;
    @api boxbackgroundclr;
    @api textclr1;
    @api textFontFamily1;
    @api textFontFamily2;
    @api completionLineclr;
    @api fontSize1;
    @api fontSize2;
    @api fontSize3;
    @api fontSize4;
    @api customFontFamily1;
    @api customFontFamily2;

    @track showhideFirst = false;
    @track showhideSecond = false;
    @track testimonials = [];
    @track testimonialText;
    @track userPhoto;
    @track userName;
    @track idx = 0;
    @track carouselItems = [];
    intervalId;
    testimonialsLoaded = false;

    connectedCallback() {
        if (this.selectCustomerReview === '1st Review') {
            this.showhideFirst = true;
        } else if (this.selectCustomerReview === '2nd Review') {
            this.showhideSecond = true;
        }
        this.loadTestimonials();
        this.loadFlickity4();
    }

    renderedCallback() {
        const container = this.template.querySelector("div");

        if (container && !this.testimonialsLoaded) {
            container.style.setProperty("--my-backgroundclr1", this.backgroundclr1);
            container.style.setProperty("--my-backgroundclr2", this.backgroundclr2);
            container.style.setProperty("--my-boxbackgroundclr", this.boxbackgroundclr);
            container.style.setProperty("--my-textclr1", this.textclr1);
            container.style.setProperty("--my-completionLineclr", this.completionLineclr);
            container.style.setProperty("--my-fontSize1", this.fontSize1);
            container.style.setProperty("--my-fontSize2", this.fontSize2);
            container.style.setProperty("--my-fontSize3", this.fontSize3);
            container.style.setProperty("--my-fontSize4", this.fontSize4);

            if (this.customFontFamily1) {
                container.style.setProperty('--my-textFontFamily1', this.customFontFamily1);
            } else {
                container.style.setProperty('--my-textFontFamily1', this.textFontFamily1);
            }

            if (this.customFontFamily2) {
                container.style.setProperty('--my-textFontFamily2', this.customFontFamily2);
            } else {
                container.style.setProperty('--my-textFontFamily2', this.textFontFamily2);
            }
        }
    }

    @wire(showcustomerReviewList)
    wiredTestimonials({ error, data }) {
        if (data) {
            this.testimonials = data;
            this.updateTestimonial();

            // if (!this.testimonialsLoaded) {
            //     this.loadTestimonials();
            //     this.testimonialsLoaded = true;
            // }
        } else if (error) {
            console.error('Error fetching testimonial data:', error);
        }
    }

    updateTestimonial() {
        if (this.testimonials && this.testimonials.length > 0) {
            const testimonial = this.testimonials[this.idx];
            this.testimonialText = testimonial?.Text__c;
            this.userPhoto = testimonial?.image_url__c;
            this.userName = testimonial?.Name;

            this.idx = (this.idx + 1) % this.testimonials.length;
        }
    }

    loadFlickity4() {
        loadScript(this, FLICK + '/flickity/jquery.min.js')
            .then(() => {
                return loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js');
            })
            .then(() => {
                return loadStyle(this, FLICK + '/flickity/flickity.css');
            })
            .then(() => {
                this.initializeFlickity();
            })
            .catch(error => {
                console.error('Error loading Flickity resources:', error);
            });
    }

    initializeFlickity() {
        const screenWidth = window.innerWidth;
        let prevNextButtonsEnabled = true;

        if (screenWidth < 768) {
            prevNextButtonsEnabled = false;
        }

        $(this.template.querySelector('div[class="carousel4"]')).flickity({
            prevNextButtons: prevNextButtonsEnabled,
            autoPlay: true,
            draggable: true,
            wrapAround: true,
            pageDots: true,
        });
    }

    loadTestimonials() {
        showcustomerReviewList()
            .then(result => {
                this.carouselItems = result.map(item => ({
                    key: item.Id,
                    text: item.Text__c,
                    imageUrl: item.image_url__c,
                    caption: item.Name,
                    stars: this.generateStars(item.stars__c)
                }));
            })
            .catch(error => {
                console.error('Error fetching testimonial data:', error);
            });
    }

    generateStars(starsCount) {
        let stars = [];

        starsCount = Math.min(starsCount, 5);

        for (let i = 0; i < starsCount; i++) {
            stars.push({ icon: 'utility:favorite', altText: 'Star', title: 'Star' });
        }

        for (let i = starsCount; i < 5; i++) {
            stars.push({ icon: 'utility:favorite_alt', altText: 'Star', title: 'Star' });
        }

        return stars;
    }
}