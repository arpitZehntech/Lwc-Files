import { LightningElement, track, api, wire } from "lwc";
import calendarschedule from '@salesforce/schema/Calendar_Schedule__c'; // object name
import createAccount from '@salesforce/apex/calendarschedule1.createAccount'; // sending customer information ( --- test class )
import getAccounts from '@salesforce/apex/getRecordDataController.getAccounts'; // for showing time and sending date ( --- test class )
import createimeslots from '@salesforce/apex/Availabletimeslots.createimeslots'; // for creating timeslots dates ( --- test class )
// import createtime from '@salesforce/apex/Availabletime.createtime'; // for creating timeslots 
import { loadStyle } from "lightning/platformResourceLoader"; // css loder
import customSR from "@salesforce/resourceUrl/calendar2"; // style css
import { NavigationMixin } from 'lightning/navigation'
import googleauthorization from '@salesforce/apex/GoogleCalenderApi.googleauthorization'; // for Authorize 
import doRefreshToken from '@salesforce/apex/GoogleCalenderApi.doRefreshToken';  // for RefreshToken
import authorised from '@salesforce/apex/authcheck.authorised';  // for RefreshToken  ( --- test class )
// import FetchAccessToken from '@salesforce/apex/GoogleCalenderApi.FetchAccessToken';  // for FetchAccessToken first time
import step1 from '@salesforce/resourceUrl/step1';
import Auth_user from '@salesforce/resourceUrl/Auth_user';
import Credentials from '@salesforce/resourceUrl/Credentials';
import client_id from '@salesforce/resourceUrl/client_id';
var confirmBtn;
var timeBtn;
export default class Calendar2 extends NavigationMixin(LightningElement) {
    // images for user guide 
    @track step1 = step1;
    @track Auth_user = Auth_user;
    @track Credentials = Credentials
    @track client_id = client_id
    @api createappointments  = false;

    @api user_image;



    @api username;
    @api location;
    @api aboutcall;
    @api text;
    @api newstartdate;
    @api lengthResult;
    @api todaycolor
    // ===================================================> for creating timeslots  <================================//c/appointment
    @api lunchstarttime;
    @api lunchendtime;
    @api timediff;
    @api officestarttime;
    @api officeclosetime;

    @track isLoading = false;

    //================================================================ for holiday=======================
    @api sunday = false;
    @api monday = false;
    @api tuesday = false;
    @api wednesday = false;
    @api thursday = false;
    @api friday = false;
    @api saturday = false;


    //----------------------------------------------------------- for Authorization of  google 
    GoogleCalenderApai() {
        googleauthorization().then(result => {
            this.link = result;
            console.log(result);
            this.navigateToWeb();
        })
            .catch(error => {
                console.log(error);
            });
    }
    navigateToWeb() {
        this[NavigationMixin.Navigate]({
            type: "standard__webPage",
            attributes: {
                url: `${this.link}`
            }
        })
    }
    //-------------------------------------------------------------------
    // AccessToken(){
    //     FetchAccessToken().then(result => { 
    //         console.log(result);
    //         console.log('working');
    //     })       
    //     .catch(error => { 
    //         console.log(error);
    //         console.log('error');

    //     });
    // }

    // gettimevalues() {
    //     createtime({ officeopen_hour: this.officeopen_hour, officeopen_min: this.officeopen_min, lunchstart_hour: this.lunchstart_hour, lunchstart_min: this.lunchstart_min, lunchend_hour: this.lunchend_hour, lunchend_min: this.lunchend_min, officeclose_hour: this.officeclose_hour, officeclose_min: this.officeclose_min, timediff: this.timediff })
    //         // createtime({lunchstarttime:this.lunchstarttime,lunchendtime:this.lunchendtime,timediff:this.timediff,officestarttime:this.officestarttime,officeclosetime:this.officeclosetime})
    //         .then(result => {
    //             this.message = result;
    //             this.error = undefined;
    //             if (this.message !== undefined) {
    //             }
    //             // console.log(JSON.stringify(result));
    //         })
    //         .catch(error => {
    //             this.message = undefined;
    //             this.error = error;
    //             // console.log("error", JSON.stringify(this.error));
    //         });

    // }

    // ===================================================> for creating timeslots date <================================//c/appointment


    timeslot() {

        // clickevent for sending data name, time, number, email ,date and description      
        createimeslots({ startdate: this.newstartdate, startmonth: this.startmonth, startyear: this.startyear, enddate: this.enddate, endmonth: this.endmonth, endyear: this.endyear, officeopen_hour: this.officeopen_hour, officeopen_min: this.officeopen_min, lunchstart_hour: this.lunchstart_hour, lunchstart_min: this.lunchstart_min, lunchend_hour: this.lunchend_hour, lunchend_min: this.lunchend_min, officeclose_hour: this.officeclose_hour, officeclose_min: this.officeclose_min, timediff: this.timediff })
            .then(result => {
                this.message = result;
                this.error = undefined;
                this.showToastnew();
                if (this.message !== undefined) {

                }
                // console.log(JSON.stringify(result));
            })
            .catch(error => {
                this.message = undefined;
                this.error = error;
                console.log("error", JSON.stringify(this.error));
                console.log("not working", JSON.stringify(this.error));
            });
    }
    showToastnew() {
        this.template.querySelector("c-appointmenttoster").showToast("success", "Your Appointments created successfully")
    }


    // ============================= get time value and dispaly into the btn =========================== //

    @api time;
    @wire(getAccounts) wiredAccounts({ data, error }) {
        if (data) {
            let selectedtimeDiv = this.template.querySelector('.selectedtimevalue1');
            for (let i = 0; i < data.length; i++) {
                let dates = new Date(data[i].Start_Time__c).toUTCString();
                this.time = dates.split(' ')[4];
                // console.log(' if truetime --------------', this.time, data);
                selectedtimeDiv.innerHTML += ` <li class="time" >
                                            <button class="timevalue value1 ${'time' + i}" >${this.time}</button>
                                            <button class="confirm" onclick={newEvent}>Confirm</button> </li> `;
            }
            timeBtn = this.template.querySelectorAll('.timevalue');
            confirmBtn = this.template.querySelectorAll('.confirm');
            for (let i = 0; i < confirmBtn.length; i++) {
                // console.log(confirmBtn[i]);
                confirmBtn[i].addEventListener('click', event => {
                    // console.log(event);
                    this.tempDate = "";
                    this.toShowCreateModal();
                });
            }
            for (let i = 0; i < timeBtn.length; i++) {
                timeBtn[i].addEventListener('click', event => {
                    for (let j = 0; j < timeBtn.length; j++) {

                        if (!event.target.parentElement.className.includes('selected') && timeBtn[j].className == event.target.className) {
                            event.target.parentElement.className = event.target.parentElement.className + ' selected';

                            this.timevalue = event.target.innerHTML;
                            // console.log(this.timevalue);
                        }
                        else if (timeBtn[j].className !== event.target.className) {
                            timeBtn[j].parentElement.className = timeBtn[j].parentElement.className.replace(' selected', '');
                            // console.log(timeBtn[j], timeBtn[j].parentElement.className, j);
                        }
                    }
                });
            }
        }
        else {
            console.log(error);
            // console.log('time --------------', this.time, data);
        }
    };

    //=================================================================> sending and storing values in salesforce custom object <=====================================//
    handleEmailValidation() {
        var flag = true;
        const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        let email = this.template.querySelector('[data-id="txtEmailAddress"]');
        let emailVal = email.value;
        if (emailVal.match(emailRegex)) {
            email.setCustomValidity("");

        } else {
            flag = false;
            email.setCustomValidity("Please enter valid email");
            // this.template.querySelector("c-appointmenttoster").showToast("error", `Please enter valid email`);
        }
        email.reportValidity();
        return flag;
    }
    handleNumberValidation() {
        var flag = true;
        const phnRegex = '[0-9]{10}';
        let phn = this.template.querySelector('[data-id="txtphn"]');
        let phnVal = phn.value;
        if (phnVal.match(phnRegex)) {
            phn.setCustomValidity("");

        }
        else {
            flag = false;
            phn.setCustomValidity("Please enter valid Number");
            // this.template.querySelector("c-appointmenttoster").showToast("error", `Please enter valid Number`);
        }
        phn.reportValidity();
        return flag;
    }
    handleNameValidation() {
        var flag = true;
        const nameRegex = '[a-zA-Z][a-zA-Z ]{2,}';
        let Name = this.template.querySelector('[data-id="txtName"]');
        let NameVal = Name.value;
        if (NameVal.match(nameRegex)) {
            Name.setCustomValidity("");

        } else {
            flag = false;
            Name.setCustomValidity("Please enter valid Name");
            // this.template.querySelector("c-appointmenttoster").showToast("error", `Please enter valid Name`);
        }
        Name.reportValidity();
        return flag;
    }
    handleNameChange(event) { // sending name 
        this.Name = event.target.value;
        // console.log("name", this.Name);
    }
    handleDateChange(event) { // sending date
        this.selecteddate = event.target.value;
        // console.log("date", this.selecteddate);
    }
    handleTimeChange(event) { // sending time
        this.timevalue = event.target.value;
        // console.log("timevalue", this.timevalue);
    }
    handleEmailChange(event) { // sending email
        this.email = event.target.value;

        // console.log("email", this.email);
    }
    handlePhnChange(event) { // sending phn
        this.contactnumber = event.target.value;

        // console.log("contactnumber", this.contactnumber);
    }
    handleDescriptionChange(event) { // sending Description
        this.description = event.target.value;
        // console.log("description", this.description);
    }



    handleClick() {  // clickevent for sending data name, time, number, email ,date and description 
        this.handleEmailValidation();
        this.handleNumberValidation();
        this.handleNameValidation();
        if (this.Name == '') {
            this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter Your Name`);
        }

        else if (this.email == undefined) {
            this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter Your email`);
        }
        else if (this.contactnumber == undefined) {
            this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter Your Contact Number`);
        }

        else if (this.description == undefined) {
            this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter description`);
        }
        else if (this.contactnumber != undefined && this.Name != undefined && this.email != undefined && this.description != undefined) {
            this.isLoading = true;
            createAccount({ Name: this.Name, selecteddate: this.selecteddate, email: this.email, contactnumber: this.contactnumber, description: this.description, timevalue: this.timevalue})
                .then(result => {
                    this.message = result;
                    this.toHideCreateModal();
                    this.showToast();
                    this.blanksfield();
                    this.error = undefined;

                    if (this.message !== undefined) {
                        this.Name = '';
                    }

                    console.log(JSON.stringify(result));
                })
                .catch(error => {
                    this.message = undefined;
                    this.error = error;
                    let newerror = JSON.stringify(this.error);
                    console.log('------', error.body.fieldErrors);
                    // console.log('sjdnbs',newerror);
                    if (newerror == `{"status":500,"body":{"fieldErrors":{"Email__c":[{"statusCode":"FIELD_CUSTOM_VALIDATION_EXCEPTION","message":"Please Insert Correct Email Address"}]},"pageErrors":[],"index":null,"duplicateResults":[]},"headers":{},"ok":false,"statusText":"Server Error","errorType":"fetchResponse"}`) {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter your Email`);
                    }
                    else if (newerror == `{"status":500,"body":{"fieldErrors":{},"pageErrors":[{"statusCode":"FIELD_CUSTOM_VALIDATION_EXCEPTION","message":"name can not container number"}],"index":null,"duplicateResults":[]},"headers":{},"ok":false,"statusText":"Server Error","errorType":"fetchResponse"}`) {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Name can not be number`);
                    }
                    else if (newerror == `{"status":500,"body":{"fieldErrors":{"Email__c":[{"statusCode":"INVALID_EMAIL_ADDRESS","message":"Email: invalid email address: ${this.email}"}]},"pageErrors":[],"index":null,"duplicateResults":[]},"headers":{},"ok":false,"statusText":"Server Error","errorType":"fetchResponse"}`) {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter Vaild Email`);
                    }
                    else if (newerror == `{"status":500,"body":{"message":"Value provided is invalid for action parameter 'contactnumber' of type 'Decimal'"},"headers":{},"ok":false,"statusText":"Server Error","errorType":"fetchResponse"}`) {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Please enter valid contact Number`);
                    }
                    else if (newerror == `{"status":500,"body":{"fieldErrors":{},"pageErrors":[{"statusCode":"REQUIRED_FIELD_MISSING","message":"Required fields are missing: [Number]"}],"index":null,"duplicateResults":[]},"headers":{},"ok":false,"statusText":"Server Error","errorType":"fetchResponse"}`) {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Please Enter Your Contact Number`);
                    }

                    else {
                        this.template.querySelector("c-appointmenttoster").showToast("error", `Sometning went wrong try after sometime`);
                    }

                    console.log("error inset user", JSON.stringify(this.error));
                }).finally(() => {
                    this.isLoading = false;

                });
        }

    }

    showToast() {
        this.template.querySelector("c-appointmenttoster").showToast("success", "Your Appoinmnet Booked successfully");
        setTimeout(() => {
            history.go(0);
        }, 3000);
    }

    blanksfield() {
        this.template.querySelector(".inputEvent1").value = '';
        this.template.querySelector(".inputEvent").value = '';
        this.template.querySelector(".inputEndDate").value = '';
        this.template.querySelector(".inputEndDate1").value = '';
        this.template.querySelector(".inputEvent11").value = '';
        this.template.querySelector(".inputDescription").value = '';
    }

    // myFunction(x,y) {
    //     var x = this.template.querySelector(".before-onclick");
    //     if (x.style.display === "none") {
    //       x.style.display = "block";
    //     }
    //      else {
    //       x.style.display = "none";
    //     }
    //   }

    //=============================================> send date from lwc to apex to show appoinment <=================================//
    newhandleClick() {
        var x = this.template.querySelector(".before-onclick");
        if (!x.style.display === "none") {
            x.style.display = "block";
        }
        else {
            x.style.display = "none";
        }
        this.template.querySelector('.after-click').style.display = "block";


        getAccounts({ userselecteddate: this.userselecteddate })
            .then(result => {
                this.lengthResult = result.length
                // time value
                if (result) {
                    this.template.querySelector('.noDataMessage').classList.remove('errorMessage')
                    this.template.querySelector('.noslots').style.display = "block";
                    this.template.querySelector('.after-click').style.display = "none";
                    let selectedtimeDiv = this.template.querySelector('.selectedtimevalue1');
                    selectedtimeDiv.innerHTML = '';
                    for (let i = 0; i < result.length; i++) {
                        let dates = new Date(result[i].Start_Time__c).toUTCString();

                        this.time = dates.split(' ')[4];
                        // console.log(' if truetime --------------', this.time, result);
                        if (this.lengthResult != 0) {
                            selectedtimeDiv.innerHTML += ` <li class="time" >
                            <button class="timevalue value1 ${'time' + i}" >${this.time}</button>
                            <button class="confirm" onclick={newEvent}>Confirm</button> </li> `;
                            this.template.querySelector('.noDataMessage').classList.add('errorMessage')
                            this.template.querySelector('.after-click').style.display = "block";

                        }
                    }
                    timeBtn = this.template.querySelectorAll('.timevalue');
                    confirmBtn = this.template.querySelectorAll('.confirm');
                    for (let i = 0; i < confirmBtn.length; i++) {
                        // console.log(confirmBtn[i]);
                        confirmBtn[i].addEventListener('click', event => {
                            // console.log(event);
                            this.tempDate = "";
                            this.toShowCreateModal();
                        });
                    }
                    for (let i = 0; i < timeBtn.length; i++) {
                        timeBtn[i].addEventListener('click', event => {
                            for (let j = 0; j < timeBtn.length; j++) {

                                if (!event.target.parentElement.className.includes('selected') && timeBtn[j].className == event.target.className) {
                                    event.target.parentElement.className = event.target.parentElement.className + ' selected';

                                    this.timevalue = event.target.innerHTML;
                                    // console.log(this.timevalue);
                                }
                                else if (timeBtn[j].className !== event.target.className) {
                                    timeBtn[j].parentElement.className = timeBtn[j].parentElement.className.replace(' selected', '');
                                    // console.log(timeBtn[j], timeBtn[j].parentElement.className, j);
                                }
                            }
                        });
                    }
                }
                else {
                    console.log(error);
                    console.log('time --------------', this.time, result);
                }


                this.message = result;
                this.error = undefined;
                if (this.message !== undefined) {
                    this.Name = '';
                    console.log('userselecteddate: ', this.userselecteddate);
                }
                console.log(JSON.stringify(result));
            })
            .catch(error => {
                this.message = undefined;
                this.error = error;
                console.log("error", JSON.stringify(this.error));
            });
    }

    // ===========================================================================> calendarData <======================================================== 
    @api
    modalSize = "small";
    @track
    calendarData = [];
    @track
    columns = [
        {
            label: "SUN",
            fieldName: "sun"
        },
        {
            label: "MON",
            fieldName: "mon"
        },
        {
            label: "TUE",
            fieldName: "tue"
        },
        {
            label: "WED",
            fieldName: "wed"
        },
        {
            label: "THU",
            fieldName: "thu"
        },
        {
            label: "FRI",
            fieldName: "fri"
        },
        {
            label: "SAT",
            fieldName: "sat"
        }
    ];
    @track showCreateModal = false;
    @track showDetailModal = false;
    @track detailModalStatus = false;
    @track detailModalIfMulti = false;
    @api originEventList = [];
    @track eventList = [];
    @track onProcess = false;
    @track actualTimeZone;
    @track monthNow = 0;
    monthOptions = [
        {
            value: 0,
            label: "January"
        },
        {
            value: 1,
            label: "February"
        },
        {
            value: 2,
            label: "March"
        },
        {
            value: 3,
            label: "April"
        },
        {
            value: 4,
            label: "May"
        },
        {
            value: 5,
            label: "June"
        },
        {
            value: 6,
            label: "July"
        },
        {
            value: 7,
            label: "August"
        },
        {
            value: 8,
            label: "September"
        },
        {
            value: 9,
            label: "October"
        },
        {
            value: 10,
            label: "November"
        },
        {
            value: 11,
            label: "December"
        }
    ];
    // normal data used to render the calendar
    monthLeap = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    monthNormal = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    monthName = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    ];
    // to show the date in the detail modal
    get dateTempForUser() {
        return new Date(this.dateTemp).toLocaleString();
    }
    // to show the start date in the detail modal
    get dateStartTempForUser() {
        return new Date(this.dateStartTemp).toLocaleString();
    }
    // to show the end date in the detail modal
    get dateEndTempForUser() {
        return new Date(this.dateEndTemp).toLocaleString();
    }
    // render the month name now
    get monthNowText() {
        return this.monthName[this.monthNow];
    }
    get createModalCss() {
        let showCreateModal = this.showCreateModal ? "slds-slide-up-open" : "";
        return `slds-modal slds-modal_${this.modalSize} ${showCreateModal}`;
    }
    get createBackdropCss() {
        return this.showCreateModal
            ? "slds-backdrop slds-backdrop_open"
            : "slds-backdrop";
    }
    get detailModalCss() {
        let showDetailModal = this.showDetailModal ? "slds-slide-up-open" : "";
        return `slds-modal slds-modal_${this.modalSize} ${showDetailModal}`;
    }
    get detailBackdropCss() {
        return this.showDetailModal
            ? "slds-backdrop slds-backdrop_open"
            : "slds-backdrop";
    }
    get monthYearModalCss() {
        let showMonthYearModal = this.showMonthYearModal
            ? "slds-slide-up-open"
            : "";
        return `slds-modal slds-modal_${this.modalSize} ${showMonthYearModal}`;
    }
    get monthYearBackdropCss() {
        return this.showMonthYearModal
            ? "slds-backdrop slds-backdrop_open"
            : "slds-backdrop";
    }
    connectedCallback() {
        this.getBasicData();
        this.generateCalendarData();
        Object.assign(this.eventList, this.originEventList);
        this.arrangeEvents();
    }
    @api slotmonths;
    @api startdate;
    @api enddate;

    // split time var

    @api hourvalue;
    @api minvalue;
    @api secvalue;
    @api milsecvalue;



    // =================================================================================================renderedCallback==================================

    renderedCallback() {
        //================================================================================ time splits
        // for refreesh token 


        authorised().then(result => {
            // console.log(result); console.log('working,result');
            this.Authorised = result[0].Authorised__c;
            this.ExpiryTime = result[0].ExpiryTime__c;
            const Expiry_datetime = new Date(this.ExpiryTime);
            // const Expiry_time = Expiry_datetime.toLocaleTimeString();
            // console.log(Expiry_datetime.getHours());
            // const Expiry_hours = Expiry_datetime.getHours();
            // const Expiry_minutes = Expiry_datetime.getMinutes();
            // const Expiry_date = Expiry_datetime.getDate();
            // const Expiry_month = Expiry_datetime.getMonth();
            // const Expiry_year = Expiry_datetime.getFullYear();
            //  console.log('Expiry_datetime',Expiry_datetime);
            // // console.log(Expiry_datetime)
            // console.log('Expiry_time', Expiry_date,Expiry_month ,Expiry_year);

            const currentDatetime = new Date();
            // console.log(currentDatetime);
            // const current_time = currentDatetime.toLocaleTimeString();
            // const current_hours = currentDatetime.getHours();
            // const current_minutes = currentDatetime.getMinutes();
            // const current_date = currentDatetime.getDate();
            // const current_month = currentDatetime.getMonth();
            // const current_year = currentDatetime.getFullYear();
            // console.log('current_date',current_date,current_month,current_year);
            // console.log('currentDatetime',currentDatetime);
            // console.log('this.ExpiryTime', this.ExpiryTime);
           


            if (Expiry_datetime <= currentDatetime) {
                 doRefreshToken().then(result => {
                    console.log('doRefreshToken');
                })
                    .catch(error => {
                        console.log('error12', error);
                    });
            }

            // if (Expiry_hours <= current_hours && Expiry_minutes <= current_minutes) {
            //     doRefreshToken().then(result => {

            //     })
            //         .catch(error => {
            //             console.log('error12', error);
            //         });
            // }


            if (this.Authorised == true) {
                this.template.querySelector('.responsive_container').classList.remove('slds-hide');
                this.template.querySelector('.googlebtn').classList.add('slds-hide');
                // console.log('true', this.Authorised);
            }
            if (this.Authorised == false) {
                this.template.querySelector('.responsive_container').classList.add('slds-hide');
                this.template.querySelector('.googlebtn').classList.remove('slds-hide');
                // console.log('false', this.Authorised);
            }
        })
            .catch(error => {
                console.log('error14', error);

            });



        // googleauthorization().then(result => { console.log(result); })
        // .catch(error => { console.log(error);
        // });


        if (this.officestarttime != null && this.officestarttime != '' && this.officestarttime != undefined) {
            let officestart = this.officestarttime.split(':')
            this.officeopen_hour = officestart[0];
            this.officeopen_min = officestart[1];
            // console.log('officestarttime------', this.officeopen_hour, this.officeopen_min);
        }

        if (this.lunchstarttime != null && this.lunchstarttime != '' && this.lunchstarttime != undefined) {
            let lunchstart = this.lunchstarttime.split(':')
            this.lunchstart_hour = lunchstart[0];
            this.lunchstart_min = lunchstart[1];
            // console.log('lunchstart------', this.lunchstart_hour, this.lunchstart_min);
        }
        if (this.lunchendtime != null && this.lunchendtime != '' && this.lunchendtime != undefined) {
            let lunchend = this.lunchendtime.split(':')
            this.lunchend_hour = lunchend[0];
            this.lunchend_min = lunchend[1];
            // console.log('lunchend------', this.lunchstart_hour, this.lunchstart_min);
        }

        if (this.officeclosetime != null && this.officeclosetime != '' && this.officeclosetime != undefined) {
            let officeclose = this.officeclosetime.split(':')
            this.officeclose_hour = officeclose[0];
            this.officeclose_min = officeclose[1];
            // console.log('officeclosetime------', this.officeclose_hour, this.officeclose_min);
        }

        //function to add months to a date
        function addMonthsToDate(_date, _noOfMonths) {
            return new Date(_date.setMonth(_date.getMonth() + _noOfMonths));
        }
        //usage of the function addMonthsToDate
        var todayDate = new Date();

        var todayDate2 = new Date();
        var todayDate3 = new Date();
        var todayDate4 = new Date();
        var todayDate5 = new Date();



        let todayyear = todayDate2.getFullYear(); //year
        let todaymonth = todayDate2.getMonth() + 1; // month
        let todayday = todayDate2.getDate(); // date , day



        // for  making not clickable

        let elem = this.template.querySelector('.monthNowText1').innerText;
        let todaymnth;
        let month_value;
        let yearhide = this.template.querySelector('.yearhide').innerText;
        if (elem == "December") {
            todaymnth = '12';
            month_value = '11';
        }
        else if (elem == "January") {
            todaymnth = '1';
            month_value = '0';
        }
        else if (elem == "February") {
            todaymnth = '2';
            month_value = '1';
        }
        else if (elem == "March") {
            todaymnth = '3';
            month_value = '2';
        }
        else if (elem == "April") {
            todaymnth = '4';
            month_value = '3';
        }
        else if (elem == "May") {
            todaymnth = '5';
            month_value = '4';
        }
        else if (elem == "June") {
            todaymnth = '6';
            month_value = '5';
        }
        else if (elem == "July") {
            todaymnth = '7';
            month_value = '6';
        }
        else if (elem == "August") {
            todaymnth = '8';
            month_value = '7';
        }
        else if (elem == "September") {
            todaymnth = '9';
            month_value = '8';
        }
        else if (elem == "October") {
            todaymnth = '10';
            month_value = '9';
        }
        else if (elem == "November") {
            todaymnth = '11';
            month_value = '10';
        }

        const userElements = this.template.querySelectorAll('.datecss')
        Array.from(userElements).forEach(item => {
            // console.log(item.innerText)
            var divdates = item.innerText;
            //  console.log('divdates',divdates)
            item.setAttribute("title", item.innerText)
            //  console.log('todayday@@@@@@@@@@@@sdfds' ,todayday);
            if (todayday > divdates && todaymnth == todaymonth && yearhide == todayyear) {
                item.style.pointerEvents = "none";
                item.style.color = "#929eaa";
                item.style.border = "none";
                item.style.background = "transparent";
                this.template.querySelector('.prevButton ').disabled = true;
            }

            else if (divdates == todayday && todaymnth == todaymonth && yearhide == todayyear) {
                item.style.pointerEvents = "none";
                item.style.color = "#FFFFFF";
            }

            else {
                item.style.color = "#006EFF";
                item.style.background = "#F2F8FF";
                item.style.pointerEvents = "auto";
                this.template.querySelector('.prevButton ').disabled = false;
            }
        })
        //  for changing color of the which user want to not do meetings


        const hoildays = this.template.querySelectorAll('.datecss')
        Array.from(hoildays).forEach(datesvalue => {
            var dates = datesvalue.innerText
            var dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var todayDate = new Date(yearhide, month_value, dates);
            var day = dayName[todayDate.getDay()];
            // console.log('-----------',todayDate);
            // console.log(day)
            // console.log('newww',datesvalue.innerText)
            if (this.saturday == false) {
                if (day == 'Saturday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello Saturday');
                }
            }
            if (this.sunday == false) {
                if (day == 'Sunday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello sunday');
                }
            }
            if (this.monday == false) {
                if (day == 'Monday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello monday');
                }
            }
            if (this.tuesday == false) {
                if (day == 'Tuesday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello tuesday');
                }
            }
            if (this.wednesday == false) {
                if (day == 'Wednesday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello Wednesday');
                }
            }
            if (this.thursday == false) {
                if (day == 'Thursday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello Thursday');
                }
            }
            if (this.friday == false) {
                if (day == 'Friday') {
                    datesvalue.style.pointerEvents = "none";
                    datesvalue.style.color = "#929eaa";
                    datesvalue.style.border = "none";
                    datesvalue.style.background = "transparent";
                    // console.log('hello Friday');

                }
            }

            // else{
            //     datesvalue.style.color = "#006EFF";
            //     datesvalue.style.background = "#F2F8FF"; 
            //    datesvalue.style.pointerEvents = "auto";   
            //    this.template.querySelector('.prevButton ').disabled = false;  
            // }

        })


        let startdatevalue = todayyear + ',' + todaymonth + ',' + todayday;
        //this.newstartdate = todayDate.getFullYear() + ',' + todayDate.getMonth() + ',' + todayDate.getDay(); // converted date in formate year,month,date
        // console.log(todayyear + ',' + todaymonth + ',' + todayday);
        // this.newstartdate = todayyear + ', ' + todaymonth + ', ' + todayday ;
        this.newstartdate = todayday;
        this.startmonth = todaymonth;
        this.startyear = todayyear;


        Promise.all([loadStyle(this, customSR)]);
        this.reduceOtherDayOpactiy();
        switch (this.slotmonths) {
            case 'One Month':
                var onemonth = addMonthsToDate(todayDate, 1);
                let date1 = onemonth.getDate();
                let monthvalue = onemonth.getMonth() + 1;
                let yearvalue = onemonth.getFullYear();
                // let onemonthvalue =  yearvalue + ', ' + monthvalue + ', ' + tempp;
                // console.log('onemonth', onemonth);
                this.enddate = date1;
                this.endmonth = monthvalue;
                this.endyear = yearvalue;
                // console.log('end date', this.enddate, this.endmonth, this.endyear);
                // console.log('start date', this.newstartdate, this.startmonth, this.startyear);
                if (this.createappointments  == true) {
                    this.timeslot();
                    console.log('timeslot');
                }
               
                // this.gettimevalues();
                break;
            case 'Three Months':
                var threemonth = addMonthsToDate(todayDate2, 3);
                let tempp1 = threemonth.getDate();
                let monthvalue1 = threemonth.getMonth() + 1;
                let yearvalue1 = threemonth.getFullYear();
                // let threemonthvalue =  yearvalue1 + ', ' + monthvalue1 + ', ' + tempp1;
                // console.log('three', threemonth);
                this.enddate = tempp1;
                this.endmonth = monthvalue1;
                this.endyear = yearvalue1;
                // console.log('end date', this.enddate, this.endmonth, this.endyear);
                // console.log('start date', this.newstartdate, this.startmonth, this.startyear);
                if (this.createappointments  == true) {
                    this.timeslot();
                    console.log('timeslot');
                }
               
                break;
            case 'Six Months':
                var sixmonth = addMonthsToDate(todayDate3, 6);
                let tempp2 = sixmonth.getDate();
                let monthvalue2 = sixmonth.getMonth() + 1;
                let yearvalue2 = sixmonth.getFullYear();
                // let sixmonthvalue =  yearvalue2 + ', ' + monthvalue2 + ', ' + tempp2;
                // console.log('three', threemonth);
                this.enddate = tempp2;
                this.endmonth = monthvalue2;
                this.endyear = yearvalue2;
                // console.log('end date', this.enddate, this.endmonth, this.endyear);
                // console.log('start date', this.newstartdate, this.startmonth, this.startyear);
                if (this.createappointments  == true) {
                    this.timeslot();
                    console.log('timeslot');
                }
                break;
            case 'One Year':
                var oneyear = addMonthsToDate(todayDate5, 12);
                let tempp3 = oneyear.getDate();
                let monthvalue3 = oneyear.getMonth() + 1;
                let yearvalue3 = oneyear.getFullYear();
                // let oneyearvalue =  yearvalue3 + ', ' + monthvalue3 + ', ' + tempp3;
                // console.log('year', oneyear);
                this.enddate = tempp3;
                this.endmonth = monthvalue3;
                this.endyear = yearvalue3;
                // console.log('end date', this.enddate, this.endmonth, this.endyear);
                // console.log('start date', this.newstartdate, this.startmonth, this.startyear);
                if (this.createappointments  == true) {
                    this.timeslot();
                    console.log('timeslot');

                }
                break;
            default:
                this.enddate = onemonthvalue;
                // console.log('end date', this.enddate);
                if (this.createappointments  == true) {
                    this.timeslot();
                    console.log('timeslot');
                }
                break;
        }
    }
    handleDragStart(e) {
        this.eventId = e.target.dataset.id;
    }
    handleDrop(e) {
        e.currentTarget.classList.remove("drag-hover");
        if (e.currentTarget.dataset.datestring) {
            let that = this;
            let originEvent = this.eventList.find((eventItem) => {
                return eventItem.id === that.eventId;
            });
            const targetDate = new Date(e.currentTarget.dataset.datestring);
            const dateDiff = this.dayDiff(originEvent.startDate, targetDate);
            let newEvent = {
                id: originEvent.id,
                title: originEvent.title,
                description: originEvent.description,
                startDate: this.addDays(originEvent.startDate, dateDiff),
                endDate: this.addDays(originEvent.endDate, dateDiff)
            };
            const event = new CustomEvent("editevent", {
                detail: newEvent
            });
            this.dispatchEvent(event);
            this.deleteEventByEventId();
            this.eventList.push(newEvent);
            this.refreshCalendar();
        }
    }
    handleDragOver(e) {
        e.preventDefault();
    }
    handleDragEnter(e) {
        e.currentTarget.classList.add("drag-hover");

    }
    handleDragLeave(e) {
        e.currentTarget.classList.remove("drag-hover");
    }
    saveNewEvent() {
        let inputStartDateStatus = JSON.stringify(
            this.template.querySelector(".inputStartDate").value
        );
        let inputEndDateStatus = JSON.stringify(
            this.template.querySelector(".inputEndDate").value
        );
        let inputStartDate = this.template.querySelector(".inputStartDate")
            .value;
        let inputEndDate = this.template.querySelector(".inputEndDate").value;
        let inputEvent = this.template.querySelector(".inputEvent").value;
        let inputDescription = this.template.querySelector(".inputDescription")
            .value;
        let randomNum = "";
        for (let i = 0; i < 6; i++) {
            randomNum += Math.floor(Math.random() * 10);
        }
        let eventId = Number(new Date(inputStartDate)) + randomNum;
        if (
            inputEvent.replace(/(^s*)|(s*$)/g, "").length !== 0 &&
            inputStartDateStatus !== "null" &&
            inputEndDateStatus !== "null" &&
            new Date(inputStartDate) < new Date(inputEndDate)
        ) {
            this.onProcess = true;
            this.template.querySelector(".inputStartDate").disabled = true;
            this.template.querySelector(".inputEndDate").disabled = true;
            this.template.querySelector(".inputEvent").disabled = true;
            this.template.querySelector(".inputDescription").disabled = true;
            let newEvent = {
                startDate: new Date(inputStartDate),
                endDate: new Date(inputEndDate),
                title: inputEvent,
                description: inputDescription,
                id: eventId
            };
            const event = new CustomEvent("newevent", {
                detail: newEvent
            });
            this.dispatchEvent(event);
            this.eventList.push(newEvent);
            this.refreshCalendar();
            this.onProcess = false;
            this.toHideCreateModal();
            this.template.querySelector(".inputStartDate").disabled = false;
            this.template.querySelector(".inputEndDate").disabled = false;
            this.template.querySelector(".inputEvent").disabled = false;
            this.template.querySelector(".inputDescription").disabled = false;
        } else {
            this.showToast("ERROR", "Illegal input", "error");
        }
    }
    eventClickHandler(evt) {
        evt.stopPropagation();
        this.titleTemp = evt.target.title;
        this.descriptionTemp = evt.target.dataset.description;
        this.eventId = evt.target.dataset.id;
        this.dateStartTemp = evt.target.dataset.datestart;
        this.dateEndTemp = evt.target.dataset.dateend;
        this.toShowDetailModal();
    }



    refreshCalendar() {
        this.calendarData = [];
        this.generateCalendarData();
        this.arrangeEvents();
    }
    thisMonth(d, h, m) {
        const t = new Date();
        return new Date(t.getFullYear(), t.getMonth(), d, h || 0, m || 0);
    }

    // ================================================================> for picking date on click <=================================================================//

    dateTileClickHandler(evt) {


        // for changing color of selected date
        let selectedDate = this.template.querySelectorAll('.dateCell');
        // console.log('lakhan d',selectedDate.value);

        for (let i = 0; i < selectedDate.length; i++) {

            if (selectedDate[i] == evt.target) {
                selectedDate[i].classList.add('selectdate')
            }
            else {
                selectedDate[i].classList.remove('selectdate');
            }
        }


        const monthsLong = {
            January: '01',
            February: '02',
            March: '03',
            April: '04',
            May: '05',
            June: '06',
            July: '07',
            August: '08',
            September: '09',
            October: '10',
            November: '11',
            December: '12',
        };

        let temp = {
            1: '01',
            2: '02',
            3: '03',
            4: '04',
            5: '05',
            6: '06',
            7: '07',
            8: '08',
            9: '09',
            10: '10',
            11: '11',
            12: '12',
            13: '13',
            14: '14',
            15: '15',
            16: '16',
            17: '17',
            18: '18',
            19: '19',
            20: '20',
            21: '21',
            22: '22',
            23: '23',
            24: '24',
            25: '25',
            26: '26',
            27: '27',
            28: '28',
            29: '29',
            30: '30',
            31: '31',
        };


        let monthdate = temp[evt.target.innerHTML];   // date
        let monthNumber = monthsLong['', this.monthNowText]; // month
        // let selecteddate = monthdate + '/' + monthNumber + '/' + this.yearNow;  // full date with date/month/year
        let selecteddate = monthNumber + '/' + monthdate + '/' + this.yearNow;  // full date with date/month/year

        this.template.querySelector('.inputEvent1').value = selecteddate;

        let selecteddate1 = monthNumber + '/' + monthdate + '/' + this.yearNow;  // full date with date/month/year

        const [day, month, year] = selecteddate.split('/')
        const result = [year, month, day].join('-');
        // this.userselecteddate = result;

        // console.log(this.userselecteddate);

        this.userselecteddate = selecteddate1;

        this.selecteddate = selecteddate; // for sending date to popup modue input
        this.template.querySelector('.selectedtimevalue').innerHTML = selecteddate;
        this.newhandleClick();
    }

    /**
     * @description generate calendar data for template to render
     * @param {*} eventList
     */
    generateCalendarData() {
        let totalDay = this.getIfLeap(this.monthNow, this.yearNow); //get the total day count of this month
        let firstDay = this.getDayStart(this.monthNow, this.yearNow); //get the first day(week) of this month
        //get next page day
        let nextPageMonth = this.monthNow + 1;
        let nextPageYear = this.yearNow;
        if (nextPageMonth > 11) {
            nextPageYear = this.yearNow + 1;
            nextPageMonth = 0;
        }
        //get previous page day
        let prevPageMonth = this.monthNow - 1;
        let prevPageYear = this.yearNow;
        if (prevPageMonth < 0) {
            prevPageYear = this.yearNow - 1;
            prevPageMonth = 11;
        }
        let calendarList = [];
        let count = 0;
        let countN = 0;
        let countP = this.getIfLeap(prevPageMonth, prevPageYear) - firstDay;
        let k = 0;
        // assemble the calendar list
        for (let i = 0; i < 6; i++) {
            let itemList = [];
            if (i === 0) {
                for (k = 1; k <= firstDay; k++) {
                    countP++;
                    let prevDate = new Date(
                        prevPageYear,
                        prevPageMonth,
                        countP,
                        0,
                        0,
                        0,
                        0
                    );
                    let style =
                        this.dayDiff(prevDate, new Date()) === 0
                            ? "background-color: #3d5a80  "
                            : "";
                    itemList.push({
                        value: countP + "",
                        type: "",
                        label: countP + "",
                        index: countP + "",
                        status: "prevMonth",
                        style: style,
                        dateString: prevDate.toISOString()
                    });
                }
                k--;
            } else {
                k = 0;
            }
            for (let j = 0; j < 7 - k; j++) {
                count++;
                let nextDate = new Date(
                    nextPageYear,
                    nextPageMonth,
                    countN,
                    0,
                    0,
                    0,
                    0
                );
                let style =
                    this.dayDiff(nextDate, new Date()) === 0
                        ? "background-color: #3d5a80"
                        : "";
                if (count > totalDay) {
                    countN++;
                    itemList.push({
                        value: countN + "",
                        type: "",
                        label: countN + "",
                        index: countN + "",
                        status: "nextMonth",
                        style: style,
                        dateString: nextDate.toISOString()
                    });
                } else {
                    let date = new Date(
                        this.yearNow,
                        this.monthNow,
                        count,
                        0,
                        0,
                        0,
                        0
                    );
                    let style =
                        this.dayDiff(date, new Date()) === 0
                            ? "background-color: #3d5a80"
                            : "";
                    itemList.push({
                        value: count + "",
                        type: "",
                        label: count + "",
                        index: count,
                        status: "thisMonth",
                        style: style,
                        dateString: date.toISOString()
                    });
                }
            }
            calendarList.push({
                items: itemList,
                weekStart: itemList[0].dateString,
                weekIndex: i,
                events: []
            });
        }
        this.calendarData = calendarList;
    }
    arrangeEvents() {
        let calendarData = this.calendarData;
        for (let i = 0; i < 6; i++) {
            const weekStart = new Date(calendarData[i].weekStart);
            const items = this.findAndSortItemsInWeek(weekStart);
            const results = [];
            const itemRows = [[], [], [], [], [], [], []];



            for (let i = 0; i < items.length; i++) {
                const ep = Object.assign({}, items[i], {
                    classes: ["cv-item"],
                    itemRow: 0
                });
                const continued = ep.startDate < weekStart;
                const startOffset = continued
                    ? 0
                    : this.dayDiff(weekStart, ep.startDate);
                const span = Math.min(
                    7 - startOffset,
                    this.dayDiff(
                        this.addDays(weekStart, startOffset),
                        ep.endDate
                    ) + 1
                );
                if (continued) ep.classes.push("continued");
                if (this.dayDiff(weekStart, ep.endDate) > 6)
                    ep.classes.push("toBeContinued");
                if (this.isInPast(ep.endDate)) ep.classes.push("past");
                // if (ep.originalItem.url) ep.classes.push("hasUrl")
                for (let d = 0; d < 7; d++) {
                    if (d === startOffset) {
                        let s = 0;
                        while (itemRows[d][s]) {
                            s++;
                        }
                        ep.itemRow = s;
                        itemRows[d][s] = true;
                    } else if (d < startOffset + span) {
                        itemRows[d][ep.itemRow] = true;
                    }
                }
                ep.classes.push(`offset${startOffset}`);
                ep.classes.push(`span${span}`);
                let classesString = "";
                for (let item of ep.classes) {
                    classesString += item + " ";
                }
                ep.classesString = classesString;
                let top = this.getItemTop(ep.itemRow);
                let style = `top:${top};`;
                ep.style = style;
                results.push(ep);
            }
            calendarData[i].events = results;
        }
        this.calendarData = calendarData;
        // console.log(JSON.stringify(this.calendarData));
    }
    getItemTop(itemRow) {
        // Compute the top position of the item based on its assigned row within the given week.
        const itemTop = "1.4em";
        const r = itemRow;
        const h = "2.2em";
        const b = "2px";
        return `calc(${itemTop} + ${r}*${h} + ${r}*${b})`;
    }
    isInPast(d) {
        return this.dateOnly(d) < this.today();
    }
    today() {
        return this.dateOnly(new Date());
    }
    dayDiff(d1, d2) {
        const endDate = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate()),
            startDate = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
        return (endDate - startDate) / 86400000;
    }
    itemComparer(a, b) {
        if (a.startDate < b.startDate) return -1;
        if (b.startDate < a.startDate) return 1;
        if (a.endDate > b.endDate) return -1;
        if (b.endDate > a.endDate) return 1;
        return a.id < b.id ? -1 : 1;
    }
    findAndSortItemsInWeek(weekStart) {
        // Return a list of items that INCLUDE any portion of a given week.
        return this.findAndSortItemsInDateRange(
            weekStart,
            this.addDays(weekStart, 6)
        );
    }
    findAndSortItemsInDateRange(startDate, endDate) {
        let events = this.eventList;
        let eventInRangeList = [];
        for (let item of events) {
            if (
                new Date(item.endDate) >= startDate &&
                this.dateOnly(item.startDate) <= endDate
            ) {
                eventInRangeList.push(item);
            }
        }
        return eventInRangeList.sort(this.itemComparer);
    }
    addDays(d, days) {
        return new Date(
            d.getFullYear(),
            d.getMonth(),
            d.getDate() + days,
            d.getHours(),
            d.getMinutes(),
            d.getSeconds()
        );
    }
    dateOnly(d) {
        // Always use a copy, setHours mutates argument
        const d2 = new Date(d);
        d2.setHours(0, 0, 0, 0);
        return d2;
    }
    toPrevMonth() {
        // for changing color of selected date
        let selectedDate = this.template.querySelectorAll('.dateCell');
        // console.log('lakhan d',selectedDate.value);
        for (let i = 0; i < selectedDate.length; i++) {
            selectedDate[i].classList.remove('selectdate');
        }
        this.monthNow--;
        if (this.monthNow < 0) {
            this.yearNow--;
            this.monthNow = 11;
        }
        this.generateCalendarData();
        this.arrangeEvents();
    }
    toNextMonth() {
        // for changing color of selected date
        let selectedDate = this.template.querySelectorAll('.dateCell');
        // console.log('lakhan d',selectedDate.value);
        for (let i = 0; i < selectedDate.length; i++) {
            selectedDate[i].classList.remove('selectdate');
        }

        this.monthNow++;
        if (this.monthNow > 11) {
            this.yearNow++;
            this.monthNow = 0;
        }
        this.generateCalendarData();
        this.arrangeEvents();


    }
    toToday() {
        this.monthNow = this.monthOrigin;
        this.yearNow = this.yearOrigin;
        this.generateCalendarData();
        this.arrangeEvents();
    }


    reduceOtherDayOpactiy() {
        let prevDayList = this.template.querySelectorAll(
            `[data-datestatus="prevMonth"]`
        );
        for (let i = 0; i < prevDayList.length; i++) {
            prevDayList[i].classList.add('prevMonth')
            // prevDayList[i].style.color = "#dfdfdf";
            // selectedDate[i].classList.add('selectdate') 


        }
        let nextDayList = this.template.querySelectorAll(
            `[data-datestatus="nextMonth"]`
        );
        for (let i = 0; i < nextDayList.length; i++) {
            nextDayList[i].classList.add('prevMonth')
            // nextDayList[i].style.color = "#dfdfdf";

        }
    }

    /**
     * @description generate the basic data to render the calendar
     */
    getBasicData() {
        this.dateNow = new Date();
        // console.log('this.dateNow' , this.dateNow);
        this.yearNow = this.dateNow.getFullYear();
        // console.log('this.yearNow' , this.yearNow);
        this.monthNow = this.dateNow.getMonth();
        // console.log('this.monthNow' , this.monthNow+1);
        this.dayNow = this.dateNow.getDate();
        // console.log('this.monthNow' , this.dayNow);
        this.yearOrigin = this.yearNow;

        this.monthOrigin = this.monthNow;
        this.dayOrigin = this.dayNow;
        this.actualTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    }
    /**
     * @description get the first day of a month
     */
    getDayStart(month, year) {
        let tmpDate = new Date(year, month, 1);
        return tmpDate.getDay();
    }
    /**
     * @description get the day count of a month in consideration of the leap year.
     * @param {*} month
     * @param {*} year
     */
    getIfLeap(month, year) {
        let tmp = year % 4;
        let monthDayNumber = 0;
        if (tmp === 0) {
            monthDayNumber = this.monthLeap[month];
        } else {
            monthDayNumber = this.monthNormal[month];
        }
        return monthDayNumber;
    }
    toShowCreateModal() {
        this.showCreateModal = true;
    }
    toHideCreateModal() {
        this.showCreateModal = false;
    }
    toShowDetailModal() {
        this.showDetailModal = true;
    }
    toHideDetailModal() {
        this.showDetailModal = false;
    }
}