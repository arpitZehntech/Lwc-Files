import { LightningElement , api  } from 'lwc';

export default class Featuretemplate extends LightningElement {


    @api heading = '';
    @api content = '';
    @api title = '';
    @api feature = '';
    @api title2 = '';
    @api feature2 = '';
    @api title3 = '';
    @api feature3 = '';
    @api title4 = '';
    @api feature4 = '';

    @api title5 = '';
    @api feature5 = '';
    @api title6 = '';
    @api feature6 = '';
    @api title7 = '';
    @api feature7 = '';
    @api title8 = '';
    @api feature8 = '';
    @api imageurl = '';
    @api imageicon = '';
    @api imageicon1 = '';
    @api imageicon2 = '';
    @api imageicon3 = '';
    @api imageicon4 = '';
    @api imageicon5 = '';
    @api imageicon6 = '';
    @api imageicon7 = '';



    @api contentclr;
    @api contentsize;


    @api headingclr;
    @api headingsize;
    @api titlecolor;
    @api titlecolor1;
    @api titlecolor2;
    @api titlecolor3;
    @api titlecolor4;
    @api titlecolor5;
    @api titlecolor6;
    @api titlecolor7;

    @api featurecolor;
    @api featurecolor1;
    @api featurecolor2;
    @api featurecolor3;
    @api featurecolor4;
    @api featurecolor5;
    @api featurecolor6;
    @api featurecolor7;
    @api backgroundcircleclr;
    @api backgroundcircleclr1;

    @api headingfontfamily;
    @api featurefontfamily;

    renderedCallback() {

        this.template
            .querySelector("h1")
            .style.setProperty("--my-headingclr", this.headingclr);


        this.template
            .querySelector("p")
            .style.setProperty("--Content", this.contentclr);

        this.template
            .querySelector("h1")
            .style.setProperty("--headingsize", this.headingsize);

        this.template
            .querySelector("p")
            .style.setProperty("--contentsize", this.contentsize);

        this.template
            .querySelector("h5")
            .style.setProperty("--titleclr", this.titlecolor);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext", this.featurecolor);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext1", this.featurecolor1);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext2", this.featurecolor2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext3", this.featurecolor3);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext4", this.featurecolor4);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext5", this.featurecolor5);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext6", this.featurecolor6);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext7", this.featurecolor7);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-titleclr1", this.titlecolor1);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr2", this.titlecolor2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr3", this.titlecolor3);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr4", this.titlecolor4);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr5", this.titlecolor5);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr6", this.titlecolor6);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr7", this.titlecolor7);

            
        this.template
        .querySelector("Div")
        .style.setProperty("--backgroundcircleclr", this.backgroundcircleclr);

            
        this.template
        .querySelector("Div")
        .style.setProperty("--backgroundcircleclr1", this.backgroundcircleclr1);

        this.template
        .querySelector("Div")
        .style.setProperty("--my-headingfontfamily", this.headingfontfamily);

        
        this.template
        .querySelector("Div")
        .style.setProperty("--my-featurefontfamily", this.featurefontfamily);
    }


}