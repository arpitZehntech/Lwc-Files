import { LightningElement, api } from 'lwc';


export default class PricingCard extends LightningElement {
    template1;
    template2;

    @api themeType;

    // Theme 1 

    @api themeOneHeaderHeading;
    @api themeOneHeaderHeadingColor;
    @api themeOneHeaderHeadingFontFamily;

    // Theme 1 Even Card
    @api themeOneEvenCardBackgoundColor;
    @api themeOneEvenCardHeaderBackgroundColor;
    @api themeOneEvenCardHeaderPtable1TitleFontFamily;
    @api themeOneEvenCardHeaderPtable1TitleColor;
    @api themeOneEvenCardBodyValuesFontFamily;
    @api themeOneEvenCardBodyValuesFontColor;

    // Theme 1 Odd Card
    @api themeOneOddCardBackgoundColor;
    @api themeOneOddCardHeaderBackgroundColor;
    @api themeOneOddCardHeaderPtable1TitleFontFamily;
    @api themeOneOddCardHeaderPtable1TitleColor;
    @api themeOneOddCardBodyValuesFontFamily;
    @api themeOneOddCardBodyValuesFontColor;


    // Card 1
    @api themeOneCard1BackgroundColor;
    @api themeOneCard1DesignColor;
    @api themeOneCard1Ptable1Title;
    @api themeOneCard1Ptable1Price;

    @api themeOneCard1Ptable1Row1Value;
    @api themeOneCard1Ptable1Row2Value;
    @api themeOneCard1Ptable1Row3Value;
    @api themeOneCard1Ptable1Row4Value;
    @api themeOneCard1Ptable1Row5Value;
    @api themeOneCard1Ptable1Row6Value;
    @api themeOneCard1Ptable1Row7Value;
    @api themeOneCard1Ptable1Row8Value;
    @api themeOneCard1Ptable1Row9Value;
    @api themeOneCard1Ptable1Row10Value;

    @api themeOneCard1PtableButtonBackgroundColor;
    @api themeOneCard1PtableButtonText;
    @api themeOneCard1PtableButtonTextColor;
    @api themeOneCard1PtableButtonRenderURL;

    // Card 2
    @api themeOneCard2BackgroundColor;
    @api themeOneCard2DesignColor;
    @api themeOneCard2Ptable1Title;
    @api themeOneCard2Ptable1Price; 2
    @api themeOneCard2Ptable1Row1Value;
    @api themeOneCard2Ptable1Row2Value;
    @api themeOneCard2Ptable1Row3Value;
    @api themeOneCard2Ptable1Row4Value;
    @api themeOneCard2Ptable1Row5Value;
    @api themeOneCard2Ptable1Row6Value;
    @api themeOneCard2Ptable1Row7Value;
    @api themeOneCard2Ptable1Row8Value;
    @api themeOneCard2Ptable1Row9Value;
    @api themeOneCard2Ptable1Row10Value;

    @api themeOneCard2PtableButtonBackgroundColor;
    @api themeOneCard2PtableButtonText;
    @api themeOneCard2PtableButtonTextColor;
    @api themeOneCard2PtableButtonRenderURL;

    // Card 3
    @api themeOneCard3BackgroundColor;
    @api themeOneCard3DesignColor;
    @api themeOneCard3Ptable1Title;
    @api themeOneCard3Ptable1Price;
    @api themeOneCard3Ptable1Row1Value;
    @api themeOneCard3Ptable1Row2Value;
    @api themeOneCard3Ptable1Row3Value;
    @api themeOneCard3Ptable1Row4Value;
    @api themeOneCard3Ptable1Row5Value;
    @api themeOneCard3Ptable1Row6Value;
    @api themeOneCard3Ptable1Row7Value;
    @api themeOneCard3Ptable1Row8Value;
    @api themeOneCard3Ptable1Row9Value;
    @api themeOneCard3Ptable1Row10Value;

    @api themeOneCard3PtableButtonBackgroundColor;
    @api themeOneCard3PtableButtonText;
    @api themeOneCard3PtableButtonTextColor;
    @api themeOneCard3PtableButtonRenderURL;


    // Theme 2 

    @api themeTwoHeader;
    @api themeTwoHeaderFontColor;
    @api themeTwoHeaderFontFamily;

    @api themeTwoHeaderLabel1Value;
    @api themeTwoHeaderLabel2Value;

    // Even Card
    @api themeTwoEvenCardBackgoundColor;

    // Odd Card
    @api themeTwoOddCardBackgoundColor;

    @api themeTwoCardBodyFontFamily;
    @api themeTwoCardBodyFontColor;

    @api themeTwoHeaderCard1AnnualPrice;
    @api themeTwoHeaderCard2AnnualPrice;
    @api themeTwoHeaderCard3AnnualPrice;


    connectedCallback() {
        // console.log('themeType: ', this.themeType);
        if (this.themeType == 'Theme 1') {
            this.template1 = true;
            this.template2 = false;
        }
        else {
            this.template1 = false;
            this.template2 = true;
        }
    }

    handelClickFun() {
        let basic = this.template.querySelector(".basic");
        let professional = this.template.querySelector(".professional");
        let master = this.template.querySelector(".master");
        let checkbox = this.template.querySelector(".checkbox");

        console.log('checkbox: ', checkbox.checked);

        if (checkbox.checked) {
            basic.textContent = '$'+this.themeTwoHeaderCard1AnnualPrice;
            professional.textContent = '$'+this.themeTwoHeaderCard2AnnualPrice;
            master.textContent = '$'+this.themeTwoHeaderCard3AnnualPrice;
        }
        else{
            basic.textContent = '$'+this.themeOneCard1Ptable1Price;
            professional.textContent = '$'+this.themeOneCard2Ptable1Price;
            master.textContent = '$'+this.themeOneCard3Ptable1Price;
        }
    }

    renderedCallback() {
        var css = this.template.host.style;
        
        // Theme One Even Cards
        css.setProperty('--themeOneEvenCardBackgoundColor', this.themeOneEvenCardBackgoundColor);
        css.setProperty('--themeOneEvenCardHeaderBackgroundColor', this.themeOneEvenCardHeaderBackgroundColor);
        css.setProperty('--themeOneEvenCardHeaderPtable1TitleFontFamily', this.themeOneEvenCardHeaderPtable1TitleFontFamily);
        css.setProperty('--themeOneEvenCardHeaderPtable1TitleColor', this.themeOneEvenCardHeaderPtable1TitleColor);
        css.setProperty('--themeOneEvenCardBodyValuesFontFamily', this.themeOneEvenCardBodyValuesFontFamily);
        css.setProperty('--themeOneEvenCardBodyValuesFontColor', this.themeOneEvenCardBodyValuesFontColor);

        // Theme One Odd Card
        css.setProperty('--themeOneOddCardBackgoundColor', this.themeOneOddCardBackgoundColor);
        css.setProperty('--themeOneOddCardHeaderBackgroundColor', this.themeOneOddCardHeaderBackgroundColor);
        css.setProperty('--themeOneOddCardHeaderPtable1TitleFontFamily', this.themeOneOddCardHeaderPtable1TitleFontFamily);
        css.setProperty('--themeOneOddCardHeaderPtable1TitleColor', this.themeOneOddCardHeaderPtable1TitleColor);
        css.setProperty('--themeOneOddCardBodyValuesFontFamily', this.themeOneOddCardBodyValuesFontFamily);
        css.setProperty('--themeOneOddCardBodyValuesFontColor', this.themeOneOddCardBodyValuesFontColor);

        // Theme Two Even Cards
        css.setProperty('--themeTwoEvenCardBackgoundColor', this.themeTwoEvenCardBackgoundColor);

        // Theme Two Odd Card
        css.setProperty('--themeTwoOddCardBackgoundColor', this.themeTwoOddCardBackgoundColor);

        // Header
        css.setProperty('--themeOneHeaderHeading', this.themeOneHeaderHeading);
        css.setProperty('--themeOneHeaderHeadingColor', this.themeOneHeaderHeadingColor);
        css.setProperty('--themeOneHeaderHeadingFontFamily', this.themeOneHeaderHeadingFontFamily);

        // Card 1
        css.setProperty('--themeOneCard1BackgroundColor', this.themeOneCard1BackgroundColor);
        css.setProperty('--themeOneCard1DesignColor', this.themeOneCard1DesignColor);
        css.setProperty('--themeOneCard1Ptable1Title', this.themeOneCard1Ptable1Title);

        css.setProperty('--themeOneCard1PtableButtonBackgroundColor', this.themeOneCard1PtableButtonBackgroundColor);
        css.setProperty('--themeOneCard1PtableButtonTextColor', this.themeOneCard1PtableButtonTextColor);

        // Card2
        css.setProperty('--themeOneCard2BackgroundColor', this.themeOneCard2BackgroundColor);
        css.setProperty('--themeOneCard2DesignColor', this.themeOneCard2DesignColor);
        css.setProperty('--themeOneCard2Ptable1Title', this.themeOneCard2Ptable1Title);

        css.setProperty('--themeOneCard2PtableButtonBackgroundColor', this.themeOneCard2PtableButtonBackgroundColor);
        css.setProperty('--themeOneCard2PtableButtonTextColor', this.themeOneCard2PtableButtonTextColor);

        // Card3
        css.setProperty('--themeOneCard3BackgroundColor', this.themeOneCard3BackgroundColor);
        css.setProperty('--themeOneCard3DesignColor', this.themeOneCard3DesignColor);
        css.setProperty('--themeOneCard3Ptable1Title', this.themeOneCard3Ptable1Title);

        css.setProperty('--themeOneCard3PtableButtonBackgroundColor', this.themeOneCard3PtableButtonBackgroundColor);
        css.setProperty('--themeOneCard3PtableButtonTextColor', this.themeOneCard3PtableButtonTextColor);

        css.setProperty('--themeTwoHeaderFontFamily', this.themeTwoHeaderFontFamily);
        css.setProperty('--themeTwoHeaderFontColor', this.themeTwoHeaderFontColor);


        css.setProperty('--themeTwoCardBodyFontFamily', this.themeTwoCardBodyFontFamily);
        css.setProperty('--themeTwoCardBodyFontColor', this.themeTwoCardBodyFontColor);
    }
}