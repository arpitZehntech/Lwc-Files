import { LightningElement, api } from 'lwc';

export default class CallToAction extends LightningElement {

    @api callToActionThemeOneBackgroundImageURL;

    @api callToActionThemeOneHeading;
    @api callToActionThemeOneHeadingFontColor;
    @api callToActionThemeOneHeadingFontFamily;

    @api callToActionThemeOneSubHeading;
    @api callToActionThemeOneSubHeadingFontColor;
    @api callToActionThemeOneSubHeadingFontFamily;

    @api callToActionThemeOneButtonBorderRadius;
    @api callToActionThemeOneButtonFont;
    @api callToActionThemeOneButtonBackgroundColor;
    @api callToActionThemeOneButtonFontColorOnHover;
    @api callToActionThemeOneButtonColorOnHover;
    @api callToActionThemeOneButtonFontColor;
    @api callToActionThemeOneButtonFontFamily;

    callToActionType1;
    callToActionType2;

    @api selectTheme;

    @api callToActionThemeTwoHeading;
    @api callToActionThemeTwoHeadingFontColor;
    @api callToActionThemeTwoHeadingFontFamily;
    @api callToActionThemeTwoSubHeading;
    @api callToActionThemeTwoSubHeadingFontColor;
    @api callToActionThemeTwoSubHeadingFontFamily;

    @api callToActionThemeTwoButtonBorderRadius;
    @api callToActionThemeTwoButtonFont;
    @api callToActionThemeTwoButtonBackgroundColor;
    @api callToActionThemeTwoButtonFontColorOnHover;
    @api callToActionThemeTwoButtonColorOnHover;
    @api callToActionThemeTwoButtonFontColor;
    @api callToActionThemeTwoButtonFontFamily;


    connectedCallback() {
        console.log('selectTheme: ', this.selectTheme);
        if (this.selectTheme == 'Theme 1') {
            this.callToActionType1 = true;
            this.callToActionType2 = false;
        }
        else {
            this.callToActionType1 = false;
            this.callToActionType2 = true;
        }
    }

    renderedCallback() {
        var css = this.template.host.style;
        if (this.selectTheme == 'Theme 1') {
            css.setProperty('--callToActionHeadingFontColor', this.callToActionThemeOneHeadingFontColor);
            css.setProperty('--callToActionHeadingFontFamily', this.callToActionThemeOneHeadingFontFamily);
            css.setProperty('--callToActionSubHeadingFontColor', this.callToActionThemeOneSubHeadingFontColor);
            css.setProperty('--callToActionSubHeadingFontFamily', this.callToActionThemeOneSubHeadingFontFamily);

            if (this.callToActionThemeOneButtonBorderRadius != '') {
                this.callToActionThemeOneButtonBorderRadius += 'px';
                css.setProperty('--callToActionThemeOneButtonBorderRadius', this.callToActionThemeOneButtonBorderRadius);
                this.template.querySelector('.callToActionThemeOnelanding-page').style.setProperty('--callToActionThemeOneBackgroundImageURL', `url(${this.callToActionThemeOneBackgroundImageURL})`);
            }

            css.setProperty('--callToActionThemeOneButtonFontColor', this.callToActionThemeOneButtonFontColor);
            css.setProperty('--callToActionThemeOneButtonBackgroundColor', this.callToActionThemeOneButtonBackgroundColor);
            css.setProperty('--callToActionThemeOneButtonColorOnHover', this.callToActionThemeOneButtonColorOnHover);
            css.setProperty('--callToActionThemeOneButtonFontColorOnHover', this.callToActionThemeOneButtonFontColorOnHover);
            css.setProperty('--callToActionThemeOneButtonFontFamily', this.callToActionThemeOneButtonFontFamily);
        }
        else {
            css.setProperty('--callToActionThemeTwoHeadingFontColor', this.callToActionThemeTwoHeadingFontColor);
            css.setProperty('--callToActionThemeTwoHeadingFontFamily', this.callToActionThemeTwoHeadingFontFamily);
            css.setProperty('--callToActionThemeTwoSubHeadingFontColor', this.callToActionThemeTwoSubHeadingFontColor);
            css.setProperty('--callToActionThemeTwoSubHeadingFontFamily', this.callToActionThemeTwoSubHeadingFontFamily);

            css.setProperty('--callToActionThemeTwoButtonFontColor', this.callToActionThemeTwoButtonFontColor);
            css.setProperty('--callToActionThemeTwoButtonBackgroundColor', this.callToActionThemeTwoButtonBackgroundColor);
            css.setProperty('--callToActionThemeTwoButtonColorOnHover', this.callToActionThemeTwoButtonColorOnHover);
            css.setProperty('--callToActionThemeTwoButtonFontColorOnHover', this.callToActionThemeTwoButtonFontColorOnHover);
            css.setProperty('--callToActionThemeTwoButtonFontFamily', this.callToActionThemeTwoButtonFontFamily);
            this.callToActionThemeTwoButtonBorderRadius += 'px';
            css.setProperty('--callToActionThemeTwoButtonBorderRadius', this.callToActionThemeTwoButtonBorderRadius);

            const paragraph = this.template.querySelector('.heading');
            console.log('paragraph: ' + paragraph);
            // Get the text content of the paragraph
            const text = paragraph.textContent.trim();
            console.log('text: ' + text);
            // Split the text into words
            const words = text.split(' ');
            // Get the last word
            const lastWord = words[words.length - 1];
            console.log('lastWord: ' + lastWord);

            // Wrap the last word in a span element with a style to set the color to red
            const coloredLastWord = `<span style="color: ${this.callToActionThemeTwoButtonBackgroundColor}">${lastWord}</span>`;

            // Replace the last word in the paragraph with the colored version
            const newText = text.substring(0, text.lastIndexOf(lastWord)) + coloredLastWord;

            // Set the modified text back to the paragraph
            paragraph.innerHTML = newText;
        }
    }
}