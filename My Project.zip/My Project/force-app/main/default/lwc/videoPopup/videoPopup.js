import { LightningElement, api } from 'lwc';

export default class VideoPopup extends LightningElement {

    isVideoPopupOpen = false;
    @api themeOnePopupVideoClickURL = '';
    

    @api themeOneBackgroundImage;
    @api themeOnePopupVideoIcon;
    @api themeOnePopupVideoText;


    openVideoPopup() {
        this.isVideoPopupOpen = true;
    }

    closePopup() {
        this.isVideoPopupOpen = false;
    }

    renderedCallback(){
        var css = this.template.host.style;
        this.template.querySelector('.videoPopupContainer').style.setProperty('--themeOneBackgroundImage', `url(${this.themeOneBackgroundImage})`);
    }
}