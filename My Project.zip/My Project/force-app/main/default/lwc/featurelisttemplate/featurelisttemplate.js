import { LightningElement, api } from 'lwc';

export default class Featurelisttemplate extends LightningElement {


    @api heading = '';
    @api heading1 = '';
    @api heading2 = '';
    @api heading3 = '';
    @api heading4 = '';

    @api selectthemetype;

    template1;
    template2;

    @api content = '';
    @api content1 = '';
    @api content2 = '';
    @api content3 = '';
    @api content4 = '';


    @api headingclr;
    @api heading1clr;
    @api heading2clr;
    @api heading3clr;
    @api heading4clr;
    @api headingsize;

    @api contentclr;
    @api content1clr;
    @api content2clr;
    @api content3clr;
    @api content4clr;

    @api imageurl;
    @api imageurl2;
    @api imageurl3;
    @api imageurl4;
    @api imageurl5;

    @api iconheight;
    @api iconheight1;
    @api iconheight3;
    @api iconheight2;

    @api firstdivclr;
    @api seconddivclr;
    @api thirddivclr;
    @api fourthdivclr;

    @api verticallineclr;
    @api horizentallineclr;

    @api headingfontfamily;
    @api contentfontfamily;

    

    renderedCallback() {

        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingclr", this.headingclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingsize", this.headingsize);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-contentclr", this.contentclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-heading-1clr", this.heading1clr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-content1clr", this.content1clr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-heading-2clr", this.heading2clr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-content2clr", this.content2clr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-heading-3clr", this.heading3clr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-content3clr", this.content3clr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-heading-4clr", this.heading4clr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-content4clr", this.content4clr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-iconheight", this.iconheight);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-iconheight1", this.iconheight1);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-iconheight2", this.iconheight2);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-iconheight3", this.iconheight3);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-firstdivClr", this.firstdivclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-seconddivClr", this.seconddivclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-thirddivClr", this.thirddivclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-fourthdivClr", this.fourthdivclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-verticallineclr", this.verticallineclr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-horizentallineclr", this.horizentallineclr);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingfontfamily", this.headingfontfamily);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-contentfontfamily", this.contentfontfamily);


        //-------------------------------------2themeproperties------------------------------------------------------------



        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingclrtheme2", this.themeheadingclr);


        this.template
            .querySelector("Div")
            .style.setProperty("--contentth2", this.contentth2);

        this.template
            .querySelector("Div")
            .style.setProperty("--headingsizeth2", this.headingsizeth2);

        this.template
            .querySelector("Div")
            .style.setProperty("--contentsizethm2", this.contentsizethm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclrthm2", this.titlecolorthm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretextthm2", this.featurecolorthm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext1thm2", this.featurecolor1thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext2thm2", this.featurecolor2thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext3thm2", this.featurecolor3thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext4thm2", this.featurecolor4thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext5thm2", this.featurecolor5thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext6thm2", this.featurecolor6thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--featuretext7thm2", this.featurecolor7thm2);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-titleclr1thm2", this.titlecolor1thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr2thm2", this.titlecolor2thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr3thm2", this.titlecolor3thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr4thm2", this.titlecolor4thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr5thm2", this.titlecolor5thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr6thm2", this.titlecolor6thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--titleclr7thm2", this.titlecolor7thm2);


        this.template
            .querySelector("Div")
            .style.setProperty("--backgroundcircleclrthm2", this.backgroundcircleclrthm2);


        this.template
            .querySelector("Div")
            .style.setProperty("--backgroundcircleclr1thm2", this.backgroundcircleclr1thm2);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingfontfamilytheme2", this.th2headingfontfamily);


        this.template
            .querySelector("Div")
            .style.setProperty("--my-featurefontfamilythm2", this.featurefontfamilyth2);


    }



    connectedCallback() {
        if (this.selectthemetype == 'Theme 1') {
            this.template1 = true;
            this.template2 = false;
        } else {
            this.template1 = false;
            this.template2 = true;
        }
    }


    //---------------------------------------Second component js---------------------------//


    @api theme2heading = '';
    @api theme2content = '';
    @api theme2title = '';
    @api theme2feature = '';
    @api theme2title2 = '';
    @api theme2feature2 = '';
    @api theme2title3 = '';
    @api theme2feature3 = '';
    @api theme2title4 = '';
    @api theme2feature4 = '';

    @api theme2title5 = '';
    @api theme2feature5 = '';
    @api theme2title6 = '';
    @api theme2feature6 = '';
    @api theme2title7 = '';
    @api theme2feature7 = '';
    @api theme2title8 = '';
    @api theme2feature8 = '';
    @api theme2imageurl = '';
    @api theme2imageicon = '';
    @api theme2imageicon1 = '';
    @api theme2imageicon2 = '';
    @api theme2imageicon3 = '';
    @api theme2imageicon4 = '';
    @api theme2imageicon5 = '';
    @api theme2imageicon6 = '';
    @api theme2imageicon7 = '';



    @api contentth2;
    @api contentsizethm2;


    @api themeheadingclr;
    @api headingsizeth2;
    @api titlecolorthm2;
    @api titlecolor1thm2;
    @api titlecolor2thm2;
    @api titlecolor3thm2;
    @api titlecolor4thm2;
    @api titlecolor5thm2;
    @api titlecolor6thm2;
    @api titlecolor7thm2;

    @api featurecolorthm2;
    @api featurecolor1thm2;
    @api featurecolor2thm2;
    @api featurecolor3thm2;
    @api featurecolor4thm2;
    @api featurecolor5thm2;
    @api featurecolor6thm2;
    @api featurecolor7thm2;
    @api backgroundcircleclrthm2;
    @api backgroundcircleclr1thm2;

    @api th2headingfontfamily;
    @api featurefontfamilyth2;

   // renderedCallback() {

        // this.template
        //     .querySelector("h1")
        //     .style.setProperty("--my-headingclrtheme2", this.themeheadingclr);


        // this.template
        //     .querySelector("p")
        //     .style.setProperty("--Contentth2", this.Contentth2);

        // this.template
        //     .querySelector("h1")
        //     .style.setProperty("--headingsizeth2", this.headingsizeth2);

        // this.template
        //     .querySelector("p")
        //     .style.setProperty("--contentsizethm2", this.contentsizethm2);

        // this.template
        //     .querySelector("h5")
        //     .style.setProperty("--titleclrthm2", this.titlecolorthm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretextthm2", this.featurecolorthm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext1thm2", this.featurecolor1thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext2thm2", this.featurecolor2thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext3thm2", this.featurecolor3thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext4thm2", this.featurecolor4thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext5thm2", this.featurecolor5thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext6thm2", this.featurecolor6thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--featuretext7thm2", this.featurecolor7thm2);


        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--my-titleclr1thm2", this.titlecolor1thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr2thm2", this.titlecolor2thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr3thm2", this.titlecolor3thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr4thm2", this.titlecolor4thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr5thm2", this.titlecolor5thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr6thm2", this.titlecolor6thm2);

        // this.template
        //     .querySelector("Div")
        //     .style.setProperty("--titleclr7thm2", this.titlecolor7thm2);


        // this.template
        // .querySelector("Div")
        // .style.setProperty("--backgroundcircleclrthm2", this.backgroundcircleclrthm2);


        // this.template
        // .querySelector("Div")
        // .style.setProperty("--backgroundcircleclr1thm2", this.backgroundcircleclr1thm2);

        // this.template
        // .querySelector("Div")
        // .style.setProperty("--my-headingfontfamilytheme2", this.th2headingfontfamily);


        // this.template
        // .querySelector("Div")
        // .style.setProperty("--my-featurefontfamilythm2", this.featurefontfamilyth2);
  //  }


}