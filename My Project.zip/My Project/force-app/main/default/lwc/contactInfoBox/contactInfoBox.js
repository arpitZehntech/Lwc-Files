import { LightningElement, api, track } from 'lwc';

export default class ContactInfoBox extends LightningElement {
    @api contactInfoBox1Icon;
    @api contactInfoBox1Title;
    @api contactInfoBox1TitleFontColor;
    @api contactInfoBox1TitleFontFamily;
    @api contactInfoBox1SubTitle;
    @api contactInfoBox1SubTitleFontColor;
    @api contactInfoBox1SubTitleFontFamily;

    @api contactInfoBox2Icon;
    @api contactInfoBox2Title;
    @api contactInfoBox2SubTitle;


    @api contactInfoBox3Icon;
    @api contactInfoBox3Title;
    @api contactInfoBox3SubTitle;

    @api contactInfoBox1IconOnHover;
    @api contactInfoBox2IconOnHover;
    @api contactInfoBox3IconOnHover;

    @api section1stHalfImg;
    @api section2ndHalfMainHeading;
    @api mainHeadingColor;

    @api section2ndHalfImg;
    @api section1StHalfMainHeading;
    @api mainHeadingColor2;

    @api selectTheme;
    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;


    connectedCallback() {

        if (this.selectTheme === 'Theme 1') {
            this.showhideFirst = true;
            this.showhideSecond = false;
            this.showhideThird = false;

        } else if (this.selectTheme === 'Theme 2') {
            this.showhideSecond = true;
            this.showhideFirst = false;
            this.showhideThird = false;

        }
        else if (this.selectTheme === 'Theme 3') {
            this.showhideSecond = false;
            this.showhideFirst = false;
            this.showhideThird = true;

        }
    }

    renderedCallback() {
        var css = this.template.host.style;

        css.setProperty('--contactInfoBox1TitleFontColor', this.contactInfoBox1TitleFontColor);
        css.setProperty('--contactInfoBox1TitleFontFamily', this.contactInfoBox1TitleFontFamily);

        css.setProperty('--contactInfoBox1SubTitleFontColor', this.contactInfoBox1SubTitleFontColor);
        css.setProperty('--contactInfoBox1SubTitleFontFamily', this.contactInfoBox1SubTitleFontFamily);

        css.setProperty('--mainHeadingColor', this.mainHeadingColor);

        css.setProperty('--mainHeadingColor2', this.mainHeadingColor2);


    }

    handleFunction11() {
        this.template.querySelector('.imgIcon1').src = this.contactInfoBox1Icon;
    }

    handleFunction1() {
        this.template.querySelector('.imgIcon1').src = this.contactInfoBox1IconOnHover;
    }

    handleFunction12() {
        this.template.querySelector('.imgIcon2').src = this.contactInfoBox2Icon;
    }

    handleFunction2() {
        this.template.querySelector('.imgIcon2').src = this.contactInfoBox2IconOnHover;
    }

    handleFunction13() {
        this.template.querySelector('.imgIcon3').src = this.contactInfoBox3Icon;
    }

    handleFunction3() {
        this.template.querySelector('.imgIcon3').src = this.contactInfoBox3IconOnHover;
    }
}