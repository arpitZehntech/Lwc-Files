import { LightningElement, track, api } from 'lwc';
// import bgImage from '@salesforce/resourceUrl/bgImage';

export default class TestingCMP extends LightningElement {
    @api selectTheme;
    @track popupOpen = false;
    @track videoSrc = '';
    @track bgImage = '';
    @track showhideFirst = false;
    @track showhideSecond = false;

    connectedCallback() {
        this.bgImage = 'https://wpmet.com/plugin/elementskit/wp-content/uploads/2021/06/call_to_action21.jpg" description="Image Should be 1600X480';
        if (this.selectTheme === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectTheme === 'Theme 2') {
            this.showhideSecond = true;
        } 

        this.hasText = !!this.buttonText;
    }


    openPopup() {
        this.popupOpen = true;
        this.videoSrc = 'https://www.youtube.com/embed/qIjZqxqDTNM?rel=0&showinfo=0'; // Set your video source here
    }

    closePopup() {
        this.popupOpen = false;
        this.videoSrc = '';
    }

    get popupStyle() {
        return this.popupOpen ? 'visibility: visible; opacity: 1;' : 'visibility: hidden; opacity: 0;';
    }
    

}