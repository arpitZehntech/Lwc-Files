import City from '@salesforce/schema/Lead.City';
import { LightningElement, api } from 'lwc';
import flightCarousel from '@salesforce/resourceUrl/flightCarousel';
import {loadStyle} from 'lightning/platformResourceLoader';





export default class Image_tabs extends LightningElement {

    @api url1;
    @api url2;
    @api url3;
    @api url4;
    @api url5;
    
    @api hov_color;
    @api slider_color;
    @api slide1;
    @api slide2;
    @api slide3;
    @api slide4;
    @api slide5;

            handleClick(){
                // this.template.querySelector('.flex-titles').style.visibility = "hidden";
                this.template.querySelector('.city1').style.display = "block";
                this.template.querySelector('.city2').style.display = "none";  
                this.template.querySelector('.city3').style.display = "none";      
                this.template.querySelector('.city4').style.display = "none";      
                this.template.querySelector('.city5').style.display = "none";      
            }

            handleClick1(){
                // this.template.querySelector('.flex-titles').style.visibility = "visible";
                this.template.querySelector('.city1').style.display = "none";
                this.template.querySelector('.city2').style.display = "block";  
                this.template.querySelector('.city3').style.display = "none";      
                this.template.querySelector('.city4').style.display = "none";      
                this.template.querySelector('.city5').style.display = "none";      
            }

            handleClick2(){
                // this.template.querySelector('.flex-titles').style.visibility = "visible";
                this.template.querySelector('.city1').style.display = "none";
                this.template.querySelector('.city2').style.display = "none";  
                this.template.querySelector('.city3').style.display = "block";
                this.template.querySelector('.city4').style.display = "none";      
                this.template.querySelector('.city5').style.display = "none";    
            }

            handleClick3(){
                // this.template.querySelector('.flex-titles').style.visibility = "visible";
                this.template.querySelector('.city1').style.display = "none";
                this.template.querySelector('.city2').style.display = "none";  
                this.template.querySelector('.city3').style.display = "none";
                this.template.querySelector('.city4').style.display = "block"; 
                this.template.querySelector('.city5').style.display = "none"; 
            }

            handleClick4(){
                // this.template.querySelector('.flex-titles').style.visibility = "visible";
                this.template.querySelector('.city1').style.display = "none";
                this.template.querySelector('.city2').style.display = "none";  
                this.template.querySelector('.city3').style.display = "none";
                this.template.querySelector('.city4').style.display = "none"; 
                this.template.querySelector('.city5').style.display = "block"; 
            }


        renderedCallback() {

            loadStyle(this, flightCarousel).then(()=>{
                console.log("Loaded Successfully")
        
            }).catch(error=>{
        
                console.log(error, "Error")
        
            });
            this.template.querySelector('.container').style.setProperty("--my-hov", this.hov_color);

            this.template.querySelector('.container').style.setProperty("--my-slider", this.slider_color);
        }
}