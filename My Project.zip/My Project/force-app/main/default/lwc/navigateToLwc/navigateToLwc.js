import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation'
// import communityId from '@salesforce/community/Id';
// Get the base path for navigating to non-named pages
// import communityBasePath from '@salesforce/community/basePath';

export default class NavigateToLwc extends NavigationMixin(LightningElement) {
    navigateToLwc(){ 
        // var defination={ 
        //     componentDef:'c:navigationLwcTarget',
        //     attributes: { 
        //         recordId:'768766686686'
        //     }
        // }
        this[NavigationMixin.Navigate]({ 
            type:'comm__namedPage',
            attributes: { 
                name:'TemplatePage__c'
            },
            state:{
                c__recordId: '8989789',
                c__positionName:'Salesforce  Developer'
            }
        })  

    }
    
    // currentcommunityId;
    // currentcommunityBasePath;

    // connectedCallback() {
    //     this.currentcommunityId = communityId;
    //     this.currentcommunityBasePath = communityBasePath;
       
    // }

    
}