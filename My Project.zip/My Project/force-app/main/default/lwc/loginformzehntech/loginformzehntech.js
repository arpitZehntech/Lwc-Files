import { LightningElement, api, track, wire } from "lwc";
import getManagedContentByContentKeys from "@salesforce/apex/fileuploadnetwork_3.getContent";
import doLogin from "@salesforce/apex/CommunityAuthControllerException.doLogin";
//import createUser from "@salesforce/apex/AutocreatedRegHandler1671081346714.createUser";
// import forwardToAuthPage from "@salesforce/apex/CommunitiesLoginController.forwardToAuthPage";
import basePath from "@salesforce/community/basePath";
import { loadStyle } from "lightning/platformResourceLoader";
import bstrap from "@salesforce/resourceUrl/loginFormbstrap";
import { NavigationMixin } from 'lightning/navigation';
var array;
// var emailRegex;

export default class Loginform extends NavigationMixin(LightningElement) {
  @api networkname;
  @api contentId;
  @api imageUrl;
  @api borderradius;
  @api backgroundcolor;
  @api signup;
  @api forgot;
  @track isLoading = false;
  @track reponseerror;
  @api redirect;
  @api hrefgoogle;
  @api containerradius;
  @api divheight;
  @api btnbgcolor;
  @api btnbghover;
  @api imageshow;
  @api nonedisplay;
  @api margintop;
  @api marginbottom;

  username;
  password;

 
  // Image Ejejction Part
  handleClick = () => {
    console.log("You clicked me!");
    console.log("contentId", this.contentkey);
  };
  // CSS Dynamic
  @wire(getManagedContentByContentKeys, {
    contentId: "$contentId",
    page: 0,
    pageSize: 1,
    language: "en_US",
    filterby: "",
    networkName: array
  })
  managedContent({ error, data }) {
    console.log("it entered the function:");
    console.log("Network", this.networkName);
    console.log("contentId", this.contentId);
    if (data) {
      if (data.source) {
        console.log("data", data.source);
        this.imageUrl = basePath + "/sfsites/c" + data.source.url;
      }
    } else if (error) {
      console.log("error:", error);
      // Handle the error.
      this.shanError = error;
    }
  }

  connectedCallback() {
    var meta = document.createElement("meta");
    meta.setAttribute("name", "viewport");
    meta.setAttribute("content", "width=device-width, initial-scale=1.0");
    // document.getElementsByTagName('head')[0].appendChild(meta);
  }

  renderedCallback() {
    array = basePath.split("/")[1];
    // console.log("Array:", array);
    // console.log("Basepath", basePath);
    //console.log("URL index [1]", networkName[1]);
    // console.log("Network", this.networkName);
    // console.log("contentId", this.contentId);

    Promise.all([loadStyle(this, bstrap)]);

    this.template
      .querySelector("div")
      .style.setProperty("--my-radius", this.borderradius);

    this.template
      .querySelector("lightning-layout")
      .style.setProperty("--my-containercolor", this.backgroundcolor);

    this.template
      .querySelector("lightning-layout")
      .style.setProperty("--my-containerradius", this.containerradius);

    this.template
      .querySelector("lightning-layout-item")
      .style.setProperty("--my-containerradius", this.containerradius);

      this.template
      .querySelector("div")
      .style.setProperty("--my-height", this.divheight);

      this.template
      .querySelector("div")
      .style.setProperty("--my-btncolor", this.btnbgcolor);

      this.template
      .querySelector("div")
      .style.setProperty("--my-btnhover", this.btnbghover);

      this.template
      .querySelector("div")
      .style.setProperty("--my-dispaly", this.imageshow);

      this.template
      .querySelector("div")
      .style.setProperty("--my-top", this.margintop);

      this.template
      .querySelector("div")
      .style.setProperty("--my-bottom", this.marginbottom);
  }

  // Value Target
  handleUserNameChange(event) {
    this.username = event.target.value;
    console.log("username", this.username);
  }

  handlePasswordChange(event) {
    this.password = event.target.value;
    console.log("password", this.password);
  }
    // Afetr login 
  handleLoginSuccess() {
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
            url: this.redirect
        }
    });
}

  // Regex
  emailRegex =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  showToast() {
    this.template
      .querySelector("c-toastlogin")
      .showToast("success", "Login Successfully");
  }

  handleLogin(event) {
    this.isLoading = true;
    let frstname = this.template.querySelector(".aaa");
    let lstname = this.template.querySelector(".bbb");

    let searchfrst = frstname.value;
    let searchlst = lstname.value;
    if (this.emailRegex.test(searchfrst)) {
      frstname.setCustomValidity("");
    } else {
      frstname.setCustomValidity("Please Check Email Format");
    }
    frstname.reportValidity();

    if (searchlst) {
      lstname.setCustomValidity("");
    } else {
      lstname.setCustomValidity("Password is required");
    }
    lstname.reportValidity();

    console.log("frt", frstname);

    // checking condition

    if (this.username && this.password) {
      event.preventDefault();

      doLogin({ username: this.username, password: this.password })
        .then((result) => {
          // this.isLoading = false;
          this.showToast();
          // window.open = this.redirect;
          // window.location.replace(this.redirect);
          this.handleLoginSuccess();
          console.log("reeeeeeee",this.redirect);
          console.log("resultssssss", result);
        })
        .catch((error) => {
          // this.isLoading = false;
          this.error = error;
          this.errorCheck = true;
          this.errorMessage = error.body.message;
          this.template
            .querySelector("c-toastlogin")
            .showToast("error", "username or password incorrect");
          console.log("errorsssss", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    }
  }
  googlelogin() {
    // this.template.querySelector('.btn1').innerHTML = "https://zehntech7-dev-ed.my.site.com/Zehntech/services/auth/sso/Google";
    window.open(
      this.hrefgoogle
    );
    // window.location.href = ;
    console.log("google", window.location.href);
  }
}