import { LightningElement } from 'lwc';

export default class Navbar extends LightningElement {}