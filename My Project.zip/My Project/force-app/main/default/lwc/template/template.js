import { LightningElement, api, track, wire } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import templateBootstrap from '@salesforce/resourceUrl/templateBootstrap';
import templatedata from "@salesforce/apex/locationSearch.templatedata_Get";
import { NavigationMixin } from 'lightning/navigation';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCandidateApplication from '@salesforce/apex/CandidateApplicationController.createCandidateApplication';

export default class Template extends NavigationMixin(LightningElement) {

    @api topHeadingBgclr;
    @api topHeadingClr;
    @api topSubHeadingClr;
    @api btnTextClr;
    @api btnBackgroundClr;



    @api position;
    logo;
    @api recordId;
    @track isShowModal = false;

    email = null;
    name = null;
    fileData;
    file;

    connectedCallback() {

        // Add an event listener for the popstate event
        window.addEventListener('popstate', this.handlePopState.bind(this));
        // console.log('connectedCallback');

    }


    // --------------   Priview Button start   -------------- //


    disconnectedCallback() {
        // Remove the event listener when the component is removed
        window.removeEventListener('popstate', this.handlePopState.bind(this));
        // console.log('disconnectedCallback');

    }

    // Define the method to handle the popstate event
    handlePopState(event) {
        // Refresh the page when the system back button is clicked
        location.reload();
    }


    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.recordId = currentPageReference.state.c__divID;
        }
        templatedata({ careerId: this.recordId })
            .then(result => {
                if (result && result.length > 0) {
                    const data = result[0];
                    console.log("data logo url", data.Logo_Url__c);
                    this.position = data.Name;
                    this.logo = data.Logo_Url__c;
                    this.department = data.Department__c;
                    this.Experience = data.Experience__c;
                    this.location = data.Location__c;
                    this.vacancy = data.No_of_Vacancy__c;
                    this.ctc = data.CTC_Slab__c;
                    this.Qualification = data.Qualification__c;
                    this.Responsibilities = data.Key_Responsibilities__c;
                    this.skill = data.Required_Skill_Set__c;
                    this.aboutUs = data.What_you_will_love_about_us__c;
                }
            })
            .catch(error => {
                console.error(JSON.stringify(error));
            });
    }

    renderedCallback() {
        Promise.all([loadStyle(this, templateBootstrap)]);

        const divStyle = this.template.querySelector("Div").style;

        divStyle.setProperty("--my-topHeadingBgclr", this.topHeadingBgclr);
        divStyle.setProperty("--my-topHeadingClr", this.topHeadingClr);
        divStyle.setProperty("--my-topSubHeadingClr", this.topSubHeadingClr);
        divStyle.setProperty("--my-btnBackgroundClr", this.btnBackgroundClr);
        divStyle.setProperty("--my-btnTextClr", this.btnTextClr);


    }

    // showModalBox() {
    //     this.isShowModal = true;
    // }

    showModalBox(event) {
        this.selectedJobTitle = event.currentTarget.dataset.title;
        this.isShowModal = true;
    }


    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleFileChange(event) {
        this.file = event.target.files[0];
    }

    // handleSubmit() {
    //     let jsWrp = {
    //         name : this.name,
    //         email : this.email,
    //         fileName : this.filename,
    //         fileData : this.base64
    //     }
    //     createCandidateApplication({ wrp : jsWrp })
    //         .then(result => {

    //             console.log('Record created successfully');
    //             this.hideModalBox();
    //         })
    //         .catch(error => {
    //             console.error('Error creating record: ' + error.body.message);
    //             console.log('Record created successfully',JSON.stringify(error));
    //         });
    // }

    handleSubmit() {
        let jsWrp = {
            name: this.name,
            email: this.email,
            fileName: this.filename,
            fileData: this.base64,
            positionId: this.selectedJobTitle
        };
        createCandidateApplication({ wrp: jsWrp })
            .then(() => {
                this.hideModalBox();
                this.toast('Record created successfully');
            })
            .catch(error => {
                console.error('Error creating record: ' + error.body.message);
                this.toast('Error creating record');
            });
    }

    openfileUpload(event) {
        const file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = () => {
            var base64 = reader.result.split(',')[1];
            this.filename = file.name;
            this.base64 = base64;
        };
        reader.readAsDataURL(file);
    }

    toast(title) {
        const toastEvent = new ShowToastEvent({
            title,
            variant: 'success'
        });
        this.dispatchEvent(toastEvent);
    }
}