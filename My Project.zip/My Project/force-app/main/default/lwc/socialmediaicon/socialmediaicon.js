import { LightningElement, api } from 'lwc';

export default class Socialmediaicon extends LightningElement {


    @api title = '';

    @api imageurl = '';
    @api imageurl1 = '';
    @api imageurl2 = '';
    @api imageurl3 = '';
    @api imageurl4 = '';

    @api profileurl = '';
    @api profileurl1 = '';
    @api profileurl2 = '';
    @api profileurl3 = '';
    @api profileurl4 = '';

    @api titlefontsize;
    @api titlefontfamily;
    @api titlecolor;
    // @api SelectSlider;


    // showhideFirst = false;
    // showhideSecond = false;
    // showhideThird = false;

    renderedCallback() {

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlefontsize", this.titlefontsize);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlefontfamily", this.titlefontfamily);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlecolor", this.titlecolor);


            // if(this.SelectSlider === '1st Slider'){
            //     this.showhideFirst = true;
            //     console.log('showhideFirst',showhideFirst);
            // } else if(this.SelectSlider === '2nd Slider'){
            //     this.showhideSecond = true;
            //     console.log('showhideSecond',showhideSecond);
            // } else if(this.SelectSlider === '3rd Slider'){
            //     this.showhideThird = true;
            //     console.log('showhideThird',showhideThird);
            // }
    }



}