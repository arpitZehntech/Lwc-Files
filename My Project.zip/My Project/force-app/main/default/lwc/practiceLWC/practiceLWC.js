import { LightningElement, api } from 'lwc';
import bootstrap_css from '@salesforce/resourceUrl/Bootstrap_css';
import TimelineCss from '@salesforce/resourceUrl/practiceLWC';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import getTimelineEvents from '@salesforce/apex/ZTTimeline.getTimelineEvents';
export default class Demo extends LightningElement {
    Zehntech_Timeline__c = [];
    error;
    rowLimit = 5;
    rowOffSet = 0;
    @api lengthofdata;
    @api eventData;
    @api Zehntech_Timeline_Title__c;
    @api Zehntech_Timeline_Date__c;
    @api Timeline_Paragraph__c;
    @api isShowModal = false;
    @api isShowModal2 = false;
    @api timelineBgclr;
    @api popUpheadingclr;
    @api popUpDateBgclr;
    @api popUpDateclr;
    @api selectTheme;
    @api btnbgColor;
    @api btnColor;
    @api theme2btnbgColor;
    @api theme2btnColor;
    @api theme1stHeading;
    @api theme1stHeadingColor;
    @api theme1stSubheading;
    @api theme1stParagraph;
    @api theme2heading;
    @api theme2HeadingClr;
    @api theme2Paragraph;
    @api theme2Subheading;
    @api theme1headingfontsize;
    @api theme2headingfontsize;

    showThemeFirst = false;
    showThemeSecond = false;

    theme1stPopuphandle(event) {
        this.isShowModal = false;
    }

    // PopUpClose() {
    //     console.log('Inside popUpClose');
    //     this.isShowModal = false;
    // }

    connectedCallback() {
        if (this.selectTheme == 'Theme 1') {
            this.showThemeFirst = true;
            this.showThemeSecond = false;
            this.loadData();
        } else if (this.selectTheme == 'Theme 2') {
            this.showThemeSecond = true;
            this.showThemeFirst = false;
            this.loadThemeData2();
        }

    }

    loadData() {
        getTimelineEvents({ limitSize: 5, offset: this.rowOffSet })
            .then(result => {
                if (result) {
                    this.Zehntech_Timeline__c = [...this.Zehntech_Timeline__c, ...result];
                    this.error = undefined;
                    this.lengthofdata = result.length;
                } else {
                    this.error = 'No data found';
                }
            })
            .catch(error => {
                this.error = error;
            });
    }

    loadData() {
        return getTimelineEvents({ limitSize: 5, offset: this.rowOffSet })
            .then(result => {
                console.log('Result : ', result);
                this.lengthofdata = result.length;
                console.log(this.lengthofdata);
                if (result) {
                    let ZTTimelineEvents = this.template.querySelector('.temp');
                    let ZTListEvents;
                    let ZTupdatedRecords = [...this.Zehntech_Timeline__c, ...result];
                    this.Zehntech_Timeline__c = ZTupdatedRecords;
                    this.error = undefined;
                    for (let i = 0; i < result.length; i++) {
                        let title = result[i].Zehntech_Timeline_Title__c;
                        let date = result[i].Zehntech_Timeline_Date__c;
                        let image = result[i].Zehntech_Timeline_Image__c;
                        let description = result[i].Timeline_Paragraph__c;
                        let recordId = result[i].Id;
                        ZTListEvents = `<li class="show">
                    <div class="divClss">
                      <span class="zt_timeline_img"><img src=${image} alt="Components Pics" class="theme1_bnt_more" data-id=${recordId} onclick=popUp(this) style="cursor: pointer;"></span>
                        <h2 class="theme1_bnt_more" data-id=${recordId} onclick=popUp(this)>${title}</h2>
                      <span class="date">${date}</span>
                      <p class="theme1_bnt_more" data-id=${recordId} onclick=popUp(this)>${description}</p>
                      <a class="bnt-more" data-id=${recordId} onclick=popUp(this)>More Details</a>
                    </div>
                  </li>`;
                        ZTTimelineEvents.innerHTML += ZTListEvents;
                    }
                    ZTTimelineEvents.addEventListener('click', (event) => {
                        const target = event.target;       // Check if the clicked element is the "bnt-more" link
                        if (target.classList.contains('bnt-more')) {
                            this.Zehntech_Timeline_Title__c = target.closest('div').querySelector('h2').innerText;
                            this.Timeline_Paragraph__c = target.closest('div').querySelector('p').innerText;
                            this.Zehntech_Timeline_Date__c = target.closest('div').querySelector('.date').innerText;
                            console.log(this.Zehntech_Timeline_Date__c);
                            this.isShowModal = true;
                        } else if (target.classList.contains('theme1_bnt_more')) {
                            this.Zehntech_Timeline_Title__c = target.closest('div').querySelector('h2').innerText;
                            this.Timeline_Paragraph__c = target.closest('div').querySelector('p').innerText;
                            this.Zehntech_Timeline_Date__c = target.closest('div').querySelector('.date').innerText;
                            console.log(this.Zehntech_Timeline_Date__c);
                            this.isShowModal = true;
                        }
                    });

                }
            })
            .catch(error => {
                this.error = error;
                this.Zehntech_Timeline__c = undefined;
            });

    }

    // handleButtonClick() {
    //     this.isShowModal = false;
    // }



    loader() {

        return new Promise((res) => {
            console.log(res);
            setTimeout(() => {
                res();
                const theButton = this.template.querySelector(".save-btn");
                theButton.onclick = async function (event) {
                    event.target.innerHTML = "<div class='loader'></div>";
                    setTimeout(() => {
                        this.innerHTML = 'Load More'
                    }, 2000);
                }
            }, 2100);
        })
    }

    async buttonLoader() {
        await this.loader();
        console.log('Offset : ', this.rowOffSet);
        console.log('data length : ', this.lengthofdata);

        if (this.lengthofdata == 0) {
            this.template.querySelector('.save-btn').style.display = "none";
        }
        else {
            this.rowOffSet += 5;
            this.loadData();
        }
    }

    renderedCallback() {
        Promise.all([
            loadStyle(this, bootstrap_css),
            loadStyle(this, TimelineCss)
        ]).then(() => {
            console.log("All scripts and CSS are loaded. perform any initialization function.")
        })
            .catch(error => {
                console.log("failed to load the scripts");
            });
        this.template.querySelector("div").style.setProperty("--my-timelineBgclr", this.timelineBgclr);
        this.template.querySelector("div").style.setProperty("--my-popUpheadingclr", this.popUpheadingclr);
        this.template.querySelector("div").style.setProperty("--my-popUpDateBgclr", this.popUpDateBgclr);
        this.template.querySelector("div").style.setProperty("--my-popUpDateclr", this.popUpDateclr);
        this.template.querySelector("div").style.setProperty("--my-btnbgColor", this.btnbgColor);
        this.template.querySelector("div").style.setProperty("--my-btnColor", this.btnColor);
        this.template.querySelector("div").style.setProperty("--my-theme1stHeadingColor", this.theme1stHeadingColor);
        this.template.querySelector("div").style.setProperty("--my-theme1stSubheading", this.theme1stSubheading);
        this.template.querySelector("div").style.setProperty("--my-theme2headingClr", this.theme2HeadingClr);
        this.template.querySelector("div").style.setProperty("--my-theme2Subheading", this.theme2Subheading);
        this.template.querySelector("div").style.setProperty("--my-theme2btnbgColor", this.theme2btnbgColor);
        this.template.querySelector("div").style.setProperty("--my-theme2btnColor", this.theme2btnColor);
        this.template.querySelector("div").style.setProperty("--my-theme1headingfontsize",this.theme1headingfontsize);
        this.template.querySelector("div").style.setProperty("--my-theme2headingfontsize",this.theme2headingfontsize);
    }

    // Timeline theme 2 code start here
    handleOverlayClick(event) {
        this.isShowModal2 = false;
    }

    loadThemeData2() {
        getTimelineEvents({ limitSize: 5, offset: this.rowOffSet })
            .then(result => {
                //console.log('demo',result);
                if (result) {
                    this.Zehntech_Timeline__c = [...this.Zehntech_Timeline__c, ...result];
                    this.error = undefined;
                    this.lengthofdata = result.length;
                } else {
                    this.error = 'No data found';
                }
            })
            .catch(error => {
                this.error = error;
            });
    }

    loadThemeData2() {
        return getTimelineEvents({ limitSize: 5, offset: this.rowOffSet })
            .then(result => {
                this.lengthofdata = result.length;
                if (result) {
                    let ZTTimelineEvents = this.template.querySelector('.flex-container');
                    let ZTListEvents;
                    let ZTupdatedRecords = [...this.Zehntech_Timeline__c, ...result];
                    this.Zehntech_Timeline__c = ZTupdatedRecords;
                    this.error = undefined;
                    for (let i = 0; i < result.length; i++) {
                        let title = result[i].Zehntech_Timeline_Title__c;
                        let image = result[i].Zehntech_Timeline_Image__c;
                        let description1 = result[i].Timeline_Paragraph__c;
                        let recordId = result[i].Id;
                        ZTListEvents = `<div class="flex-item">
                    <div class="flex-item-content">
                      <img src=${image} alt="Components Pics" class="theme2_bnt_more" data-id=${recordId} onclick=popUp(this) style="cursor: pointer;">
                      <h4 class="theme2_bnt_more" data-id=${recordId} onclick=popUp(this)>${title}</h4>
                      <p class="theme2_bnt_more" data-id=${recordId} onclick=popUp(this)>${description1}</p>
                    </div>
                  </div>`;
                        ZTTimelineEvents.innerHTML += ZTListEvents;
                    }

                    ZTTimelineEvents.addEventListener('click', (event) => {
                        const target = event.target;  // Check if the clicked element is the "bnt-more" link
                        if (target.classList.contains('theme2_bnt_more')) {
                            this.Zehntech_Timeline_Title__c = target.closest('div').querySelector('h4').innerText;
                            this.Timeline_Paragraph__c = target.closest('div').querySelector('p').innerText;
                            console.log(this.Timeline_Paragraph__c);
                            this.isShowModal2 = true;
                        }
                    });

                }
            })
            .catch(error => {
                this.error = error;
                this.Zehntech_Timeline__c = undefined;
            });

    }

    loaderTheme2() {
        return new Promise((res) => {
            console.log(res);
            setTimeout(() => {
                res();
                const theButton = this.template.querySelector(".theme2Button");
                theButton.onclick = async function (event) {
                    event.target.innerHTML = "<div class='loader'></div>";
                    setTimeout(() => {
                        this.innerHTML = 'Load More'
                    }, 2000);
                }
            }, 2100);
        })
    }

    async buttonLoader2() {
        await this.loaderTheme2();
        console.log('Offset : ', this.rowOffSet);
        console.log('data length : ', this.lengthofdata);

        if (this.lengthofdata == 0) {
            this.template.querySelector('.theme2Button').style.display = "none";
        }
        else {
            this.rowOffSet += 5;
            this.loadThemeData2();
        }
    }

}