import { LightningElement, api, track } from 'lwc';

export default class TeamCards extends LightningElement {
    @api headingTag;
    @api headingTagFontFamily;
    @api headingTagFontColor;

    @api subHeadingTag;
    @api subHeadingFontFamily;
    @api subHeadingFontColor;

    @api evenCardsBlockquotesColor;
    @api oddCardsBlockquotesColor;

    // Card 1
    @api card1ImageURL;
    @api card1Description;
    @api card1TeamMemberName;
    @api card1TeamMemberDesignation;

    // Card 2
    @api card2ImageURL;
    @api card2Description;
    @api card2TeamMemberName;
    @api card2TeamMemberDesignation;

    // Card 3
    @api card3ImageURL;
    @api card3Description;
    @api card3TeamMemberName;
    @api card3TeamMemberDesignation;

    // Card 4
    @api card4ImageURL;
    @api card4Description;
    @api card4TeamMemberName;
    @api card4TeamMemberDesignation;

    // Card 5
    @api card5ImageURL;
    @api card5Description;
    @api card5TeamMemberName;
    @api card5TeamMemberDesignation;

    // Card 6
    @api card6ImageURL;
    @api card6Description;
    @api card6TeamMemberName;
    @api card6TeamMemberDesignation;

    // Card 7
    @api card7ImageURL;
    @api card7Description;
    @api card7TeamMemberName;
    @api card7TeamMemberDesignation;

    // Card 8
    @api card8ImageURL;
    @api card8Description;
    @api card8TeamMemberName;
    @api card8TeamMemberDesignation;

    // Card 9
    @api card9ImageURL;
    @api card9Description;
    @api card9TeamMemberName;
    @api card9TeamMemberDesignation;

    // Card 10
    @api card10ImageURL;
    @api card10Description;
    @api card10TeamMemberName;
    @api card10TeamMemberDesignation;

    // Card 11
    @api card11ImageURL;
    @api card11Description;
    @api card11TeamMemberName;
    @api card11TeamMemberDesignation;

    // Card 12
    @api card12ImageURL;
    @api card12Description;
    @api card12TeamMemberName;
    @api card12TeamMemberDesignation;

    // Card 13
    @api card13ImageURL;
    @api card13Description;
    @api card13TeamMemberName;
    @api card13TeamMemberDesignation;

    // Card 14
    @api card14ImageURL;
    @api card14Description;
    @api card14TeamMemberName;
    @api card14TeamMemberDesignation;

    // Card 15
    @api card15ImageURL;
    @api card15Description;
    @api card15TeamMemberName;
    @api card15TeamMemberDesignation;

    @track showError = false;
    errorMessage;

    connectedCallback() {
        if (this.card1Description) {
            if (this.card1Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card1Description = '';
            }
        }
        else if (this.card2Description) {
            if (this.card2Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card2Description = '';
            }
        }
        else if (this.card3Description) {
            if (this.card3Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card3Description = '';
            }
        }
        else if (this.card4Description) {
            if (this.card4Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card4Description = '';
            }
        }
        else if (this.card5Description) {
            if (this.card5Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card5Description = '';
            }
        }
        else if (this.card6Description) {
            if (this.card6Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card6Description = '';
            }
        }
        else if (this.card7Description) {
            if (this.card7Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card7Description = '';
            }
        }
        else if (this.card8Description) {
            if (this.card8Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card8Description = '';
            }
        }
        else if (this.card9Description) {
            if (this.card9Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card9Description = '';
            }
        }
        else if (this.card10Description) {
            if (this.card10Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card10Description = '';
            }
        }
        else if (this.card11Description) {
            if (this.card11Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card11Description = '';
            }
        }
        else if (this.card12Description) {
            if (this.card12Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card12Description = '';
            }
        }
        else if (this.card13Description) {
            if (this.card13Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card13Description = '';
            }
        }
        else if (this.card14Description) {
            if (this.card14Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card14Description = '';
            }
        }
        else if (this.card15Description) {
            if (this.card15Description.length > 220) {
                this.showError = true;
                this.errorMessage = 'Character limit exceeded of Card 1 Description (220 characters max)';
                this.card15Description = '';
            }
        }
    }

    renderedCallback(){
        var css = this.template.host.style;
        
        css.setProperty('--headingTagFontFamily', this.headingTagFontFamily);
        css.setProperty('--headingTagFontColor', this.headingTagFontColor);
        css.setProperty('--subHeadingFontFamily', this.subHeadingFontFamily);
        css.setProperty('--subHeadingFontColor', this.subHeadingFontColor);
        css.setProperty('--evenCardsBlockquotesColor', this.evenCardsBlockquotesColor);
        css.setProperty('--oddCardsBlockquotesColor', this.oddCardsBlockquotesColor);
    }

    closeModalPopup() {
        this.showError = false;
    }
}