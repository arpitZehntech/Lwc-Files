// import { LightningElement, api } from 'lwc';

// export default class WebinarInfoTimer extends LightningElement {
// @api dateTime;

   
//     intervalId;
//     timeStamp;

//     connectedCallback() {

//         console.log("dateTime :", this.dateTime);
//         // Parse the dateTime value from JSON string
//         const parsedData = JSON.parse(this.dateTime);

//         // Extract the dateTime value from the parsed data
//         const dateTimeValue = parsedData.dateTime;

//         console.log("dateTime value:", dateTimeValue); // Log the parsed dateTime value

//         if (!dateTimeValue) {
//             console.error('DateTime is required.'); // Log error if dateTime is not provided
//             return;
//         }

//         // Convert dateTime to timestamp
//         this.timeStamp = new Date(dateTimeValue).getTime();

//         console.log("Timestamp value:", this.timeStamp); // Log the converted timestamp value

//         // Start the timer
//         this.startTimer();
//     }

    

//     startTimer() {
//         this.intervalId = setInterval(() => {
//             const now = new Date();
//             const diffInMilliseconds = this.timeStamp - now.getTime();

//             // Handle expired timer gracefully
//             if (diffInMilliseconds <= 0) {
//                 clearInterval(this.intervalId);
//                 this.template.querySelector('.bwdwi-webinar-info').textContent = 'Webinar has ended.';
//                 return;
//             }

//             const days = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
//             const hours = Math.floor((diffInMilliseconds % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//             const minutes = Math.floor((diffInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));
//             const seconds = Math.floor((diffInMilliseconds % (1000 * 60)) / 1000);

//             this.template.querySelector('.bwdwi-webinar-info').innerHTML = `
//                 <div>${days} <div>days</div></div>
//                 <div>${hours.toString().padStart(2, '0')} <div>hours</div></div>
//                 <div>${minutes.toString().padStart(2, '0')} <div>minutes</div></div>
//                 <div>${seconds.toString().padStart(2, '0')} <div>seconds</div></div>
//             `;
//         }, 1000);
//     }

//     disconnectedCallback() {
//         // Clear the interval when the component is disconnected
//         if (this.intervalId) {
//             clearInterval(this.intervalId);
//         }
//     }
// }
import { LightningElement, api, track } from 'lwc';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createWebinarAttendee from '@salesforce/apex/WebinarAttendeeController.createAttendeeApplication';

export default class WebinarInfoTimer extends LightningElement {
    @api dateTime;

    @api mainHeading;
    @api mainHeadingClr;
    @api subHeading;
    @api subHeadingClr;

    @api member1Img;
    @api member1Name;
    @api member1Position;

    @api member2Img;
    @api member2Name;
    @api member2Position;

    @api member3Img;
    @api member3Name;
    @api member3Position;

    @api member4Img;
    @api member4Name;
    @api member4Position;

    @api member5Img;
    @api member5Name;
    @api member5Position;

    @api memberImgBorderClr;
    @api memberNameClr;
    @api memberPositionClr;

    @api mainBackgroungClr;

    @api dateTimeZoneClr;

    @api counterDownBackgroungClr;
    @api counterDownTextClr;

    @api buttonClr;
    @api buttonTextClr;
    @api buttonClrOnHover;
    @api buttonTextClrOnHover;

    @api backgroundImageUrlWebinar;

    intervalId;
    timeStamp;
    formattedDateTime;

    get webinarmageStyle() {
        return `background-image: url(${this.backgroundImageUrlWebinar});`;
    }

    ///////   Pop UP js start    /////////
    @track isShowModal = false;
    email = null;
    name = null;
    contact = null;
    

    showModalBox() {
        this.isShowModal = true;
    }

    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }
    
    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleContactChange(event) {
        this.contact = event.target.value; 
    }

    handleSubmit() {
        let jsWrp = {
            name: this.name,
            email: this.email,
            contact: this.contact,
            heading: this.mainHeading,
        };
        createWebinarAttendee({ wrp: jsWrp })
            .then(() => {
                this.hideModalBox();
                this.toast('Record created successfully');
            })
            .catch(error => {
                console.error('Error creating record: ' + error.body.message);
                this.toast('Error creating record');
            });
    }
    

    
    toast(title) {
        const toastEvent = new ShowToastEvent({
            title, 
            variant: 'success'
        });
        this.dispatchEvent(toastEvent);
    }


    
    ///////   Pop UP js End    /////////


    renderedCallback() {
        
        this.template
        .querySelector("div")
        .style.setProperty("--my-mainHeadingClr", this.mainHeadingClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subHeadingClr", this.subHeadingClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-memberImgBorderClr", this.memberImgBorderClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-memberNameClr", this.memberNameClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-memberPositionClr", this.memberPositionClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-mainBackgroungClr", this.mainBackgroungClr);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-dateTimeZoneClr", this.dateTimeZoneClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-counterDownBackgroungClr", this.counterDownBackgroungClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-counterDownTextClr", this.counterDownTextClr);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-buttonClr", this.buttonClr);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-buttonTextClr", this.buttonTextClr);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-buttonClrOnHover", this.buttonClrOnHover);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-buttonTextClrOnHover", this.buttonTextClrOnHover);



        if (!this.member1Img) {
            this.template.querySelector('.member1').style.display = 'none';
        }
        if (!this.member2Img) {
            this.template.querySelector('.member2').style.display = 'none';
        }
        if (!this.member3Img) {
            this.template.querySelector('.member3').style.display = 'none';
        }
        if (!this.member4Img) {
            this.template.querySelector('.member4').style.display = 'none';
        }
        if (!this.member5Img) {
            this.template.querySelector('.member5').style.display = 'none';
        }
    }

    connectedCallback() {


        console.log("dateTime :",this.dateTime);

        const parsedData = JSON.parse(this.dateTime);
        const dateTimeValue = parsedData.dateTime;

        console.log("dateTime value:", dateTimeValue); // Log the parsed dateTime value

        if (!dateTimeValue) {
            console.error('DateTime is required.');
            return;
        }

        this.timeStamp = new Date(dateTimeValue).getTime();
        this.formattedDateTime = new Date(dateTimeValue);

        console.log("timeStamp : ", this.timeStamp);

        console.log("formattedDateTime value:", this.formattedDateTime); // Log the parsed dateTime value
        this.startTimer();
    }

    startTimer() {
        this.intervalId = setInterval(() => {
            const now = new Date();
            const diffInMilliseconds = this.timeStamp - now.getTime();

            if (diffInMilliseconds <= 0) {
                clearInterval(this.intervalId);
                this.template.querySelector('.bwdwi-webinar-info').textContent = 'Webinar has ended.';
                return;
            }

            const days = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diffInMilliseconds % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diffInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diffInMilliseconds % (1000 * 60)) / 1000);

            this.template.querySelector('.bwdwi-webinar-info').innerHTML = `
                <div>${days} <div>days</div></div>
                <div>${hours.toString().padStart(2, '0')} <div>hours</div></div>
                <div>${minutes.toString().padStart(2, '0')} <div>minutes</div></div>
                <div>${seconds.toString().padStart(2, '0')} <div>seconds</div></div>
            `;
        }, 1000);
    }

    disconnectedCallback() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
    }
    
}






