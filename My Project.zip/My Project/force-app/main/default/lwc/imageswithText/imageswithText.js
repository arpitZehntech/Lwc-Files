import { LightningElement, api, track } from 'lwc';


export default class ImageswithText extends LightningElement {

    @api selectTheme;
    @api heading = '';
    @api subheading = '';
    @api headingclr;
    @api imageurl = '';
    @api headingfontfamily;
    @api subheadingfontfamily;
    @api subheadingcolor;
    @api redirectUrl;
    @api redirectContent;


    @track showhideFirst = false;
    @track showhideSecond = false;

        connectedCallback() {
    
        if (this.selectTheme === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectTheme === 'Theme 2') {
            this.showhideSecond = true;
        } 
    }


    renderedCallback() {


        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingclr", this.headingclr);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-headingfontfamily", this.headingfontfamily);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-subheadingfontfamily", this.subheadingfontfamily);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-subheadingcolor", this.subheadingcolor);


    }

}