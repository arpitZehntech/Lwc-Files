import { LightningElement, api } from 'lwc';

export default class ProgressBar extends LightningElement {

    @api progressbarthemetype = 'Theme 1';

    progressbartype1;
    progressbartype2;
    progressbartype3;

    // Theme One Variables
    @api themeoneheaderheadingtag;
    @api themeoneheaderparagraphtag;

    @api themeoneprogressbar1tempValue = "";
    @api themeoneprogressbar2tempValue = "";
    @api themeoneprogressbar3tempValue = "";
    @api themeoneprogressbar4tempValue = "";

    @api themeoneprogressbar1Value = "--value: ";
    @api themeoneprogressbar2Value = "--value: ";
    @api themeoneprogressbar3Value = "--value: ";
    @api themeoneprogressbar4Value = "--value: ";

    @api themeoneh2tag1;
    @api themeoneh2tag2;
    @api themeoneh2tag3;
    @api themeoneh2tag4;

    @api themeoneptag1;
    @api themeoneptag2;
    @api themeoneptag3;
    @api themeoneptag4;

    @api themeonefirstprogressbarfillingcolor;
    @api themeonesecondprogressbarfillingcolor;
    @api themeonethirdprogressbarfillingcolor;
    @api themeonefourthprogressbarfillingcolor;

    @api themeonefirstprogressbarfillingbackgroundcolor;
    @api themeonesecondprogressbarfillingbackgroundcolor;
    @api themeonethirdprogressbarfillingbackgroundcolor;
    @api themeonefourthprogressbarfillingbackgroundcolor;

    @api themeOneheaderheadingtagFontColor;
    @api themeOneheaderheadingFontFamily;
    @api themeOneheaderparagraphtagFontColor;
    @api themeOneheaderparagraphtagFontFamily;

    @api themeOneCardsTitleFontFamily;
    @api themeOneCardsTitleFontColor;
    @api themeOneCardsDescriptionFontFamily;
    @api themeOneCardsDescriptionFontColor;

    // Theme Two Variables

    @api themetwoheaderheadingtag;
    @api themetwoheaderparagraphtag;

    @api themetwoprogressbar1tempValue = "";
    @api themetwoprogressbar2tempValue = "";
    @api themetwoprogressbar3tempValue = "";
    @api themetwoprogressbar4tempValue = "";

    @api themetwoprogressbar1Value = "--value: ";
    @api themetwoprogressbar2Value = "--value: ";
    @api themetwoprogressbar3Value = "--value: ";
    @api themetwoprogressbar4Value = "--value: ";

    @api themetwoh2tag1;
    @api themetwoh2tag1textcolor;

    @api themetwoh2tag2;
    @api themetwoh2tag2textcolor;

    @api themetwoh2tag3;
    @api themetwoh2tag3textcolor;

    @api themetwoh2tag4;
    @api themetwoh2tag4textcolor;


    @api themetwofirstprogressbarfillingcolor;
    @api themetwosecondprogressbarfillingcolor;
    @api themetwothirdprogressbarfillingcolor;
    @api themetwofourthprogressbarfillingcolor;

    @api themetwofirstprogressbarfillingbackgroundcolor;
    @api themetwosecondprogressbarfillingbackgroundcolor;
    @api themetwothirdprogressbarfillingbackgroundcolor;
    @api themetwofourthprogressbarfillingbackgroundcolor;

    @api themetwocard1backgroundcolor;
    @api themetwocard2backgroundcolor;
    @api themetwocard3backgroundcolor;
    @api themetwocard4backgroundcolor;

    @api themetwoheaderheadingFontFamily;
    @api themetwoheaderheadingFontColor;
    @api themetwoheaderparagraphtagFontFamily;
    @api themetwoheaderparagraphtagFontColor;

    connectedCallback() {

        if (this.progressbarthemetype == 'Theme 1') {
            this.progressbartype1 = true;
            this.progressbartype2 = false;
            this.progressbartype3 = false;

            if (this.themeoneprogressbar1tempValue != '') {
                this.themeoneprogressbar1Value += this.themeoneprogressbar1tempValue;
            }
            if (this.themeoneprogressbar2tempValue != '') {
                this.themeoneprogressbar2Value += this.themeoneprogressbar2tempValue;
            }
            if (this.themeoneprogressbar3tempValue != '') {
                this.themeoneprogressbar3Value += this.themeoneprogressbar3tempValue;
            }
            if (this.themeoneprogressbar4tempValue != '') {
                this.themeoneprogressbar4Value += this.themeoneprogressbar4tempValue;
            }

        }
        else {
            this.progressbartype1 = false;
            this.progressbartype2 = true;
            this.progressbartype3 = false;

            if (this.themetwoprogressbar1tempValue != '') {
                this.themetwoprogressbar1Value += this.themetwoprogressbar1tempValue;
            }
            if (this.themetwoprogressbar2tempValue != '') {
                this.themetwoprogressbar2Value += this.themetwoprogressbar2tempValue;
            }
            if (this.themetwoprogressbar3tempValue != '') {
                this.themetwoprogressbar3Value += this.themetwoprogressbar3tempValue;
            }
            if (this.themetwoprogressbar4tempValue != '') {
                this.themetwoprogressbar4Value += this.themetwoprogressbar4tempValue;
            }
        }
    }

    renderedCallback() {
        var css = this.template.host.style;

        // Theme One CSS Properties
        css.setProperty('--themeone--first-progressbar-fillingcolor', this.themeonefirstprogressbarfillingcolor);
        css.setProperty('--themeone--first-progressbar-fillingbackgroundcolor', this.themeonefirstprogressbarfillingbackgroundcolor);

        css.setProperty('--themeone--second-progressbar-fillingcolor', this.themeonesecondprogressbarfillingcolor);
        css.setProperty('--themeone--second-progressbar-fillingbackgroundcolor', this.themeonesecondprogressbarfillingbackgroundcolor);

        css.setProperty('--themeone--third-progressbar-fillingcolor', this.themeonethirdprogressbarfillingcolor);
        css.setProperty('--themeone--third-progressbar-fillingbackgroundcolor', this.themeonethirdprogressbarfillingbackgroundcolor);

        css.setProperty('--themeone--fourth-progressbar-fillingcolor', this.themeonefourthprogressbarfillingcolor);
        css.setProperty('--themeone--fourth-progressbar-fillingbackgroundcolor', this.themeonefourthprogressbarfillingbackgroundcolor);

        // Theme Two CSS Properties
        css.setProperty('--themetwo--first-progressbar-fillingcolor', this.themetwofirstprogressbarfillingcolor);
        css.setProperty('--themetwo--first-progressbar-fillingbackgroundcolor', this.themetwofirstprogressbarfillingbackgroundcolor);

        css.setProperty('--themetwo--second-progressbar-fillingcolor', this.themetwosecondprogressbarfillingcolor);
        css.setProperty('--themetwo--second-progressbar-fillingbackgroundcolor', this.themetwosecondprogressbarfillingbackgroundcolor);

        css.setProperty('--themetwo--third-progressbar-fillingcolor', this.themetwothirdprogressbarfillingcolor);
        css.setProperty('--themetwo--third-progressbar-fillingbackgroundcolor', this.themetwothirdprogressbarfillingbackgroundcolor);

        css.setProperty('--themetwo--fourth-progressbar-fillingcolor', this.themetwofourthprogressbarfillingcolor);
        css.setProperty('--themetwo--fourth-progressbar-fillingbackgroundcolor', this.themetwofourthprogressbarfillingbackgroundcolor);

        css.setProperty('--themeOneheaderheadingtagFontColor', this.themeOneheaderheadingtagFontColor);
        css.setProperty('--themeOneheaderheadingFontFamily', this.themeOneheaderheadingFontFamily);
        css.setProperty('--themeOneheaderparagraphtagFontColor', this.themeOneheaderparagraphtagFontColor);
        css.setProperty('--themeOneheaderparagraphtagFontFamily', this.themeOneheaderparagraphtagFontFamily);

        css.setProperty('-themeOneCardsTitleFontFamily', this.themeOneCardsTitleFontFamily);
        css.setProperty('--themeOneCardsTitleFontColor', this.themeOneCardsTitleFontColor);
        css.setProperty('--themeOneCardsDescriptionFontFamily', this.themeOneCardsDescriptionFontFamily);
        css.setProperty('--themeOneCardsDescriptionFontColor', this.themeOneCardsDescriptionFontColor);

        if (this.progressbarthemetype == 'Theme 2') {
            css.setProperty('--theme-two-backgroundcolor-card1', this.themetwocard1backgroundcolor);
            css.setProperty('--theme-two-backgroundcolor-card2', this.themetwocard2backgroundcolor);
            css.setProperty('--theme-two-backgroundcolor-card3', this.themetwocard3backgroundcolor);
            css.setProperty('--theme-two-backgroundcolor-card4', this.themetwocard4backgroundcolor);
            css.setProperty('--theme-two-h2Tag1color', this.themetwoh2tag1textcolor);
            css.setProperty('--theme-two-h2Tag2color', this.themetwoh2tag2textcolor);
            css.setProperty('--theme-two-h2Tag3color', this.themetwoh2tag3textcolor);
            css.setProperty('--theme-two-h2Tag4color', this.themetwoh2tag4textcolor);
            css.setProperty('--themetwoheaderheadingFontFamily', this.themetwoheaderheadingFontFamily);
            css.setProperty('--themetwoheaderheadingFontColor', this.themetwoheaderheadingFontColor);
            css.setProperty('--themetwoheaderparagraphtagFontFamily', this.themetwoheaderparagraphtagFontFamily);
            css.setProperty('--themetwoheaderparagraphtagFontColor', this.themetwoheaderparagraphtagFontColor);
        }
    }
}