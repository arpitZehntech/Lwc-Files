import { LightningElement } from 'lwc';

export default class WebinarInfoTimer1 extends LightningElement {}