import { LightningElement, api } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';

export default class Maps extends LightningElement {
    mapMarkers;
    zoomLevel;
    listView;

    @api zoomLevel;
    @api mapHeight;

    @api city = '';
    @api country = '';
    @api postalCode = '';
    @api state = '';
    @api street = '';
    @api title = ''
    @api description = '';

    @api cityOne = '';
    @api countryOne = '';
    @api postalCodeOne = '';
    @api stateOne = '';
    @api streetOne = '';
    @api titleOne = ''
    @api descriptionOne = '';

    @api cityTwo = '';
    @api countryTwo = '';
    @api postalCodeTwo = '';
    @api stateTwo = '';
    @api streetTwo = '';
    @api titleTwo = ''
    @api descriptionTwo = '';

    @api cityThree = '';
    @api countryThree = '';
    @api postalCodeThree = '';
    @api stateThree = '';
    @api streetThree = '';
    @api titleThree = ''
    @api descriptionThree = '';

    @api cityFour = '';
    @api countryFour = '';
    @api postalCodeFour = '';
    @api stateFour = '';
    @api streetFour = '';
    @api titleFour = ''
    @api descriptionFour = '';

    connectedCallback() {

        this.mapMarkers = [
            {
                location: {
                    City: this.city,
                    Country: this.country,
                    PostalCode: this.postalCode,
                    State: this.state,
                    Street: this.street
                },
                title: this.title,
                description:
                    this.description,
            },
            {
                location: {
                    City: this.cityOne,
                    Country: this.countryOne,
                    PostalCode: this.postalCodeOne,
                    State: this.stateOne,
                    Street: this.streetOne
                },
                title: this.titleOne,
                description:
                    this.descriptionOne,
            },
            {
                location: {
                    City: this.cityTwo,
                    Country: this.countryTwo,
                    PostalCode: this.postalCodeTwo,
                    State: this.stateTwo,
                    Street: this.streetTwo
                },
                title: this.titleTwo,
                description:
                    this.descriptionTwo,
            },
            {
                location: {
                    City: this.cityThree,
                    Country: this.countryThree,
                    PostalCode: this.postalCodeThree,
                    State: this.stateThree,
                    Street: this.streetThree
                },
                title: this.titleThree,
                description:
                    this.descriptionThree,
            },
            {
                location: {
                    City: this.cityFour,
                    Country: this.countryFour,
                    PostalCode: this.postalCodeFour,
                    State: this.stateFour,
                    Street: this.streetFour
                },
                title: this.titleFour,
                description:
                    this.descriptionFour,
            }
        ];
        this.zoomLevel = this.zoomLevel;
    }

    renderedCallback() {

        const style = document.createElement('style');
        style.innerText = `

        .slds-map_container {
            height: ${this.mapHeight}rem !important;
        }
        .slds-map {
            height: fit-content !important;
            position: relative !important;
            min-width: 23.75rem !important;
            width: 100% !important;
            max-height: max-content !important;
        }
        .slds-coordinates {
            display: none !important;
        }
        `;
        console.log('Style: '+style);
        this.template.querySelector('lightning-map').appendChild(style);
        console.log('-------',this.template.querySelector('lightning-map').appendChild(style));
    }
}