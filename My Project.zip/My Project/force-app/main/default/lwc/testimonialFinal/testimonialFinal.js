// import { LightningElement, track, api } from 'lwc';
// import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
// import FLICK from '@salesforce/resourceUrl/flickity2';
// import showtestimonialList from '@salesforce/apex/testimonialsClass.showtestimonials';

// export default class TestimonialFinal extends LightningElement {
//     @api selectTestimonial;
//     @api heading;
//     @api headingClr;

//     @api subheading;
//     @api subheadingClr;
//     @api headingUndLineClr;
//     @api backgroundclr2;
//     @api cardbackgroundclr;
//     @api cardHeadingclr;
//     @api cardSubHeadingclr;
//     @api backgroundclr3;
//     @api cardbackgroundclr3;

//     @api cardHeadingclr3;
//     @api cardSubHeadingclr3;


//     @track showhideFirst = false;
//     @track showhideSecond = false;
//     @track showhideThird = false;

//     @track carouselItems = [];

//     // Flags to check if Flickity is initialized for each carousel
//     // flickityInitialized1 = false;
//     // flickityInitialized2 = false;
//     // flickityInitialized3 = false;

//     renderedCallback() {
        
//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-headingClr", this.headingClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-subheadingClr", this.subheadingClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-headingUndLineClr", this.headingUndLineClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-backgroundclr2", this.backgroundclr2);
//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardbackgroundclr", this.cardbackgroundclr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardHeadingclr", this.cardHeadingclr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardSubHeadingclr", this.cardSubHeadingclr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-backgroundclr3", this.backgroundclr3);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardbackgroundclr3", this.cardbackgroundclr3);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardHeadingclr3", this.cardHeadingclr3);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-cardSubHeadingclr3", this.cardSubHeadingclr3);



//     }

    

//     connectedCallback() {
//         if (this.selectTestimonial === 'Theme 1') {
//             this.showhideFirst = true;
//         } else if (this.selectTestimonial === 'Theme 2') {
//             this.showhideSecond = true;
//         } else if (this.selectTestimonial === 'Theme 3') {
//             this.showhideThird = true;
//         }
//             // this.loadTestimonials();
//             // this.loadFlickity();
//         this.loadTestimonials().then(() => {
//             this.loadFlickity();
//             console.log("loadFlickity in connectedCallback");
            
//         },2000);
//     }

//     loadTestimonials() {
//         return showtestimonialList()
//             .then(result => {
//                 this.carouselItems = result.map(item => ({
//                     id: item.Id,
//                     name: item.Name,
//                     description: item.Discription__c,
//                     imageUrl: item.image_url__c
//                 }));
//             })
//             .catch(error => {
//                 console.error('Error fetching testimonial data:', error);
//             });
//     }

//     loadFlickity() {
//         Promise.all([
//             loadScript(this, FLICK + '/flickity/jquery.min.js'),
//             loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
//             loadStyle(this, FLICK + '/flickity/flickity.css'),
//         ]).then(() => {

//             this.flickity = new Flickity(this.template.querySelector('[data-flickity]'), {
//               this.initializeFlickity();
//              });
//             // if (!this.flickityInitialized1) {
//                 // this.initializeFlickity('[data-flickity]');
//             //     this.flickityInitialized1 = true;
//             // }
//             // if (this.showhideSecond && !this.flickityInitialized2) {
//             //     this.initializeFlickity('[data-flickity]');
//             //     this.flickityInitialized2 = true;
//             // }
//             // if (this.showhideThird && !this.flickityInitialized3) {
//             //     this.initializeFlickity('[data-flickity]');
//             //     this.flickityInitialized3 = true;
//             // }
//         }).catch(error => {
//             console.error('Error loading Flickity resources:', error);
//         });
//     }


//     initializeFlickity(selector) {
//         $(this.template.querySelector(selector)).flickity({
//             prevNextButtons: true,
//             draggable: true,
//             pageDots: false,
//             groupCells: false,
//             wrapAround: true,
//             contain:true,
//             autoPlay:true

//         });
//     }
// }


import { LightningElement, track, api } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity2';
import showtestimonialList from '@salesforce/apex/testimonialsClass.showtestimonials';

export default class TestimonialFinal extends LightningElement {
  @api selectTestimonial;
  @api heading;
  @api headingClr;

  @api subheading;
  @api subheadingClr;
  @api headingUndLineClr;
  @api backgroundclr2;
  @api cardbackgroundclr;
  @api cardHeadingclr;
  @api cardSubHeadingclr;
  @api backgroundclr3;
  @api cardbackgroundclr3;
  @api cardHeadingclr3;
  @api cardSubHeadingclr3;

  @track showhideFirst = false;
  @track showhideSecond = false;
  @track showhideThird = false;
  @track carouselItems = [];

  connectedCallback() {
    if (this.selectTestimonial === 'Theme 1') {
      this.showhideFirst = true;
    } else if (this.selectTestimonial === 'Theme 2') {
      this.showhideSecond = true;
    } else if (this.selectTestimonial === 'Theme 3') {
      this.showhideThird = true;
    }

    Promise.all([this.loadTestimonials(), this.loadFlickityResources()])
      .then(() => this.initializeFlickity('[data-flickity]'))
      .catch(error => {
        console.error('Error loading resources:', error);
      });
  }

  loadFlickityResources() {
    return Promise.all([
      loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
      loadStyle(this, FLICK + '/flickity/flickity.css'),
    ]);
  }

  renderedCallback() {
      
    this.updateStyleVariables();
}

  updateStyleVariables() {
    const divElement = this.template.querySelector('div');
    if (divElement) {
        divElement.style.setProperty('--my-headingClr', this.headingClr);
        divElement.style.setProperty('--my-subheadingClr', this.subheadingClr);
        divElement.style.setProperty('--my-headingUndLineClr', this.headingUndLineClr);
        divElement.style.setProperty('--my-backgroundclr2', this.backgroundclr2);
        divElement.style.setProperty('--my-cardbackgroundclr', this.cardbackgroundclr);
        divElement.style.setProperty('--my-cardHeadingclr', this.cardHeadingclr);
        divElement.style.setProperty('--my-cardSubHeadingclr', this.cardSubHeadingclr);
        divElement.style.setProperty('--my-backgroundclr3', this.backgroundclr3);
        divElement.style.setProperty('--my-cardbackgroundclr3', this.cardbackgroundclr3);
        divElement.style.setProperty('--my-cardHeadingclr3', this.cardHeadingclr3);
        divElement.style.setProperty('--my-cardSubHeadingclr3', this.cardSubHeadingclr3);
    }
}

  loadTestimonials() {
    return showtestimonialList()
      .then(result => {
        this.carouselItems = result.map(item => ({
          id: item.Id,
          name: item.Name,
          description: item.Discription__c,
          imageUrl: item.image_url__c,
        }));
      })
      .catch(error => {
        console.error('Error fetching testimonial data:', error);
      });
  }

  initializeFlickity(selector) {
    const flickityOptions = {
      prevNextButtons: true,
      draggable: true,
      pageDots: false,
      groupCells: false,
      wrapAround: true,
      contain: true,
      autoPlay: true,
    };

    // Assuming Flickity supports direct usage without jQuery
    const flickityInstance = new Flickity(this.template.querySelector(selector), flickityOptions);
  }
}






// import { LightningElement, track, api } from 'lwc';
// import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
// import FLICK from '@salesforce/resourceUrl/flickity2';
// import showtestimonialList from '@salesforce/apex/testimonialsClass.showtestimonials';

// export default class TestimonialFinal extends LightningElement {
//     @api selectTestimonial;
//     @api heading;
//     @api headingClr;
//     @api subheading;
//     @api subheadingClr;
//     @api headingUndLineClr;
//     @api backgroundclr2;
//     @api cardbackgroundclr;
//     @api cardHeadingclr;
//     @api cardSubHeadingclr;
//     @api backgroundclr3;
//     @api cardbackgroundclr3;
//     @api cardHeadingclr3;
//     @api cardSubHeadingclr3;

//     @track showhideFirst = false;
//     @track showhideSecond = false;
//     @track showhideThird = false;
//     @track carouselItems = [];

//     flickityInitialized1 = false;
//     flickityInitialized2 = false;
//     flickityInitialized3 = false;

//     renderedCallback() {
//         this.applyStyles();
//     }

//     connectedCallback() {

//         if (this.selectTestimonial === 'Theme 1') {
//             this.showhideFirst = true;
//         } else if (this.selectTestimonial === 'Theme 2') {
//             this.showhideSecond = true;
//         } else if (this.selectTestimonial === 'Theme 3') {
//             this.showhideThird = true;
//         }

//         this.loadTestimonials();
       
//     }

//     applyStyles() {
//         const styleVariables = {
//             '--my-headingClr': this.headingClr,
//             '--my-subheadingClr': this.subheadingClr,
//             '--my-headingUndLineClr': this.headingUndLineClr,
//             '--my-backgroundclr2': this.backgroundclr2,
//             '--my-cardbackgroundclr': this.cardbackgroundclr,
//             '--my-cardHeadingclr': this.cardHeadingclr,
//             '--my-cardSubHeadingclr': this.cardSubHeadingclr,
//             '--my-backgroundclr3': this.backgroundclr3,
//             '--my-cardbackgroundclr3': this.cardbackgroundclr3,
//             '--my-cardHeadingclr3': this.cardHeadingclr3,
//             '--my-cardSubHeadingclr3': this.cardSubHeadingclr3
//         };

//         const divElement = this.template.querySelector('div');
//         if (divElement) {
//             Object.keys(styleVariables).forEach(key => {
//                 divElement.style.setProperty(key, styleVariables[key]);
//             });
//         }
//     }

//     loadTestimonials() {
//         showtestimonialList()
//             .then(result => {
//                 this.carouselItems = result.map(item => ({
//                     id: item.Id,
//                     name: item.Name,
//                     description: item.Discription__c,
//                     imageUrl: item.image_url__c
//                 }));

//                 this.loadFlickity();
//             })
//             .catch(error => {
//                 console.error('Error fetching testimonial data:', error);
//             });
//     }


//     loadFlickity() {
//         Promise.all([
//             loadScript(this, FLICK + '/flickity/jquery.min.js'),
//             loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
//             loadStyle(this, FLICK + '/flickity/flickity.css'),
//         ]).then(() => {
//             if (this.showhideFirst && !this.flickityInitialized1) {
//                 this.initializeFlickity('.carousel1');
//                 this.flickityInitialized1 = true;
//             }
//             if (this.showhideSecond && !this.flickityInitialized2) {
//                 this.initializeFlickity('[data-flickity]');
//                 this.flickityInitialized2 = true;
//             }
//             if (this.showhideThird && !this.flickityInitialized3) {
//                 this.initializeFlickity('div[class="carousel3"]');
//                 this.flickityInitialized3 = true;
//             }
//         }).catch(error => {
//             console.error('Error loading Flickity resources:', error);
//         });
//     }


//     initializeFlickity(selector) {
//         const flickityContainer = this.template.querySelector(selector);
//         if (flickityContainer) {
//             const flickityInstance = new flickity(flickityContainer, {
//                 prevNextButtons: true,
//                 draggable: true,
//                 pageDots: false,
//                 groupCells: false,
//                 wrapAround: true,
//                 contain:true,
//                 autoPlay:true
//             });
//         } else {
//             console.error(`Flickity container element not found for selector: ${selector}`);
//         }
//     }
    
// }