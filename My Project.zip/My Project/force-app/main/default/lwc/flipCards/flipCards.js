import { LightningElement, api } from 'lwc';

export default class FlipCards extends LightningElement {

    // @api flipCardCard1FrontImageUrl = 'background-image: url(https://images.unsplash.com/photo-1707699097343-7df8074b05c9?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=418&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1MjY5Ng&ixlib=rb-4.0.3&q=80&w=300)';
    // @api flipCardCard1FrontImageUr2 = 'background-image: url(https://images.unsplash.com/photo-1709062856146-6cc9dcdbb2cf?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=402&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1MjQ3MQ&ixlib=rb-4.0.3&q=80&w=300)';
    // @api flipCardCard1FrontImageUr3 = 'background-image: url(https://images.unsplash.com/photo-1708348244831-07e906ded4ae?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=418&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1Mjg2Mw&ixlib=rb-4.0.3&q=80&w=300)';
    // @api flipCardCard1FrontImageUr4 = 'background-image: url(https://images.unsplash.com/photo-1709279305829-0ed92560abb9?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=418&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1NDkyOQ&ixlib=rb-4.0.3&q=80&w=300)';
    // @api flipCardCard1FrontImageUr5 = 'background-image: url(https://images.unsplash.com/photo-1708233002626-ff54f9e41506?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=418&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1NTA5OA&ixlib=rb-4.0.3&q=80&w=300)';
    // @api flipCardCard1FrontImageUr6 = '';
    // @api flipBoxURL6 = 'background-image: url(https://images.unsplash.com/photo-1704207525603-9961bd5281e0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=418&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxMjA1NTE4MQ&ixlib=rb-4.0.3&q=80&w=300)';

    // Header
    @api flipCardHeading;
    @api flipCardHeadingFontFamily;
    @api flipCardHeadingFontColor;

    @api flipCardDescription;
    @api flipCardDescriptionFontFamily;
    @api flipCardDescriptionFontColor;

    // Card 1 
    // Front
    flipCard1 = false;
    @api flipCardCard1TempFrontImageUrl = '';
    @api flipCardCard1FrontImageUrl;
    @api flipCardCard1FrontBackgroundColor = '';
    @api flipCardCard1FrontText;
    @api flipCardCard1FrontTextFontColor;
    @api flipCardCard1FrontTextFontFamily;

    // Back
    @api flipCardCard1BackText;
    @api flipCardCard1BackTextFontColor;
    @api flipCardCard1BackTextFontFamily;
    @api flipCardCard1BackTempBackgroundImageURL = '';
    @api flipCardCard1BackBackgroundImageURL;
    @api flipCardCard1BackBackgroundColor = '';

    // Card 2
    // Front
    flipCard2 = false;
    @api flipCardCard2TempFrontImageUrl = '';
    @api flipCardCard2FrontImageUrl;
    @api flipCardCard2FrontBackgroundColor = '';
    @api flipCardCard2FrontText;
    @api flipCardCard2FrontTextFontColor;
    @api flipCardCard2FrontTextFontFamily;

    // Back
    @api flipCardCard2BackText;
    @api flipCardCard2BackTextFontColor;
    @api flipCardCard2BackTextFontFamily;
    @api flipCardCard2BackTempBackgroundImageURL = '';
    @api flipCardCard2BackBackgroundImageURL;
    @api flipCardCard2BackBackgroundColor = '';

    // Card 3
    // Front
    flipCard3 = false;
    @api flipCardCard3TempFrontImageUrl = '';
    @api flipCardCard3FrontImageUrl;
    @api flipCardCard3FrontBackgroundColor = '';
    @api flipCardCard3FrontText;
    @api flipCardCard3FrontTextFontColor;
    @api flipCardCard3FrontTextFontFamily;

    // Back
    @api flipCardCard3BackText;
    @api flipCardCard3BackTextFontColor;
    @api flipCardCard3BackTextFontFamily;
    @api flipCardCard3BackTempBackgroundImageURL = '';
    @api flipCardCard3BackBackgroundImageURL;
    @api flipCardCard3BackBackgroundColor = '';

    // Card 4
    // Front
    flipCard4 = false;
    @api flipCardCard4TempFrontImageUrl = '';
    @api flipCardCard4FrontImageUrl;
    @api flipCardCard4FrontBackgroundColor = '';
    @api flipCardCard4FrontText;
    @api flipCardCard4FrontTextFontColor;
    @api flipCardCard4FrontTextFontFamily;

    // Back
    @api flipCardCard4BackText;
    @api flipCardCard4BackTextFontColor;
    @api flipCardCard4BackTextFontFamily;
    @api flipCardCard4BackTempBackgroundImageURL = '';
    @api flipCardCard4BackBackgroundImageURL;
    @api flipCardCard4BackBackgroundColor = '';

    // Card 5
    // Front
    flipCard5 = false;
    @api flipCardCard5TempFrontImageUrl = '';
    @api flipCardCard5FrontImageUrl;
    @api flipCardCard5FrontBackgroundColor = '';
    @api flipCardCard5FrontText;
    @api flipCardCard5FrontTextFontColor;
    @api flipCardCard5FrontTextFontFamily;

    // Back
    @api flipCardCard5BackText;
    @api flipCardCard5BackTextFontColor;
    @api flipCardCard5BackTextFontFamily;
    @api flipCardCard5BackTempBackgroundImageURL = '';
    @api flipCardCard5BackBackgroundImageURL;
    @api flipCardCard5BackBackgroundColor = '';

    // Card 6
    // Front
    flipCard6 = false;
    @api flipCardCard6TempFrontImageUrl = '';
    @api flipCardCard6FrontImageUrl;
    @api flipCardCard6FrontBackgroundColor = '';
    @api flipCardCard6FrontText;
    @api flipCardCard6FrontTextFontColor;
    @api flipCardCard6FrontTextFontFamily;

    // Back
    @api flipCardCard6BackText;
    @api flipCardCard6BackTextFontColor;
    @api flipCardCard6BackTextFontFamily;
    @api flipCardCard6BackTempBackgroundImageURL = '';
    @api flipCardCard6BackBackgroundImageURL;
    @api flipCardCard6BackBackgroundColor = '';

    // Even & Odd Cards Buttons
    @api evenCardsButtonBackgroundColor;
    @api evenCardsButtonFontColor;
    @api evenCardsButtonFontFamily;
    @api oddCardsButtonBackgroundColor;
    @api oddCardsButtonFontColor;
    @api oddCardsButtonFontFamily;

    // Buttons
    @api card1ButtonText = '';
    @api card1ButtonRenderURL;
    @api card2ButtonText = '';
    @api card2ButtonRenderURL;
    @api card3ButtonText = '';
    @api card3ButtonRenderURL;
    @api card4ButtonText = '';
    @api card4ButtonRenderURL;
    @api card5ButtonText = '';
    @api card5ButtonRenderURL;
    @api card6ButtonText = '';
    @api card6ButtonRenderURL;


    connectedCallback() {

        // Card1
        if (this.flipCardCard1TempFrontImageUrl != '') {
            this.flipCard1 = true;
            this.flipCardCard1FrontImageUrl = `background-image: url('${this.flipCardCard1TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard1FrontBackgroundColor != '') {
            this.flipCard1 = true;
            this.flipCardCard1FrontImageUrl = `background-color: ${this.flipCardCard1FrontBackgroundColor};`;
        }

        if (this.flipCardCard1BackTempBackgroundImageURL != '') {
            console.log('Inside card back if');
            this.flipCardCard1BackBackgroundImageURL = `background-image: url('${this.flipCardCard1BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard1BackBackgroundColor != '') {
            console.log('Inside card back else');
            this.flipCardCard1BackBackgroundImageURL = `background-color: ${this.flipCardCard1BackBackgroundColor};`;
        }


        // Card2
        if (this.flipCardCard2TempFrontImageUrl != '') {
            this.flipCard2 = true;
            this.flipCardCard2FrontImageUrl = `background-image: url('${this.flipCardCard2TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard2FrontBackgroundColor != '') {
            this.flipCard2 = true;
            this.flipCardCard2FrontImageUrl = `background-color: ${this.flipCardCard2FrontBackgroundColor};`;
        }

        if (this.flipCardCard2BackTempBackgroundImageURL != '') {
            this.flipCardCard2BackBackgroundImageURL = `background-image: url('${this.flipCardCard2BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard2BackBackgroundColor != '') {
            this.flipCardCard2BackBackgroundImageURL = `background-color: ${this.flipCardCard2BackBackgroundColor};`;
        }

        // Card3
        if (this.flipCardCard3TempFrontImageUrl != '') {
            //this.flipCardCard1FrontImageUrl = `background-image: url('${this.flipCardCard1TempFrontImageUrl}'); background-color: ${this.flipCardCard1FrontBackgroundColor};`;
            this.flipCard3 = true;
            this.flipCardCard3FrontImageUrl = `background-image: url('${this.flipCardCard3TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard3FrontBackgroundColor != '') {
            this.flipCard3 = true;
            this.flipCardCard3FrontImageUrl = `background-color: ${this.flipCardCard3FrontBackgroundColor};`;
        }

        if (this.flipCardCard3BackTempBackgroundImageURL != '') {
            this.flipCardCard3BackBackgroundImageURL = `background-image: url('${this.flipCardCard3BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard3BackBackgroundColor != '') {
            this.flipCardCard3BackBackgroundImageURL = `background-color: ${this.flipCardCard3BackBackgroundColor};`;
        }

        // Card4
        if (this.flipCardCard4TempFrontImageUrl != '') {
            //this.flipCardCard1FrontImageUrl = `background-image: url('${this.flipCardCard1TempFrontImageUrl}'); background-color: ${this.flipCardCard1FrontBackgroundColor};`;
            this.flipCard4 = true;
            this.flipCardCard4FrontImageUrl = `background-image: url('${this.flipCardCard4TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard4FrontBackgroundColor != '') {
            this.flipCard4 = true;
            this.flipCardCard4FrontImageUrl = `background-color: ${this.flipCardCard4FrontBackgroundColor};`;
        }

        if (this.flipCardCard4BackTempBackgroundImageURL != '') {
            this.flipCardCard4BackBackgroundImageURL = `background-image: url('${this.flipCardCard4BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard4BackBackgroundColor != '') {
            this.flipCardCard4BackBackgroundImageURL = `background-color: ${this.flipCardCard4BackBackgroundColor};`;
        }

        // Card5
        if (this.flipCardCard5TempFrontImageUrl != '') {
            //this.flipCardCard1FrontImageUrl = `background-image: url('${this.flipCardCard1TempFrontImageUrl}'); background-color: ${this.flipCardCard1FrontBackgroundColor};`;
            this.flipCard5 = true;
            this.flipCardCard5FrontImageUrl = `background-image: url('${this.flipCardCard5TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard5FrontBackgroundColor != '') {
            this.flipCard5 = true;
            this.flipCardCard5FrontImageUrl = `background-color: ${this.flipCardCard5FrontBackgroundColor};`;
        }

        if (this.flipCardCard5BackTempBackgroundImageURL != '') {
            this.flipCardCard5BackBackgroundImageURL = `background-image: url('${this.flipCardCard5BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard1BackBackgroundColor != '') {
            this.flipCardCard5BackBackgroundImageURL = `background-color: ${this.flipCardCard5BackBackgroundColor};`;
        }

        // Card6
        if (this.flipCardCard6TempFrontImageUrl != '') {
            //this.flipCardCard1FrontImageUrl = `background-image: url('${this.flipCardCard1TempFrontImageUrl}'); background-color: ${this.flipCardCard1FrontBackgroundColor};`;
            this.flipCard6 = true;
            this.flipCardCard6FrontImageUrl = `background-image: url('${this.flipCardCard6TempFrontImageUrl}');`;
        }
        else if (this.flipCardCard6FrontBackgroundColor != '') {
            this.flipCard6 = true;
            this.flipCardCard6FrontImageUrl = `background-color: ${this.flipCardCard6FrontBackgroundColor};`;
        }

        if (this.flipCardCard6BackTempBackgroundImageURL != '') {
            this.flipCardCard6BackBackgroundImageURL = `background-image: url('${this.flipCardCard6BackTempBackgroundImageURL}');`;
        }
        else if (this.flipCardCard6BackBackgroundColor != '') {
            this.flipCardCard6BackBackgroundImageURL = `background-color: ${this.flipCardCard6BackBackgroundColor};`;
        }
    }


    renderedCallback() {

        var css = this.template.host.style;

        // Header
        css.setProperty('--flipCardHeadingFontFamily', this.flipCardHeadingFontFamily);
        css.setProperty('--flipCardHeadingFontColor', this.flipCardHeadingFontColor);

        css.setProperty('--flipCardDescriptionFontFamily', this.flipCardDescriptionFontFamily);
        css.setProperty('--flipCardDescriptionFontColor', this.flipCardDescriptionFontColor);

        // Card1
        css.setProperty('--flipCardCard1FrontImageUrl', this.flipCardCard1FrontImageUrl);
        css.setProperty('--flipCardCard1FrontBackgroundColor', this.flipCardCard1FrontBackgroundColor);
        css.setProperty('--flipCardCard1FrontTextFontColor', this.flipCardCard1FrontTextFontColor);
        css.setProperty('--flipCardCard1FrontTextFontFamily', this.flipCardCard1FrontTextFontFamily);
        css.setProperty('--flipCardCard1BackTextFontColor', this.flipCardCard1BackTextFontColor);
        css.setProperty('--flipCardCard1BackTextFontFamily', this.flipCardCard1BackTextFontFamily);

        // Card2
        css.setProperty('--flipCardCard2FrontImageUrl', this.flipCardCard2FrontImageUrl);
        css.setProperty('--flipCardCard2FrontBackgroundColor', this.flipCardCard2FrontBackgroundColor);
        css.setProperty('--flipCardCard2FrontTextFontColor', this.flipCardCard2FrontTextFontColor);
        css.setProperty('--flipCardCard2FrontTextFontFamily', this.flipCardCard2FrontTextFontFamily);
        css.setProperty('--flipCardCard2BackTextFontColor', this.flipCardCard2BackTextFontColor);
        css.setProperty('--flipCardCard2BackTextFontFamily', this.flipCardCard2BackTextFontFamily);

        // Card3
        css.setProperty('--flipCardCard3FrontImageUrl', this.flipCardCard3FrontImageUrl);
        css.setProperty('--flipCardCard3FrontBackgroundColor', this.flipCardCard3FrontBackgroundColor);
        css.setProperty('--flipCardCard3FrontTextFontColor', this.flipCardCard3FrontTextFontColor);
        css.setProperty('--flipCardCard3FrontTextFontFamily', this.flipCardCard3FrontTextFontFamily);
        css.setProperty('--flipCardCard3BackTextFontColor', this.flipCardCard3BackTextFontColor);
        css.setProperty('--flipCardCard3BackTextFontFamily', this.flipCardCard3BackTextFontFamily);

        // Card4
        css.setProperty('--flipCardCard4FrontImageUrl', this.flipCardCard4FrontImageUrl);
        css.setProperty('--flipCardCard4FrontBackgroundColor', this.flipCardCard4FrontBackgroundColor);
        css.setProperty('--flipCardCard4FrontTextFontColor', this.flipCardCard4FrontTextFontColor);
        css.setProperty('--flipCardCard4FrontTextFontFamily', this.flipCardCard4FrontTextFontFamily);
        css.setProperty('--flipCardCard4BackTextFontColor', this.flipCardCard4BackTextFontColor);
        css.setProperty('--flipCardCard4BackTextFontFamily', this.flipCardCard4BackTextFontFamily);

        // Card5
        css.setProperty('--flipCardCard5FrontImageUrl', this.flipCardCard5FrontImageUrl);
        css.setProperty('--flipCardCard5FrontBackgroundColor', this.flipCardCard5FrontBackgroundColor);
        css.setProperty('--flipCardCard5FrontTextFontColor', this.flipCardCard5FrontTextFontColor);
        css.setProperty('--flipCardCard5FrontTextFontFamily', this.flipCardCard5FrontTextFontFamily);
        css.setProperty('--flipCardCard5BackTextFontColor', this.flipCardCard5BackTextFontColor);
        css.setProperty('--flipCardCard5BackTextFontFamily', this.flipCardCard5BackTextFontFamily);

        // Card6
        css.setProperty('--flipCardCard6FrontImageUrl', this.flipCardCard6FrontImageUrl);
        css.setProperty('--flipCardCard6FrontBackgroundColor', this.flipCardCard6FrontBackgroundColor);
        css.setProperty('--flipCardCard6FrontTextFontColor', this.flipCardCard6FrontTextFontColor);
        css.setProperty('--flipCardCard6FrontTextFontFamily', this.flipCardCard6FrontTextFontFamily);
        css.setProperty('--flipCardCard6BackTextFontColor', this.flipCardCard6BackTextFontColor);
        css.setProperty('--flipCardCard6BackTextFontFamily', this.flipCardCard6BackTextFontFamily);

        // Even & Odd Cards
        css.setProperty('--evenCardsButtonBackgroundColor', this.evenCardsButtonBackgroundColor);
        css.setProperty('--evenCardsButtonFontColor', this.evenCardsButtonFontColor);
        css.setProperty('--evenCardsButtonFontFamily', this.evenCardsButtonFontFamily);
        css.setProperty('--oddCardsButtonBackgroundColor', this.oddCardsButtonBackgroundColor);
        css.setProperty('--oddCardsButtonFontColor', this.oddCardsButtonFontColor);
        css.setProperty('--oddCardsButtonFontFamily', this.oddCardsButtonFontFamily);
    }


    handleButtonClick1() {
        // window.location.href = this.card1ButtonRenderURL;
        window.open(this.card1ButtonRenderURL, "_blank");
    }
    handleButtonClick2() {
        // window.location.href = this.card2ButtonRenderURL;
        window.open(this.card2ButtonRenderURL, "_blank");
    }
    handleButtonClick3() {
        // window.location.href = this.card3ButtonRenderURL;
        window.open(this.card3ButtonRenderURL, "_blank");
    }
    handleButtonClick4() {
        // window.location.href = this.card4ButtonRenderURL;
        window.open(this.card4ButtonRenderURL, "_blank");
    }
    handleButtonClick5() {
        // window.location.href = this.card5ButtonRenderURL;
        window.open(this.card5ButtonRenderURL, "_blank");
    }
    handleButtonClick6() {
        // window.location.href = this.card6ButtonRenderURL;
        window.open(this.card6ButtonRenderURL, "_blank");
    }
}