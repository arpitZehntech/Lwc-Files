import { LightningElement } from 'lwc';

export default class Testmap extends LightningElement {}