import { LightningElement } from 'lwc';

export default class Career2 extends LightningElement {}