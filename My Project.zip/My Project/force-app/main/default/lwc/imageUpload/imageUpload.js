import { LightningElement, api, wire, track } from 'lwc';
import getManagedContentByContentKeys from "@salesforce/apex/ManagedContentCtrl.getContent"; //testclass:ManagedContentCtrlTest3
import basePath from "@salesforce/community/basePath";
import icons from '@salesforce/resourceUrl/icon';
import { loadStyle } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from "lightning/platformShowToastEvent";




var network;

export default class ImageUpload extends LightningElement {


    @api networkName;
    @api contentId;
    
    @track shanData;
    @track shanError;
    @api communityId;
    @api communitykey;
    
    
    @track imageurl2;

 @api iconspng = '';







    handleClick = () => {
        console.log("You clicked me!");
        console.log("contentId", this.contentkey);
    };

    // 1 profile
    @wire(getManagedContentByContentKeys, {
        contentId: "$contentId",
        page: 0,
        pageSize: 1,
        language: "en_US",
        filterby: "",
        networkName: network

    })

    managedContent({ error, data }) {
        // console.log("it entered the function:");
        if (data) {
            if (data.source) {
                this.imageurl2 = basePath + "/sfsites/c" + data.source.url;
                
            }
        } else if (error) {
            console.log("error:", error);
            // Handle the error.
            this.shanError = error;
        }
    }

    renderedCallback(){


        network = basePath.split("/")[1];
        console.log("network:", network);
        console.log("Basepath", basePath);
        //console.log("URL index [1]", networkName[1]);
        console.log("Network", this.networkName);
        console.log("contentId", this.contentId);
    }



    connectedCallback(){
        Promise.all([

            loadStyle(this, icons + '/icons.css'),
           
        ]).then(() => {
            this.initializeicons();
          })
          .catch((error) => {
            this.dispatchEvent(
              new ShowToastEvent({
                title: "Error loading icons",
                message: error.message,
                variant: "error",
              }),
            );
          });
      
    }





}