import { LightningElement, api } from 'lwc';

export default class Faqs extends LightningElement {
    template1;

    @api themeType;

    @api themeOneHeading;
    @api themeOneHeadingColor;
    @api themeOneHeadingFontFamily;

    @api themeOneFAQsBackgroundColor;
    @api themeOneFAQsBackgroundColorOnHover;

    @api themeOneActiveFAQBackgroundColor;

    @api themeOneQuestionsFontFamily;
    @api themeOneQuestionsFontColor;
    @api themeOneAnswersFontFamily;
    @api themeOneAnswersFontColor;

    @api faqQuestion1;
    @api faqAnswer1;
    faq1Expanded = false;

    @api faqQuestion2;
    @api faqAnswer2;
    faq2Expanded = false;

    @api faqQuestion3;
    @api faqAnswer3;
    faq3Expanded = false;

    @api faqQuestion4;
    @api faqAnswer4;
    faq4Expanded = false;

    @api faqQuestion5;
    @api faqAnswer5;
    faq5Expanded = false;

    @api faqQuestion6;
    @api faqAnswer6;
    faq6Expanded = false;

    @api faqQuestion7;
    @api faqAnswer7;
    faq7Expanded = false;

    @api faqQuestion8;
    @api faqAnswer8;
    faq8Expanded = false;

    @api faqQuestion9;
    @api faqAnswer9;
    faq9Expanded = false;

    @api faqQuestion10;
    @api faqAnswer10;
    faq10Expanded = false;

    @api faqQuestion11;
    @api faqAnswer11;
    faq11Expanded = false;

    @api faqQuestion12;
    @api faqAnswer12;
    faq12Expanded = false;

    @api faqQuestion13;
    @api faqAnswer13;
    faq13Expanded = false;

    @api faqQuestion14;
    @api faqAnswer14;
    faq14Expanded = false;

    @api faqQuestion15;
    @api faqAnswer15;
    faq15Expanded = false;

    @api themeTwoImageURL;

    connectedCallback() {
        if(this.themeType == 'Theme 1'){
            this.template1 = true;
            this.template2 = false;
        }
        else{
            this.template1 = false;
            this.template2 = true;
        }
    }

    handleToggleAccordion(event) {
        const clickedId = event.target.dataset.id;
        console.log('clickedId: ', clickedId);

        // Open the clicked accordion
        if (clickedId === '1') {
            if (this.faq1Expanded) {
                this.faq1Expanded = false;
            }
            else {
                this.faq1Expanded = true;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        } else if (clickedId === '2') {
            if (this.faq2Expanded) {
                this.faq2Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = true;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        } else if (clickedId === '3') {
            if (this.faq3Expanded) {
                this.faq3Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = true;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '4') {
            if (this.faq4Expanded) {
                this.faq4Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = true;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '5') {
            if (this.faq5Expanded) {
                this.faq5Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = true;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '6') {
            if (this.faq6Expanded) {
                this.faq6Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = true;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '7') {
            if (this.faq7Expanded) {
                this.faq7Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = true;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '8') {
            if (this.faq8Expanded) {
                this.faq8Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = true;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '9') {
            if (this.faq9Expanded) {
                this.faq9Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = true;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '10') {
            if (this.faq10Expanded) {
                this.faq10Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = true;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '11') {
            if (this.faq11Expanded) {
                this.faq11Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = true;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '12') {
            if (this.faq12Expanded) {
                this.faq12Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = true;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '13') {
            if (this.faq13Expanded) {
                this.faq13Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = true;
                this.faq14Expanded = false;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '14') {
            if (this.faq14Expanded) {
                this.faq14Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = true;
                this.faq15Expanded = false;
            }
        }
        else if (clickedId === '15') {
            if (this.faq15Expanded) {
                this.faq15Expanded = false;
            }
            else {
                this.faq1Expanded = false;
                this.faq2Expanded = false;
                this.faq3Expanded = false;
                this.faq4Expanded = false;
                this.faq5Expanded = false;
                this.faq6Expanded = false;
                this.faq7Expanded = false;
                this.faq8Expanded = false;
                this.faq9Expanded = false;
                this.faq10Expanded = false;
                this.faq11Expanded = false;
                this.faq12Expanded = false;
                this.faq13Expanded = false;
                this.faq14Expanded = false;
                this.faq15Expanded = true;
            }
        }

    }

    renderedCallback() {
        var css = this.template.host.style;

        css.setProperty('--themeOneHeadingColor', this.themeOneHeadingColor);
        css.setProperty('--themeOneHeadingFontFamily', this.themeOneHeadingFontFamily);
        css.setProperty('--themeOneFAQsBackgroundColor', this.themeOneFAQsBackgroundColor);
        css.setProperty('--themeOneFAQsBackgroundColorOnHover', this.themeOneFAQsBackgroundColorOnHover);
        css.setProperty('--themeOneActiveFAQBackgroundColor', this.themeOneActiveFAQBackgroundColor);
        css.setProperty('--themeOneQuestionsFontFamily', this.themeOneQuestionsFontFamily);
        css.setProperty('--themeOneQuestionsFontColor', this.themeOneQuestionsFontColor);
        css.setProperty('--themeOneAnswersFontFamily', this.themeOneAnswersFontFamily);
        css.setProperty('--themeOneAnswersFontColor', this.themeOneAnswersFontColor);
    }
}