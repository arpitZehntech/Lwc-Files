import { LightningElement, api } from 'lwc';

export default class VideoPlayer extends LightningElement {
    @api videoUrl = 'https://videos.pexels.com/video-files/2239241/2239241-sd_640_360_24fps.mp4';

    handleVideoLoaded() {
        const videoTag = this.template.querySelector('.videoPlayer');
        console.log('videoTag: ' + videoTag);
        if (videoTag) {
            videoTag.play();
        }
    }
}