import { LightningElement, api, track } from 'lwc';
import sendMail from "@salesforce/apex/contactformController.createCustomerQuery";

export default class ContactForm extends LightningElement {



    // shapeImageUrl = 'img/shape.png';

    // formData = {
    //     name: '',
    //     email: '',
    //     phone: '',
    //     message: ''
    // };

    // connectedCallback() {
    //     const inputs = this.template.querySelectorAll('.input');
    //     inputs.forEach(input => {
    //         input.addEventListener('focus', this.focusFunc.bind(this));
    //         input.addEventListener('blur', this.blurFunc.bind(this));
    //     });
    // }

    // focusFunc(event) {
    //     const parent = event.target.parentNode;
    //     parent.classList.add('focus');
    // }

    // blurFunc(event) {
    //     const parent = event.target.parentNode;
    //     if (!event.target.value.trim()) {
    //         parent.classList.remove('focus');
    //     }
    // }

    // handleInputChange(event) {
    //     const fieldName = event.target.name;
    //     const fieldValue = event.target.value;
    //     this.formData = { ...this.formData, [fieldName]: fieldValue };
    // }

    // handleSubmit(event) {
    //     event.preventDefault();
    //     // You can now access the form data from this.formData object
    //     console.log('Form Data:', this.formData);
    // }

    @api cardBackgroundColor;

    @api cardleftsectionHeading;
    @api cardleftsectionSubHeading;

    @api cardleftsectionAddressIcon;
    @api cardleftsectionAddress;

    @api cardleftsectionEmailIcon;
    @api cardleftsectionEmail; 

    @api cardleftsectionPhoneIcon;
    @api cardleftsectionPhone;

    @api cardleftsectionbottomSubHeading;
    @api cardleftsectionbottomSubHeadingIcon1;
    @api cardleftsectionbottomSubHeadingIcon2;
    @api cardleftsectionbottomSubHeadingIcon3;
    @api cardleftsectionbottomSubHeadingIcon4;

    @api cardleftsectionbottomSubHeadingIcon1RenderURL;
    @api cardleftsectionbottomSubHeadingIcon2RenderURL;
    @api cardleftsectionbottomSubHeadingIcon3RenderURL;
    @api cardleftsectionbottomSubHeadingIcon4RenderURL;

    @api customerMailSubject;
    @api customerMailBody;

    @api cardrightsectionBackgroundColor;

    @track showPopup = false;

    @api cardFontFamily;
    @api cardrightsectionHeading;
    @api notificationMessage;


    shapeImageUrl = 'img/shape.png';
    handleSubmit(event) {
        event.preventDefault(); // Prevent default form submission

        // Get input field values
        const username = this.template.querySelector('.username').value;
        const email = this.template.querySelector('.email').value;
        const phone = this.template.querySelector('.phone').value;
        const message = this.template.querySelector('.message').value;

        // Do whatever you want with the captured data
        console.log('Username:', username);
        console.log('Email:', email);
        console.log('Phone:', phone);
        console.log('Message:', message);

        sendMail({username: username, email: email, phoneNumber: phone, message: message })
            .then((result) => {
                let parsedResult = JSON.parse(result);

                if (parsedResult.isRecordInserted == true) {
                    this.showPopup = true;
                    // Automatically close the popup after 3 seconds
                    setTimeout(() => {
                        this.closePopup();
                    }, 3000);
                }
                else{
                    console.log('Error Message: ',parsedResult.resultMessage);
                    this.notificationMessage = parsedResult.resultMessage;
                    this.showPopup = true;
                    setTimeout(() => {
                        this.closePopup();
                    }, 3000);
                }
            })
            .catch((error) => {
                console.log('Error: ', error);
            });
    }

    closePopup() {
        this.resetForm();
        this.showPopup = false;
    }

    resetForm() {
        // Reset form fields after submission
        this.template.querySelector('.username').value = '';
        this.template.querySelector('.email').value = '';
        this.template.querySelector('.phone').value = '';
        this.template.querySelector('.message').value = '';
    }

    renderedCallback() {
        // Ensure that the DOM elements are rendered before accessing them
        if (this.isRendered) {
            return;
        }
        this.isRendered = true;


        const css = this.template.host.style;
        
        css.setProperty('--cardBackgroundColor', this.cardBackgroundColor);
        css.setProperty('--cardrightsectionBackgroundColor', this.cardrightsectionBackgroundColor);
        css.setProperty('--cardFontFamily', this.cardFontFamily);
    }
}