import { LightningElement } from 'lwc';
import getSurvey from "@salesforce/apex/getSurveyDetails.getSurvey";
import updateSUrveyResponse from "@salesforce/apex/getSurveyDetails.updateSurveyResponse";


let quizData
let quizDataArray;
let quiz;
let answerList;
let question;
let footer;
let quizDetails;
let btnSubmit;
let currentQuiz;
let answerArray;
let a_text;
let b_text;
let c_text;
let d_text;
let headingText;
let surveyName;
let currentSurveyQuestion;

export default class Survey extends LightningElement {
    startSurvey = true;

    async connectedCallback() {

        currentQuiz = 0;

        getSurvey()
            .then(result => {
                console.log('Result: ', result);
                surveyName = result[0].Name;

                const surveyQuestions = Array.from(result[0].Survey_Questions__r);

                quizData = surveyQuestions.map(sQuestions => {
                    return {
                        Question: sQuestions.Name,
                        a: sQuestions.Answer_a__c,
                        b: sQuestions.Answer_b__c,
                        c: sQuestions.Answer_c__c,
                        d: sQuestions.Answer_d__c
                    };
                });

                if (this.startSurvey) {

                    quizDataArray = Array.from(quizData);

                    quiz = this.template.querySelector('.quiz-body');
                    answerList = this.template.querySelectorAll('.answer');
                    question = this.template.querySelector('.quizQuestion');
                    footer = this.template.querySelector('.quiz-footer');
                    quizDetails = this.template.querySelector('.quiz-details');
                    btnSubmit = this.template.querySelector('.btn');

                    answerArray = Array.from(answerList);

                    a_text = this.template.querySelector('.a_text');
                    b_text = this.template.querySelector('.b_text');
                    c_text = this.template.querySelector('.c_text');
                    d_text = this.template.querySelector('.d_text');

                    headingText = this.template.querySelector('.header-txt');

                    this.loadSurvey();
                }
            })
            .catch(error => {
                // TODO Error handling
                console.log('Error: ', error);
            });
    }


    async loadSurvey() {

        await this.deSelectAnswer();
        const currentQuizData = quizDataArray[currentQuiz];

        currentSurveyQuestion = currentQuizData.Question;

        headingText.innerHTML = surveyName;

        question.innerText = currentQuizData.Question;
        a_text.innerHTML = currentQuizData.a;
        b_text.innerHTML = currentQuizData.b;
        c_text.innerHTML = currentQuizData.c;
        d_text.innerHTML = currentQuizData.d;

        quizDetails.innerHTML = `<p>${currentQuiz + 1} of ${quizData.length} Questions</p>`;
    }

    async deSelectAnswer() {
        answerArray.forEach((Ans) => {
            Ans.checked = false;
        })
    }

    async getSelected() {
        var selectedAnswer;
        answerArray.forEach((Ans => {
            if (Ans.checked) {
                selectedAnswer = Ans.id;
            }
        }));
        return selectedAnswer;
    }

    async saveResponse() {
        const getAns = await this.getSelected();
        console.log('getAns: ', getAns);
        // Assuming getAns is always in the format "a-48"
        const parts = getAns.split('-');
        const beforeHyphen = parts[0];

        updateSUrveyResponse({ surveyQuestion: currentSurveyQuestion, response: beforeHyphen })
            .then(result => {
                console.log('Is data inserted: ' + result);
                // Parse the JSON string to access properties of the WrapperClass object
                let parsedResult = JSON.parse(result);
                if (parsedResult.isRecordUpdated == true) {
                    currentQuiz++;
                    if (currentQuiz < quizData.length) {
                        if (currentQuiz + 1 == quizData.length) {
                            btnSubmit.innerHTML = 'Submit';
                            this.loadSurvey();
                        } else {
                            this.loadSurvey();
                        }
                    } else {
                        this.startSurvey = false;
                    }
                }
                else{
                    console.log('Error Message: ',parsedResult.resultMessage);
                }
            })
            .catch(error => {
                // TODO Error handling
                console.log('Error: ' + error);
                console.log('Errorrrr: ', JSON.parse(error));
            });
    }
}