import { LightningElement, track, api } from 'lwc';

export default class CounterUp extends LightningElement {
    @api selectCounter;
    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;
    @track showhideFourth = false;

    @api count1;
    @api count2;
    @api count3;
    @api count4;

    number1;
    number2;
    number3;
    number4;

    current1;
    current2;
    current3;
    current4;

    @api title1;
    @api title2;
    @api title3;
    @api title4;

    label1;
    label2;
    label3;
    label4;

    @api logoImg1;
    @api logoImg2;
    @api logoImg3;
    @api logoImg4;

    image1;
    image2;
    image3;
    image4;

    @api boxBgColor1;
    @api boxBgColor2;
    @api boxBgColor3;
    @api boxBgColor4;

    cellBgColor1;
    cellBgColor2;
    cellBgColor3;
    cellBgColor4;

    @api logoBgcolor1;
    @api logoBgcolor2;
    @api logoBgcolor3;
    @api logoBgcolor4;

    imgbgColor1;
    imgbgColor2;
    imgbgColor3;
    imgbgColor4;

    @api mainHeading1;
    @api mainHeading2;
    @api mainHeading3;
    @api mainHeading4;

    @api mainHeading1Clr;
    @api mainHeading2Clr;
    @api mainHeading3Clr;
    @api mainHeading4Clr;

    @api text1;
    @api text2;
    @api text3;
    @api text4;

    @api textClr1;
    @api textClr2;
    @api textClr3;
    @api textClr4;


    @api mainBgColor;
    @api backgroundImg;

    @api boxBgColor;
    @api logoBgcolor;

    @api numberColor1;
    @api numberColor2;
    @api numberColor3;
    @api numberColor4;


    @api titleColor1;
    @api titleColor2;
    @api titleColor3;
    @api titleColor4;

    @track counts = [];

    renderedCallback() {
        
        this.template
        .querySelector("div")
        .style.setProperty("--my-heading1", this.mainHeading1Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading2", this.mainHeading2Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading3", this.mainHeading3Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading4", this.mainHeading4Clr);


    this.template
        .querySelector("div")
        .style.setProperty("--my-text1", this.textClr1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text2", this.textClr2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text3", this.textClr3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text4", this.textClr4);



    this.template
        .querySelector("div")
        .style.setProperty("--my-bgColor", this.mainBgColor);

    this.template
        .querySelector("div")
        .style.setProperty("--my-bgImage", `url(${this.backgroundImg})`);

    this.template
        .querySelector("div")
        .style.setProperty("--my-boxBgColor", this.boxBgColor);

    this.template
        .querySelector("div")
        .style.setProperty("--my-logoBgcolor", this.logoBgcolor);


    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor1", this.numberColor1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor2", this.numberColor2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor3", this.numberColor3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor4", this.numberColor4);



    this.template
        .querySelector("div")
        .style.setProperty("--my-titleColor1", this.titleColor1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-titleColor2", this.titleColor2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-titleColor3", this.titleColor3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-titleColor4", this.titleColor4);
    }

    // setCssVariables() {


    // }

    connectedCallback() {

        this.number1 = this.count1;
        this.number2 = this.count2;
        this.number3 = this.count3;
        this.number4 = this.count4;

        this.current1 = 0;
        this.current2 = 0;
        this.current3 = 0;
        this.current4 = 0;

        this.label1 = this.title1;
        this.label2 = this.title2;
        this.label3 = this.title3;
        this.label4 = this.title4;

        this.image1 = this.logoImg1;
        this.image2 = this.logoImg2;
        this.image3 = this.logoImg3;
        this.image4 = this.logoImg4;

        this.cellBgColor1 = this.boxBgColor1;
        this.cellBgColor2 = this.boxBgColor2;
        this.cellBgColor3 = this.boxBgColor3;
        this.cellBgColor4 = this.boxBgColor4;

        this.imgbgColor1 = this.logoBgcolor1;
        this.imgbgColor2 = this.logoBgcolor2;
        this.imgbgColor3 = this.logoBgcolor3;
        this.imgbgColor4 = this.logoBgcolor4;


        this.counts = [
            this.generateCountItem(this.number1, this.current1, this.label1, this.image1, this.cellBgColor1, this.imgbgColor1),
            this.generateCountItem(this.number2, this.current2, this.label2, this.image2, this.cellBgColor2, this.imgbgColor2),
            this.generateCountItem(this.number3, this.current3, this.label3, this.image3, this.cellBgColor3, this.imgbgColor3),
            this.generateCountItem(this.number4, this.current4, this.label4, this.image4, this.cellBgColor4, this.imgbgColor4),

        ];

        if (this.selectCounter === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectCounter === 'Theme 2') {
            this.showhideSecond = true;
        } else if (this.selectCounter === 'Theme 3') {
            this.showhideThird = true;
        } else if (this.selectCounter === 'Theme 4') {
            this.showhideFourth = true;
        }

        this.startCounters();

    }

    generateCountItem(number, current, label, image, boxBgrColor, imgbgColor) {

        // console.log('Debug: number current fourth', { number, current });

        return {
            number: number,
            current: current,
            label: label,
            image: image,
            boxBg1Color: 'background-color:' + boxBgrColor,
            imgbgColor: 'background-color:' + imgbgColor,
        };
    }

    startCounters() {
        const intervalTime = 20; // Set the default interval time in milliseconds
        const intervalTimeForSmallValues = 100; // Set a faster interval time for values less than 150

        // Find the maximum number of iterations needed to finish all counters at the same time
        const maxIterations = Math.max(...this.counts.map(item => Math.ceil(item.number / 150)));

        // Execute the interval function for each counter
        this.counts.forEach((item) => {
            const incrementValue = Math.ceil(item.number / maxIterations);
            const currentIntervalTime = item.number < 150 ? intervalTimeForSmallValues : intervalTime;

            const intervalFunction = () => {
                const remainingIncrement = item.number - item.current;
                item.current += Math.min(incrementValue, remainingIncrement);

                // Log the current value
                // console.log(`${item.label} Current Value: ${item.current}`);

                if (item.current < item.number) {
                    setTimeout(intervalFunction, currentIntervalTime);
                }
            };

            intervalFunction();
        });
    }


}