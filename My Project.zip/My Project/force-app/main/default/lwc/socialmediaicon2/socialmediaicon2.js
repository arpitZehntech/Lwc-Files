import { LightningElement, api } from 'lwc';

export default class Socialmediaicon2 extends LightningElement {

    @api title = '';

    @api imageurl = '';
    @api imageurl1 = '';
    @api imageurl2 = '';
    @api imageurl3 = '';
    @api imageurl4 = '';

    @api profileurl = '';
    @api profileurl1 = '';
    @api profileurl2 = '';
    @api profileurl3 = '';
    @api profileurl4 = '';

    @api titlefontsize;
    @api titlefontfamily;
    @api titlecolor;

    renderedCallback() {

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlefontsize", this.titlefontsize);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlefontfamily", this.titlefontfamily);

        this.template
            .querySelector("Div")
            .style.setProperty("--my-titlecolor", this.titlecolor);
    }

}