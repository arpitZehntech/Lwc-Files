import { LightningElement, wire, track, api } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';

import career_data from "@salesforce/apex/locationSearch.Career_Get"; // fetch Career data
import Objects_Type from "@salesforce/apex/locationSearch.f_Get_Types"; //fetch location data   
import Objects_Types from "@salesforce/apex/locationSearch.f_Get"; //fetch department data   
import { NavigationMixin } from 'lightning/navigation';
import createCandidateApplication from '@salesforce/apex/CandidateApplicationController.createCandidateApplication';

export default class Career3 extends NavigationMixin(LightningElement) {
    @track isShowModal = false;
    email = null;
    name = null;
    fileData;
    file;
    filename;
    base64;

    
    @api heading;
    @api subheading;
    @api backgroundImageUrl1;

    @api headingClr1;
    @api subHeadingClr1;
    @api filterBackGroundClr;
    @api filterPlaceholderClr;
    @api searchBarBackgroundClr;
    @api searchBarPlaceHolderClr;
    @api searchBarTextClr;

    // @api searchResultMsgClr;

    @api cardHeadingColor;
    @api cardSubHeadingColor;

    @api cardButtonColor;
    @api cardButtonTextColor;
    @api cardButtonBorderColor;
    @api cardButtonColorOnHover;
    @api cardButtonTextColorOnHover;
    @api cardButtonBorderColorOnHover;
    @api cardLeftBorderColorOnHover;


    // @api templatePage1;

    get topBannerBackgoundImg() {
        return `background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${this.backgroundImageUrl1});`;
    }



    renderedCallback() {

        this.template
            .querySelector("div")
            .style.setProperty("--my-headingClr1", this.headingClr1);

        this.template
            .querySelector("div")
            .style.setProperty("--my-subHeadingClr1", this.subHeadingClr1);

        this.template
            .querySelector("div")
            .style.setProperty("--my-filterBackGroundClr", this.filterBackGroundClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-filterPlaceholderClr", this.filterPlaceholderClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarBackgroundClr", this.searchBarBackgroundClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarPlaceHolderClr", this.searchBarPlaceHolderClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarTextClr", this.searchBarTextClr);

        // this.template
        //     .querySelector("div")
        //     .style.setProperty("--my-searchResultMsgClr", this.searchResultMsgClr);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardHeadingColor", this.cardHeadingColor);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardSubHeadingColor", this.cardSubHeadingColor);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonColor", this.cardButtonColor);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonTextColor", this.cardButtonTextColor);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonBorderColor", this.cardButtonBorderColor);


        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonColorOnHover", this.cardButtonColorOnHover);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonTextColorOnHover", this.cardButtonTextColorOnHover);

        this.template
            .querySelector("main")
            .style.setProperty("--my-cardButtonBorderColorOnHover", this.cardButtonBorderColorOnHover);

            this.template
            .querySelector("main")
            .style.setProperty("--my-cardLeftBorderColorOnHover", this.cardLeftBorderColorOnHover);


        const defaultLocation = 'All';
        const defaultDepartment = 'All';
        this.filterData1(defaultLocation, defaultDepartment);
    }




    @track cards = [];
    @track cityNameOptions = [];
    @track deptNameOptions = [];

    @wire(Objects_Type)
    wiredObjectsType({ error, data }) {
        if (data) {
            this.cityNameOptions = [{ label: 'All Locations', value: 'All' }, ...data.map(ele => ({ label: ele.Location__c, value: ele.Location__c }))];
        } else if (error) {
            // Handle error
        }
    }

    @wire(Objects_Types)
    wiredObjectsTypes({ error, data }) {
        if (data) {
            this.deptNameOptions = [{ label: 'All Department', value: 'All' }, ...data.map(ele => ({ label: ele.Department__c, value: ele.Department__c }))];
        } else if (error) {
            // Handle error
        }
    }

    get cityName() {
        return this.cityNameOptions;
    }

    get deptName() {
        return this.deptNameOptions;
    }

    @wire(career_data)
    wiredCareerData({ error, data }) {
        if (data) {
            console.log('Inside wiredCareerData');
            this.cards = data.map(item => ({
                uniqueId: item.Id,
                jobTitle: item.Name,
                departmentName: item.Department__c,
                jobLocation: item.Location__c,
                jobExperience: item.Experience__c,
                avatarSrc: item.Position_Image_Url__c
            }));
        } else if (error) {
            // Handle error
        }
    }

    connectedCallback() {
        window.addEventListener('popstate', this.handlePopState.bind(this));
    }

    disconnectedCallback() {
        window.removeEventListener('popstate', this.handlePopState.bind(this));
    }

    handlePopState(event) {
        location.reload();
    }

    handleLocationChange1(event) {
        const location = event.target.value;
        const department = this.template.querySelector('.department').value;
        this.filterData1(location, department);
    }

    handleDepartmentChange1(event) {
        const department = event.target.value;
        const location = this.template.querySelector('.location').value;
        this.filterData1(location, department);
    }

    filterData1(location, department) {
        const search = this.template.querySelector('.filter').value?.trim().toUpperCase();
        const searchDiv = this.template.querySelector('.card-holder');
        const cards = searchDiv.querySelectorAll('.cardCar2');

        console.log("searchDiv :", searchDiv);

        console.log("cards :", cards);

        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            const cardLocation = card.querySelector('.card-company-location')?.textContent?.trim().toUpperCase() || '';
            const cardDepartment = card.querySelector('.card-company-glassdoor')?.textContent?.trim().toUpperCase() || '';
            const title = cards[i].querySelector('.job-title').innerText.toUpperCase();

            let locationMatch;
            let departmentMatch;

            if (location === 'All') {
                locationMatch = true;
                this.searchPosition1();
            } else {
                locationMatch = location ? cardLocation.toUpperCase().trim() === location.toUpperCase().trim() : true;
            }
            if (department === 'All') {
                departmentMatch = true;
                this.searchPosition1();
            } else {
                departmentMatch = department ? cardDepartment.includes(department.toUpperCase().trim()) : true;
            }

            if (locationMatch && departmentMatch) {
                card.style.display = "";
                this.searchPosition1();
            } else {
                card.style.display = "none";
            }
        }
    }

    searchPosition1() {
        const search = this.template.querySelector('.filter').value?.trim().toUpperCase();
        const location = this.template.querySelector('.location').value?.trim().toUpperCase();
        const department = this.template.querySelector('.department').value?.trim().toUpperCase();

        const searchDiv = this.template.querySelector('.card-holder');
        const cards = searchDiv.querySelectorAll('.cardCar2');
        let resultsFound = 0;

        for (let i = 0; i < cards.length; i++) {
            const cardDept = cards[i].querySelector('.card-company-glassdoor').innerText.trim().toUpperCase();
            const cardLoc = cards[i].querySelector('.card-company-location').innerText.trim().toUpperCase();
            const title = cards[i].querySelector('.job-title').innerText.toUpperCase();

            let titleMatch = title.includes(search);
            let locationMatch = !location || location === 'ALL' || location === cardLoc;
            let departmentMatch = !department || department === 'ALL' || cardDept.includes(department);

            if (titleMatch && locationMatch && departmentMatch) {
                cards[i].style.display = "";
                resultsFound++;
            } else {
                cards[i].style.display = "none";
            }
        }

        const searchResultsMessage = this.template.querySelector('.search-results-message');
        if (resultsFound > 0) {
            searchResultsMessage.textContent = `${resultsFound} Result${resultsFound > 1 ? 's' : ''} found: ${search}`;
        } else {
            searchResultsMessage.textContent = `No results found${search ? ` for "${search}".` : '.'}`;
        }
    }





    handleViewJob(event) {
        // event.preventDefault();
        const jobId = event.target.dataset.id;
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'NewTemplate__c' 
            },
            state: {
                c__divID: jobId
            }
        });
    }

    showModalBox() {
        this.isShowModal = true;
    }

    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleFileChange(event) {
        this.file = event.target.files[0];
    }

    handleSubmit() {
        let jsWrp = {
            name: this.name,
            email: this.email,
            fileName: this.filename,
            fileData: this.base64
        };
        createCandidateApplication({ wrp: jsWrp })
            .then((result) => {
                console.log('Record created successfully');
                this.hideModalBox();
            })
            .catch((error) => {
                console.error('Error creating record: ' + error.body.message);
                console.log('Record created successfully', JSON.stringify(error));
            });
    }

    openfileUpload(event) {
        const file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = () => {
            var base64 = reader.result.split(',')[1];
            this.filename = file.name;
            this.base64 = base64;
        };
        reader.readAsDataURL(file);
    }


}