import { LightningElement, track, api } from 'lwc';

export default class CountdownTimer1 extends LightningElement {

    booleanshowTimmer = true;
    deadline;
    now;
    distance;
    x;
    days;
    hours;
    minutes;
    seconds;

    @api themeType;

    @api contentId;
    @api showcountdowntimer;

    @api themeTwoeventDateTime;


    @track remaningDays;
    @track remaningHours;
    @track remaningMinutes;
    @track remaningSeconds;

    @api themeTwoBackgroundColor;

    @api themeTwoImageURL;
    @api themeTwodescription;

    @api themeTwoFontFamily;
    @api themeTwoFontColor;

    @api themeTwoButton1Text;
    @api themeTwoButton1Color;
    @api themeTwoButton1BackgroundColor;

    @api themeTwoButton2Text;
    @api themeTwoButton2Color;
    @api themeTwoButton2BackgroundColor;

    @api themeTwoEventCountdownColor;

    @api themeTwoButtonHover;
    @api themeTwoButtonHoverFontColor;

    @api themeTwoRenderURLButton1;
    @api themeTwoRenderURLButton2;

    connectedCallback() {
        if (this.themeTwoeventDateTime == "" || this.themeTwoeventDateTime == undefined) {
            this.booleanshowTimmer = false;
            this.remaningDays = "00";
            this.remaningHours = "00";
            this.remaningMinutes = "00";
            this.remaningSeconds = "00";
        } else {
            // Parse the JSON string
            const eventDateTimeObject = JSON.parse(this.themeTwoeventDateTime);
            // console.log(eventDateTimeObject);
            const isoDateString = eventDateTimeObject.dateTime;
            // console.log('isoDateString: ', isoDateString);

            // Convert ISO 8601 date string to timestamp
            this.deadline = Date.parse(isoDateString);
            // console.log('Deadline Timestamp: ', this.deadline);

            // Update the count down every 1 second
            this.x = setInterval(() => {
                // Get the current timestamp
                this.now = new Date().getTime();
                // console.log('Current Timestamp: ', this.now);

                // Find the distance between now and the count down date
                this.distance = Math.floor(this.deadline - this.now);
                // console.log('Distance: ', this.distance);

                this.days = Math.floor(this.distance / (1000 * 60 * 60 * 24));
                this.hours = Math.floor(
                    (this.distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
                );
                this.minutes = Math.floor(
                    (this.distance % (1000 * 60 * 60)) / (1000 * 60)
                );
                this.seconds = Math.floor((this.distance % (1000 * 60)) / 1000);

                if (this.distance > 0) {
                    // console.log('Inside if');
                    // this.remaning_time = `Remaining time: ${this.days} days ${this.hours} hours ${this.minutes} minutes ${this.seconds} seconds`;
                    // console.log('DAYS: ',this.days);
                    // console.log('HOURS: ',this.hours);
                    // console.log('MINUTES: ',this.minutes);

                    if (this.days == 0) {
                        // console.log('Yes Days is zero');
                        this.days = "00";
                        // console.log('Updated Days: ',this.days);
                    }
                    if (this.hours == 0) {
                        // console.log('Yes hours is zero');
                        this.hours = "00";
                        // console.log('Updated Hours: ', this.hours);
                    }
                    if (this.minutes == 0) {
                        // console.log('Yes Minutes is zero');
                        this.minutes = "00";
                        // console.log('Updated Minutes: ', this.minutes);
                    }

                    this.remaningDays = this.days;
                    this.remaningHours = this.hours;
                    this.remaningMinutes = this.minutes;
                    this.remaningSeconds = this.seconds;
                } else {
                    // this.remaning_time = `Event has ended`;
                    this.hideTitle = true;
                    this.remaningDays = "00";
                    this.remaningHours = "00";
                    this.remaningMinutes = "00";
                    this.remaningSeconds = "00";

                    clearInterval(this.x);
                }
            }, 1000); // 1000 milliseconds = 1 second
        }
    }

    renderedCallback(){
        var css = this.template.host.style;
        css.setProperty('--themeTwoBackgroundColor', this.themeTwoBackgroundColor);
        css.setProperty('--themeTwoFontFamily',this.themeTwoFontFamily); 
        css.setProperty('--themeTwoFontColor',this.themeTwoFontColor);

        css.setProperty('--themeTwoButton1Color',this.themeTwoButton1Color);
        css.setProperty('--themeTwoButton1BackgroundColor',this.themeTwoButton1BackgroundColor);

        css.setProperty('--themeTwoButton2Color',this.themeTwoButton2Color);
        css.setProperty('--themeTwoButton2BackgroundColor',this.themeTwoButton2BackgroundColor);

        css.setProperty('--themeTwoEventCountdownColor', this.themeTwoEventCountdownColor);
        css.setProperty('--themeTwoButtonHover',this.themeTwoButtonHover);
        css.setProperty('--themeTwoButtonHoverFontColor',this.themeTwoButtonHoverFontColor);
    }

    button1Submit(){
        window.location.href = this.themeTwoRenderURLButton1;
    }

    button2Submit(){
        window.location.href = this.themeTwoRenderURLButton2;
    }
}