import { LightningElement , api, track} from 'lwc';

export default class Test1 extends LightningElement {

    @api selectTheme;
    @track showhideFirst = false;
    @track showhideSecond = false;

    
    connectedCallback()
    {

        if (this.selectTheme === '1st Theme') {
            this.showhideFirst = true;
        } else if (this.selectTheme === '2nd Theme') {
            this.showhideSecond = true;
        } 
    }


    _test1LayoutProperties;

    @api
    set test1LayoutProperties(value) {
        if (value) {
            this._test1LayoutProperties = JSON.parse(value);
        }
    }

    get test1LayoutProperties() {
        return this._test1LayoutProperties;
    }

    setStyles() {


        if (this.test1LayoutProperties) {

            this.template
            .querySelector("div")
            .style.setProperty("text-align", this.test1LayoutProperties.textAlignment);

            this.template
            .querySelector("div")
            .style.setProperty("border-style", this.test1LayoutProperties.borderStyle);

            this.template
            .querySelector("div")
            .style.setProperty("border-width", this.test1LayoutProperties.borderWeight + 'px');

            this.template
            .querySelector("div")
            .style.setProperty("border-radius", this.test1LayoutProperties.borderRadius + 'px');

            this.template
            .querySelector("div")
            .style.setProperty("font-size", this.test1LayoutProperties.fontSize + 'px');


            // articleCSS.setProperty('text-align', this.test1LayoutProperties.textAlignment);
            // articleCSS.setProperty('border-style', this.test1LayoutProperties.borderStyle);
            // articleCSS.setProperty('border-width', this.test1LayoutProperties.borderWeight + 'px');
            // articleCSS.setProperty('border-radius', this.test1LayoutProperties.borderRadius + 'px');
  
        }
    }

    

    renderedCallback() {
        this.setStyles();

    }



}