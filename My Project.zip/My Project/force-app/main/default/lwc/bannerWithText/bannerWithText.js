import { LightningElement, api } from 'lwc';

export default class BannerWithText extends LightningElement {
    @api containerBackgroundColor;
    @api bannerTextHeading;
    @api bannerTextHeadingColor;
    @api bannerTextHeadingFontFamily;
    @api bannerTextSubHeading;
    @api bannerTextSubHeadingColor;
    @api bannerTextSubHeadingFontFamily;

    renderedCallback(){
        var css =  this.template.host.style;
        css.setProperty('--containerBackgroundColor', this.containerBackgroundColor);
        css.setProperty('--bannerTextHeadingColor', this.bannerTextHeadingColor);
        css.setProperty('--bannerTextHeadingFontFamily', this.bannerTextHeadingFontFamily);
        css.setProperty('--bannerTextSubHeadingColor', this.bannerTextSubHeadingColor);
        css.setProperty('--bannerTextSubHeadingFontFamily', this.bannerTextSubHeadingFontFamily);
    }
}