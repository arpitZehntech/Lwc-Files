

// import { LightningElement, api, track } from 'lwc';

// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import getWebinarData from '@salesforce/apex/WebinarController.getWebinarData';
// import createWebinarAttendee from '@salesforce/apex/WebinarAttendeeController.createAttendeeApplication';

// export default class WebinarTimer extends LightningElement {
//     @api dateTime;

//     @api mainHeading;
//     @api mainHeadingClr;
//     @api subHeading;
//     @api subHeadingClr;

//     @api member1Img;
//     @api member1Name;
//     @api member1Position;

//     @api member2Img;
//     @api member2Name;
//     @api member2Position;

//     @api member3Img;
//     @api member3Name;
//     @api member3Position;

//     @api member4Img;
//     @api member4Name;
//     @api member4Position;

//     @api member5Img;
//     @api member5Name;
//     @api member5Position;

//     @api memberImgBorderClr;
//     @api memberNameClr;
//     @api memberPositionClr;

//     @api mainBackgroungClr;

//     @api dateTimeZoneClr;

//     @api counterDownBackgroungClr;
//     @api counterDownTextClr;

//     @api ButtonText;
//     @api buttonClr;
//     @api buttonTextClr;
//     @api buttonClrOnHover;
//     @api buttonTextClrOnHover;

//     @api backgroundImageUrlWebinar;

//     intervalId;
//     timeStamp;
//     formattedDateTime;

//     get webinarmageStyle() {
//         return `background-image: url(${this.backgroundImageUrlWebinar});`;
//     }

//     ///////   Pop UP js start    /////////
//     @track isShowModal = false;
//     email = null;
//     name = null;
//     contact = null;


//     showModalBox() {
//         this.isShowModal = true;
//     }

//     hideModalBox() {
//         this.isShowModal = false;
//     }

//     handleEmailChange(event) {
//         this.email = event.target.value;
//     }

//     handleNameChange(event) {
//         this.name = event.target.value;
//     }

//     handleContactChange(event) {
//         this.contact = event.target.value; 
//     }

//     handleSubmit() {
//         let jsWrp = {
//             name: this.name,
//             email: this.email,
//             contact: this.contact,
//             heading: this.mainHeading,
//         };
//         createWebinarAttendee({ wrp: jsWrp })
//             .then(() => {
//                 this.hideModalBox();
//                 this.toast('Record created successfully');
//             })
//             .catch(error => {
//                 console.error('Error creating record: ' + error.body.message);
//                 this.toast('Error creating record');
//             });
//     }



//     toast(title) {
//         const toastEvent = new ShowToastEvent({
//             title, 
//             variant: 'success'
//         });
//         this.dispatchEvent(toastEvent);
//     }



//     ///////   Pop UP js End    /////////


//     renderedCallback() {

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-mainHeadingClr", this.mainHeadingClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-subHeadingClr", this.subHeadingClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-memberImgBorderClr", this.memberImgBorderClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-memberNameClr", this.memberNameClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-memberPositionClr", this.memberPositionClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-mainBackgroungClr", this.mainBackgroungClr);


//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-dateTimeZoneClr", this.dateTimeZoneClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-counterDownBackgroungClr", this.counterDownBackgroungClr);

//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-counterDownTextClr", this.counterDownTextClr);


//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-buttonClr", this.buttonClr);


//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-buttonTextClr", this.buttonTextClr);


//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-buttonClrOnHover", this.buttonClrOnHover);


//         this.template
//         .querySelector("div")
//         .style.setProperty("--my-buttonTextClrOnHover", this.buttonTextClrOnHover);



//         if (!this.member1Img) {
//             this.template.querySelector('.member1').style.display = 'none';
//         }
//         if (!this.member2Img) {
//             this.template.querySelector('.member2').style.display = 'none';
//         }
//         if (!this.member3Img) {
//             this.template.querySelector('.member3').style.display = 'none';
//         }
//         if (!this.member4Img) {
//             this.template.querySelector('.member4').style.display = 'none';
//         }
//         if (!this.member5Img) {
//             this.template.querySelector('.member5').style.display = 'none';
//         }
//     }

//     // connectedCallback() {


//     //     console.log("dateTime :",this.dateTime);

//     //     const parsedData = JSON.parse(this.dateTime);
//     //     const dateTimeValue = parsedData.dateTime;

//     //     console.log("dateTime value:", dateTimeValue); // Log the parsed dateTime value

//     //     if (!dateTimeValue) {
//     //         console.error('DateTime is required.');
//     //         return;
//     //     }

//     //     this.timeStamp = new Date(dateTimeValue).getTime();
//     //     this.formattedDateTime = new Date(dateTimeValue);

//     //     console.log("timeStamp : ", this.timeStamp);

//     //     console.log("formattedDateTime value:", this.formattedDateTime); // Log the parsed dateTime value
//     //     this.startTimer();
//     // }

//     connectedCallback() {
//         console.log("dateTime :", this.dateTime);

//         // Check if dateTime is empty or undefined
//         if (!this.dateTime) {
//             console.error('DateTime is empty or undefined.');
//             return;
//         }

//         try {
//             const parsedData = JSON.parse(this.dateTime);
//             const dateTimeValue = parsedData.dateTime;

//             console.log("dateTime value:", dateTimeValue); // Log the parsed dateTime value

//             if (!dateTimeValue) {
//                 console.error('DateTime is required.');
//                 return;
//             }

//             this.timeStamp = new Date(dateTimeValue).getTime();
//             this.formattedDateTime = new Date(dateTimeValue);

//             console.log("timeStamp : ", this.timeStamp);
//             console.log("formattedDateTime value:", this.formattedDateTime); // Log the parsed dateTime value

//             this.startTimer();
//         } catch (error) {
//             console.error('Error parsing dateTime JSON:', error);
//         }
//     }


//     startTimer() {
//         this.intervalId = setInterval(() => {
//             const now = new Date();
//             const diffInMilliseconds = this.timeStamp - now.getTime();

//             if (diffInMilliseconds <= 0) {
//                 clearInterval(this.intervalId);
//                 this.template.querySelector('.bwdwi-webinar-info').textContent = 'Webinar has ended.';
//                 return;
//             }

//             const days = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
//             const hours = Math.floor((diffInMilliseconds % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//             const minutes = Math.floor((diffInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));
//             const seconds = Math.floor((diffInMilliseconds % (1000 * 60)) / 1000);

//             this.template.querySelector('.bwdwi-webinar-info').innerHTML = `
//                 <div>${days} <div>days</div></div>
//                 <div>${hours.toString().padStart(2, '0')} <div>hours</div></div>
//                 <div>${minutes.toString().padStart(2, '0')} <div>minutes</div></div>
//                 <div>${seconds.toString().padStart(2, '0')} <div>seconds</div></div>
//             `;
//         }, 1000);
//     }

//     disconnectedCallback() {
//         if (this.intervalId) {
//             clearInterval(this.intervalId);
//         }
//     }

// }


import { LightningElement, api, track, wire } from 'lwc';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getWebinarData from '@salesforce/apex/WebinarController.getWebinarData';
// import createWebinarAttendee from '@salesforce/apex/WebinarAttendeeController.createAttendeeApplication';

import createWebinarAttendee from '@salesforce/apex/WebinarController.createWebinarAttendee';

export default class WebinarTimer extends LightningElement {

    intervalId;
    timeStamp;
    formattedDateTime;

    @api mainHeadingClr;
    @api subHeadingClr;
    @api memberImgBorderClr;
    @api memberNameClr;
    @api memberPositionClr;
    @api mainBackgroungClr;
    @api dateTimeZoneClr;
    @api counterDownBackgroungClr;
    @api counterDownTextClr;
    @api buttonClr;
    @api buttonTextClr;
    @api buttonClrOnHover;
    @api buttonTextClrOnHover;
    @api backgroundImageUrlWebinar;
    @api buttonText;

    @api locationImgLogo;
    @api locationTextClr;

    mainHeading;
    @track webinarData;

    @wire(getWebinarData)
    wiredWebinarData({ error, data }) {
        if (data) {
            let webinar = data[0].webinar;

            console.log("webinar", webinar.Id);

            const dateTimeValue = webinar.Webinar_Date_and_Time__c;
            const dateTime = new Date(dateTimeValue);

            this.webinarData = {
                webinarId: webinar.Id,
                mainHeading: webinar.Name,
                subHeading: webinar.Subtitle__c,
                dateTime: dateTime,
                address: webinar.Address__c,
                members: data[0].members.map(member => ({
                    name: member.Name,
                    designation: member.Designation__c,
                    imageUrl: member.image_url__c
                }))
            };
        } else if (error) {
            console.error('Error fetching webinar data:', error);
        }
    }





    get webinarmageStyle() {
        return `background-image: url(${this.backgroundImageUrlWebinar});`;
    }

    ///////   Pop UP js start    /////////
    @track isShowModal = false;
    email = null;
    name = null;
    contact = null;


    showModalBox() {
        this.isShowModal = true;
    }

    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleContactChange(event) {
        this.contact = event.target.value;
    }

    //  handleSubmit() {
    //         let jsWrp = {
    //             name: this.name,
    //             email: this.email,
    //             contact: this.contact,
    //             heading: this.webinarData.mainHeading, // Use webinarData instead of mainHeading
    //         };
    //         createWebinarAttendee({ wrp: jsWrp })
    //             .then(() => {
    //                 this.hideModalBox();
    //                 this.toast('Record created successfully');
    //             })
    //             .catch(error => {
    //                 console.error('Error creating record: ' + error.body.message);
    //                 this.toast('Error creating record');
    //             });
    //     }


    // handleSubmit() {
    //     let jsWrp = {
    //         name: this.name,
    //         email: this.email,
    //         contact: this.contact,
    //         heading: this.webinarData.Name, // Use webinarData instead of mainHeading

    //     };
    //     createWebinarAttendee({ wrp: jsWrp })
    //         .then(() => {
    //             this.hideModalBox();
    //             this.toast('Record created successfully');
    //         })
    //         .catch(error => {
    //             console.error('Error creating record: ' + error.body.message);
    //             this.toast('Error creating record');
    //         });
    // }

    handleSubmit() {
        let jsWrp = {
            webinarId: this.webinarData.webinarId,
            name: this.name,
            email: this.email,
            contact: this.contact, // Replace with valid decimal value for contact
            heading: this.webinarData.mainHeading

        };
        console.log('this.name---------->', this.name);
        console.log('this.email---------->', this.email);
        console.log('this.contact---------->', this.contact);
        console.log('this.this.webinarData.Name---------->', this.webinarData.mainHeading);

        console.log("jsWrp :", jsWrp);
        createWebinarAttendee({ wrp: jsWrp })

            .then(() => {
                this.hideModalBox();
                this.toast('Record created successfully');
            })
            .catch(error => {
                console.error('Error creating record: ' + error.body.message);
                this.toast('Error creating record');
            });
    }


    toast(title) {
        const toastEvent = new ShowToastEvent({
            title,
            variant: 'success'
        });
        this.dispatchEvent(toastEvent);
    }



    ///////   Pop UP js End    /////////

    renderedCallback() {


        if (!this.webinarData || !this.webinarData.dateTime) {
            console.error('DateTime is empty or undefined.');
            return;
        }

        try {
            const dateTimeValue = this.webinarData.dateTime;

            this.timeStamp = new Date(dateTimeValue).getTime();
            this.formattedDateTime = new Date(dateTimeValue);

            this.startTimer();
        } catch (error) {
            console.error('Error in parsing dateTime:', error);
        }



        const divElement = this.template.querySelector("div");

        if (!divElement) {
            console.error('Div element not found.');
            return;
        }

        const styleProperties = [
            { name: "--my-mainHeadingClr", value: this.mainHeadingClr },
            { name: "--my-subHeadingClr", value: this.subHeadingClr },
            { name: "--my-memberImgBorderClr", value: this.memberImgBorderClr },
            { name: "--my-memberNameClr", value: this.memberNameClr },
            { name: "--my-memberPositionClr", value: this.memberPositionClr },
            { name: "--my-mainBackgroungClr", value: this.mainBackgroungClr },
            { name: "--my-dateTimeZoneClr", value: this.dateTimeZoneClr },
            { name: "--my-counterDownBackgroungClr", value: this.counterDownBackgroungClr },
            { name: "--my-counterDownTextClr", value: this.counterDownTextClr },
            { name: "--my-buttonClr", value: this.buttonClr },
            { name: "--my-buttonTextClr", value: this.buttonTextClr },
            { name: "--my-buttonClrOnHover", value: this.buttonClrOnHover },
            { name: "--my-buttonTextClrOnHover", value: this.buttonTextClrOnHover },
            { name: "--my-locationTextClr", value: this.locationTextClr }
        ];

        styleProperties.forEach(property => {
            if (property.value) {
                divElement.style.setProperty(property.name, property.value);
            }
        });

    }

    connectedCallback() {

    }



    startTimer() {
        this.intervalId = setInterval(() => {
            const now = new Date();
            const diffInMilliseconds = this.timeStamp - now.getTime();

            if (diffInMilliseconds <= 0) {
                clearInterval(this.intervalId);
                this.template.querySelector('.bwdwi-webinar-info').textContent = 'Webinar has ended.';
                return;
            }

            const days = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diffInMilliseconds % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diffInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diffInMilliseconds % (1000 * 60)) / 1000);

            this.template.querySelector('.bwdwi-webinar-info').innerHTML = `
                <div>${days} <div>days</div></div>
                <div>${hours.toString().padStart(2, '0')} <div>hours</div></div>
                <div>${minutes.toString().padStart(2, '0')} <div>minutes</div></div>
                <div>${seconds.toString().padStart(2, '0')} <div>seconds</div></div>
            `;
        }, 1000);
    }

    disconnectedCallback() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
    }

}