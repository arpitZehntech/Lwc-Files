import { LightningElement, api, track, wire } from 'lwc';
import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

export default class TabsWithAccordion extends LightningElement {

    @track tabs = [];
    @api tabOrder = '';

    @track activeTabValue = 'TAB 1';

    // It is applicable in First Tab
    // start


    @track visibleTabs = [];
    @track hiddenTabs = [];
    @track hasHiddenTabs = false;

    // end

    @api selectTabsandAccordion;

    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;

    connectedCallback() {

        if (this.selectTabsandAccordion === '1st Tabs and Accordion') {
            this.showhideFirst = true;
        } else if (this.selectTabsandAccordion === '2nd Tabs and Accordion') {
            this.showhideSecond = true;
        } else if (this.selectTabsandAccordion === '3rd Tabs and Accordion') {
            this.showhideThird = true;
        }

        window.addEventListener('resize', () => {
            this.updateVisibleTabs();
        });
    }

    @wire(fetchTabData)
    wiredTabData({ error, data }) {
        if (data) {
            this.tabs = data.map(tab => ({
                label: tab.label,
                subheadings: tab.subheadings.map(subheading => ({
                    label: subheading.label,
                    content: subheading.content
                }))
            }));
            // Check if the tab order property is set
            if (this.tabOrder) {
                // Split the tab order string into an array
                const orderArray = this.tabOrder.split(',').map(item => item.trim());
                // Sort the tabs based on the order specified in the tab order property
                this.tabs.sort((a, b) => {
                    return orderArray.indexOf(a.label) - orderArray.indexOf(b.label);
                });
            }
            this.updateVisibleTabs();
        } else if (error) {
            console.error('Error fetching tab data:', error);
        }
    }

    // Extra JS Used in 1st tabs and accordian 

    handleTabClick(event) {
        const selectedTabLabel = event.target.dataset.key;
        const allSections = this.template.querySelectorAll('.accordion1');
        allSections.forEach(section => {
            if (section.classList.contains(selectedTabLabel)) {
                section.style.display = 'flex';
            }
        });
    }

    updateVisibleTabs() {
        if (window.innerWidth <= 600) {
            this.visibleTabs = this.tabs.slice(0, 2);
            this.hiddenTabs = this.tabs.slice(2);
            this.hasHiddenTabs = this.hiddenTabs.length > 0;
        } else {
            this.visibleTabs = [...this.tabs];
            this.hiddenTabs = [];
            this.hasHiddenTabs = false;
        }
    }

    handleMoreItemClick(event) {
        this.visibleTabs = [...this.visibleTabs, ...this.hiddenTabs];
        this.hiddenTabs = [];
        this.hasHiddenTabs = false;
    }

    // Extra js for 2nd and 3rd Tabs and accordian

    handleTabChange(event) {
        this.activeTabValue = event.detail.value;
        // Reset accordion active section when tab changes
        this.accordion1ActiveSection = null;
        this.accordion2ActiveSection = null;
    }

}