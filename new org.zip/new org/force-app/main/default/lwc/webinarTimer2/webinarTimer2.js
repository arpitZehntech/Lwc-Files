import { LightningElement } from 'lwc';

export default class WebinarTimer2 extends LightningElement {}