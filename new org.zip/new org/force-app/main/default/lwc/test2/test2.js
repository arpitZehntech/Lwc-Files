import { LightningElement , api, track} from 'lwc';

export default class Test2 extends LightningElement {

    @api selectTheme;
    @track showhideFirst = false;
    @track showhideSecond = false;

    
    connectedCallback()
    {

        if (this.selectTheme === '1st Theme') {
            this.showhideFirst = true;
        } else if (this.selectTheme === '2nd Theme') {
            this.showhideSecond = true;
        } 
    }


    _newLayout1;

    @api
    set newLayout1(value) {
        if (value) {
            this._newLayout1 = JSON.parse(value);
        }
    }

    get newLayout1() {
        return this._newLayout1;
    }

    setStyles1() {


        if (this.newLayout1) {

            this.template
            .querySelector("div")
            .style.setProperty("text-align", this.newLayout1.textAlignment);

            this.template
            .querySelector("div")
            .style.setProperty("border-style", this.newLayout1.borderStyle);

            this.template
            .querySelector("div")
            .style.setProperty("border-width", this.newLayout1.borderWeight + 'px');

            this.template
            .querySelector("div")
            .style.setProperty("border-radius", this.newLayout1.borderRadius + 'px');

            this.template
            .querySelector(".h1")
            .style.setProperty("font-size", this.newLayout1.fontSize + 'px');

  
        }
    }


    _newLayout2;

    @api
    set newLayout2(value) {
        if (value) {
            this._newLayout2 = JSON.parse(value);
        }
    }

    get newLayout2() {
        return this._newLayout2;
    }

    setStyles2() {


        if (this.newLayout2) {

            this.template
            .querySelector("div")
            .style.setProperty("text-align", this.newLayout2.textAlignment2);

            this.template
            .querySelector("div")
            .style.setProperty("border-style", this.newLayout2.borderStyle2);

            this.template
            .querySelector("div")
            .style.setProperty("border-width", this.newLayout2.borderWeight2+ 'px');

            this.template
            .querySelector("div")
            .style.setProperty("border-radius", this.newLayout2.borderRadius2 + 'px');

            this.template
            .querySelector(".h2")
            .style.setProperty("font-size", this.newLayout2.fontSize2 + 'px');

  
        }
    }

    

    renderedCallback() {
        this.setStyles1();
        this.setStyles2();


    }



}