import { LightningElement, api, track, wire } from 'lwc';

import career_data from "@salesforce/apex/locationSearch.Career_Get"; // fetch Career data
import { NavigationMixin } from 'lightning/navigation';
import createCandidateApplication from '@salesforce/apex/CandidateApplicationController.createCandidateApplication';
import { loadStyle } from 'lightning/platformResourceLoader'
import dropdown from '@salesforce/resourceUrl/dropdown';
import cssFile from '@salesforce/resourceUrl/careerCSS'; //Css file of Career component
import ZTWebsiteBootstrap from '@salesforce/resourceUrl/ZTWebsiteBootstrap'; //bootstrapFile import

import locations_Object from "@salesforce/apex/locationSearch.f_Get_Types"; //fetch location data   
import department_Object from "@salesforce/apex/locationSearch.f_Get"; //fetch department data   

export default class CareerPage extends NavigationMixin(LightningElement) {

    @api selectTheme;
    @track showhideFirst = false;
    @track showhideSecond = false;


    connectedCallback() {

        if (this.selectTheme === 'Theme 1') {
            this.showhideFirst = true;
            this.showhideSecond = false;
        } else if (this.selectTheme === 'Theme 2') {
            this.showhideSecond = true;
            this.showhideFirst = false;
        }

        // Add an event listener for the popstate event
        window.addEventListener('popstate', this.handlePopState.bind(this));
        console.log('connectedCallback');

    }


    // --------------   Priview Button start   -------------- //


    disconnectedCallback() {
        // Remove the event listener when the component is removed
        window.removeEventListener('popstate', this.handlePopState.bind(this));
        console.log('disconnectedCallback');

    }

    // Define the method to handle the popstate event
    handlePopState(event) {
        // Refresh the page when the system back button is clicked
        location.reload();
    }


    //--------------  Priview Button END   -------------- //


    // ---------------------------------------------   theme 1 js -------------------------------------------------------------



    @track isShowModal = false;
    email = null;
    name = null;
    fileData;
    file;
    filename;
    base64;


    @api heading;
    @api subheading;
    @api backgroundImageUrl1;

    @api headingClr1;
    @api subHeadingClr1;
    @api filterBackGroundClr;
    @api filterPlaceholderClr;
    @api searchBarBackgroundClr;
    @api searchBarPlaceHolderClr;
    @api searchBarTextClr;

    // @api searchResultMsgClr;

    @api cardHeadingColor;
    @api cardSubHeadingColor;

    @api cardButtonColor;
    @api cardButtonTextColor;
    @api cardButtonBorderColor;
    @api cardButtonColorOnHover;
    @api cardButtonTextColorOnHover;
    @api cardButtonBorderColorOnHover;
    @api cardLeftBorderColorOnHover;

    @api templatePage1;

    get topBannerBackgoundImg() {
        return `background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${this.backgroundImageUrl1});`;
    }

    renderedCallback() {

        Promise.all([loadStyle(this, ZTWebsiteBootstrap)]),
            Promise.all([loadStyle(this, dropdown)]),
            Promise.all([loadStyle(this, cssFile)]);


        this.template
            .querySelector("div")
            .style.setProperty("--my-headingClr1", this.headingClr1);

        this.template
            .querySelector("div")
            .style.setProperty("--my-subHeadingClr1", this.subHeadingClr1);

        this.template
            .querySelector("div")
            .style.setProperty("--my-filterBackGroundClr", this.filterBackGroundClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-filterPlaceholderClr", this.filterPlaceholderClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarBackgroundClr", this.searchBarBackgroundClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarPlaceHolderClr", this.searchBarPlaceHolderClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-searchBarTextClr", this.searchBarTextClr);

        // this.template
        //     .querySelector("div")
        //     .style.setProperty("--my-searchResultMsgClr", this.searchResultMsgClr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardHeadingColor", this.cardHeadingColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardSubHeadingColor", this.cardSubHeadingColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonColor", this.cardButtonColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonTextColor", this.cardButtonTextColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonBorderColor", this.cardButtonBorderColor);


        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonColorOnHover", this.cardButtonColorOnHover);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonTextColorOnHover", this.cardButtonTextColorOnHover);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardButtonBorderColorOnHover", this.cardButtonBorderColorOnHover);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardLeftBorderColorOnHover", this.cardLeftBorderColorOnHover);


            // ----------------------------------   Theme 2 Property  ------------------------//

        this.template
            .querySelector("div")
            .style.setProperty("--my-headingColor", this.headingColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardBorderColor", this.cardBorderColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardBackgroundColor", this.cardBackgroundColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-backgroundHvrColor", this.backgroundHvrColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardtxtcolorHvr", this.cardtxtcolorHvr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-btnColorHvr", this.btnColorHvr);

        this.template
            .querySelector("div")
            .style.setProperty("--my-cardtxtcolor", this.cardtxtcolor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-btnColor", this.btnColor);

        this.template
            .querySelector("div")
            .style.setProperty("--my-btnTxtColor", this.btnTxtColor);



        // Fetching data
        const defaultLocation = 'All';
        const defaultDepartment = 'All';
        this.filterData(defaultLocation, defaultDepartment);
        this.filterData1(defaultLocation, defaultDepartment);

    }


    @track cards1 = [];
    @track cityNameOptions = [];
    @track deptNameOptions = [];

    @wire(locations_Object)
    wiredlocationsObject({ error, data }) {
        if (data) {
            this.cityNameOptions = [{ label: 'All Locations', value: 'All' }, ...data.map(ele => ({ label: ele.Location__c, value: ele.Location__c }))];
        } else if (error) {
            // Handle error
        }
    }

    @wire(department_Object)
    wireddepartmentObject({ error, data }) {
        if (data) {
            this.deptNameOptions = [{ label: 'All Department', value: 'All' }, ...data.map(ele => ({ label: ele.Department__c, value: ele.Department__c }))];
        } else if (error) {
            // Handle error
        }
    }

    get cityName() {
        return this.cityNameOptions;
    }

    get deptName() {
        return this.deptNameOptions;
    }

    @wire(career_data)
    wiredCareerData({ error, data }) {
        if (data) {
            this.cards1 = data.map(item => ({
                uniqueId: item.Id,
                jobTitle: item.Name,
                departmentName: item.Department__c,
                jobLocation: item.Location__c,
                jobExperience: item.Experience__c,
                avatarSrc: item.Position_Logo_Image_Url__c
            }));
        } else if (error) {
            // Handle error
        }
    }

    handleLocationChange1(event) {
        const location = event.target.value;
        const department = this.template.querySelector('.department').value;
        this.filterData1(location, department);
    }

    handleDepartmentChange1(event) {
        const department = event.target.value;
        const location = this.template.querySelector('.location').value;
        this.filterData1(location, department);
    }

    filterData1(location, department) {
        const searchDiv1 = this.template.querySelector('.card-holder');

        console.log("searchDiv1 :" , searchDiv1);
        // Check if searchDiv1 exists before proceeding
        if (searchDiv1) {
            const cards1 = searchDiv1.querySelectorAll('.cardCar2');

            // Your existing filtering logic here
            for (let i = 0; i < cards1.length; i++) {
                const card1 = cards1[i];
                const cardLocation1 = card1.querySelector('.card-company-location')?.textContent?.trim().toUpperCase() || '';
                const cardDepartment1 = card1.querySelector('.card-company-glassdoor')?.textContent?.trim().toUpperCase() || '';
                const title1 = cards1[i].querySelector('.job-title').innerText.toUpperCase();

                let locationMatch;
                let departmentMatch;

                if (location === 'All') {
                    locationMatch = true;
                    this.searchPosition1();
                } else {
                    locationMatch = location ? cardLocation1.toUpperCase().trim() === location.toUpperCase().trim() : true;
                }
                if (department === 'All') {
                    departmentMatch = true;
                    this.searchPosition1();
                } else {
                    departmentMatch = department ? cardDepartment1.includes(department.toUpperCase().trim()) : true;
                }

                if (locationMatch && departmentMatch) {
                    card1.style.display = "";
                    this.searchPosition1();
                } else {
                    card1.style.display = "none";
                }
            }
        } else {
            console.error('.card-holder element not found');
        }
    }


    searchPosition1(position) {
        // Define searchDiv before using it

        const search1 = this.template.querySelector('.filter').value?.trim().toUpperCase();
        const location = this.template.querySelector('.location').value?.trim().toUpperCase();
        const department = this.template.querySelector('.department').value?.trim().toUpperCase();
        let resultsFound = 0;

        const searchDiv1 = this.template.querySelector('.card-holder');

        if (searchDiv1) {

            const cards1 = searchDiv1.querySelectorAll('.cardCar2');


            // Your code logic here
            for (let i = 0; i < cards1.length; i++) {
                const cardDept = cards1[i].querySelector('.card-company-glassdoor').innerText.trim().toUpperCase();
                const cardLoc = cards1[i].querySelector('.card-company-location').innerText.trim().toUpperCase();
                const title1 = cards1[i].querySelector('.job-title').innerText.toUpperCase();

                let titleMatch = title1.includes(search1);
                let locationMatch = !location || location === 'ALL' || location === cardLoc;
                let departmentMatch = !department || department === 'ALL' || cardDept.includes(department);

                if (titleMatch && locationMatch && departmentMatch) {
                    cards1[i].style.display = "";
                    resultsFound++;
                } else {
                    cards1[i].style.display = "none";
                }
            }
        } else {
            console.error('.card-holder element not found');
            // Optionally, handle this case by returning early or taking appropriate action
        }

        const searchResultsMessage = this.template.querySelector('.search-results-message');
        if (resultsFound > 0) {
            searchResultsMessage.textContent = `${resultsFound} Result${resultsFound > 1 ? 's' : ''} found: ${search1}`;
        } else {
            searchResultsMessage.textContent = `No results found${search1 ? ` for "${search1}".` : '.'}`;
        }
    }


    handleViewJob(event) {
        // event.preventDefault();
        const jobId = event.target.dataset.id;
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: this.templatePage1
            },
            state: {
                c__divID: jobId
            }
        });
    }
    

    showModalBox() {
        this.isShowModal = true;
    }

    hideModalBox() {
        this.isShowModal = false;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleFileChange(event) {
        this.file = event.target.files[0];
    }

    handleSubmit() {
        let jsWrp = {
            name: this.name,
            email: this.email,
            fileName: this.filename,
            fileData: this.base64
        };
        createCandidateApplication({ wrp: jsWrp })
            .then((result) => {
                console.log('Record created successfully');
                this.hideModalBox();
            })
            .catch((error) => {
                console.error('Error creating record: ' + error.body.message);
                console.log('Record created successfully', JSON.stringify(error));
            });
    }

    openfileUpload(event) {
        const file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = () => {
            var base64 = reader.result.split(',')[1];
            this.filename = file.name;
            this.base64 = base64;
        };
        reader.readAsDataURL(file);
    }


    // ---------------------------------------------   theme 2 js -------------------------------------------------------------

    @api position;
    @api department;
    @api Experience;
    @api location;
    @api vacancy;
    @api ctc;
    @api Qualification;
    @api Responsibilities;
    @api skill;
    @api aboutUs;
    @api templatePage;
    @api logo;
    @track l_All_Types;

    @api headingColor;
    @api cardBackgroundColor;
    @api backgroundHvrColor;
    @api cardtxtcolorHvr;
    @api btnColor;
    @api btnColorHvr;
    @api btnTxtColor;
    @api cardtxtcolor;
    @api cardBorderColor;

    @track All_Types;

    displayedTiles = [];



    // --------------     dropdown filter new start -------------- //


    handleLocationChange(event) {
        var location = event.target.value;
        var department = this.template.querySelector('.department').value;
        this.filterData(location, department);
    }

    handleDepartmentChange(event) {
        var department = event.target.value;
        var location = this.template.querySelector('.location').value;
        this.filterData(location, department);

    }

    filterData(location, department) {
        const searchDiv2 = this.template.querySelector('.row');

       console.log("searchDiv1 :" , searchDiv2);


        // Check if searchDiv2 exists before proceeding
        if (searchDiv2) {
            const cards2 = searchDiv2.querySelectorAll('.col-6');

            for (let i = 0; i < cards2.length; i++) {
                let card2 = cards2[i];
                let cardLocation2 = card2.querySelector('.cityicon').childNodes[0].nextSibling.childNodes[2].nodeValue.trim();
                let cardDepartment2 = card2.className.toUpperCase();

                let locationMatch;
                let departmentMatch;

                if (location === 'All') {
                    locationMatch = true;

                    // Remove any existing no-results message
                    const existingMessages = searchDiv2.querySelectorAll('.no-results-message');
                    existingMessages.forEach(message => message.remove());

                    // Call searchPosition() to ensure proper filtering
                    this.searchPosition();
                } else {
                    locationMatch = location ? cardLocation2.toUpperCase().trim() === location.toUpperCase().trim() : true;
                }
                if (department === 'All') {
                    departmentMatch = true;
                    // Remove any existing no-results message
                    const existingMessages = searchDiv2.querySelectorAll('.no-results-message');
                    existingMessages.forEach(message => message.remove());

                    // Call searchPosition() to ensure proper filtering
                    this.searchPosition();
                } else {
                    departmentMatch = department ? cardDepartment2.includes(department.toUpperCase().trim()) : true;
                }

                if (locationMatch && departmentMatch) {
                    card2.style.display = "";
                    // Remove any existing no-results message
                    const existingMessages = searchDiv2.querySelectorAll('.no-results-message');
                    existingMessages.forEach(message => message.remove());

                    // Call searchPosition() to ensure proper filtering
                    this.searchPosition();
                } else {
                    card2.style.display = "none";
                }
            }
        } else {
            console.error('.row element not found');
           
        }
    }


    searchPosition() {
        const search2 = this.template.querySelector('.filter').value?.trim().toUpperCase();
        const location = this.template.querySelector('.location').value?.trim().toUpperCase();
        const department = this.template.querySelector('.department').value?.trim().toUpperCase();

        const searchDiv2 = this.template.querySelector('.row');
        const cards2 = searchDiv2.querySelectorAll('.col-6');
        let resultsFound = false;

        for (let i = 0; i < cards2.length; i++) {
            let cardDept = cards2[i].className.toUpperCase().trim();
            let cardLoc = cards2[i].querySelector('.cityicon').innerText.trim().toUpperCase();
            let title2 = cards2[i].querySelector('.positionName').innerHTML.toUpperCase();

            // Check if the search matches the title
            let titleMatch = title2.includes(search2);
            // Check if the location matches the selected location, is "All Locations", or if no location is selected
            let locationMatch = !location || location === 'ALL' || location === cardLoc;
            // Check if the department matches the selected department, is "All Department", or if no department is selected
            let departmentMatch = !department || department === 'ALL' || cardDept.includes(department);

            // Display the card if any of the search criteria match
            if (titleMatch && locationMatch && departmentMatch) {
                cards2[i].style.display = "";
                resultsFound = true; // Set to true if any matching card is found
            } else {
                cards2[i].style.display = "none";
            }
        }

        // Remove all existing no-result messages
        const existingMessages = searchDiv2.querySelectorAll('.no-results-message');
        existingMessages.forEach(message => message.remove());

        // Show message if no results are found
        if (!resultsFound) {
            const noResultsMessage = document.createElement('div');
            noResultsMessage.classList.add('no-results-message'); // Add a class to identify the message
            noResultsMessage.style.textAlign = 'center'; // Center the message
            noResultsMessage.style.fontWeight = 'bold'; // Make the message bold
            noResultsMessage.style.fontSize = '30px'; // Set the font size to 36px
            noResultsMessage.style.paddingTop = '40px'; // Set the font size to 36px
            noResultsMessage.innerHTML = `<p>No results found for "${search2}".</p>`;
            searchDiv2.appendChild(noResultsMessage);
        }
    }



    //-------------------------------create Div dynamically according to custom object-------------------//

    @wire(career_data)
    getcareerData({ error, data }) {
        if (error) {
            // TODO: Error handling
        } else if (data) {
            // console.log('Inside getcareerData');
            // console.log('Data: ', data);

            let boxDiv = this.template.querySelector('.row');
            if (!boxDiv) {
                // Wait for the component to finish rendering
                setTimeout(() => {
                    this.getcareerData({ error, data });
                }, 0);
                return;
            }

            let cardTemplate;

            console.log('boxDiv: ', boxDiv);

            let cont = this.template.querySelector('.container');
            console.log('cont: ', cont);
            console.log('cont childnodes: ', cont.childNodes);

            for (let i = 0; i < data.length; i++) {
                cardTemplate = `<div class="box1 col-6 ${data[i].Department__c}" data-id="${data[i].Id}" >
              <div class="slds-grid box">
                  <div class="slds-col divsize" style="border-color:${this.bordercolor}">
                      <div class="slds-grid slds-grid_vertical ccd cardHover">
                          <div class="slds-col bold">
                              <h1 class="positionName">${data[i].Name}</h1>
                          </div>
                          <div class="slds-col slds-grid slds-wrap mmm">
                              <div class="slds-col slds-size_1-of-3 bttm">
                                  <span class="jobopening">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-briefcase"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>${data[i].Experience__c}</span>
                              </div>
                              <div class="slds-col slds-size_1-of-3 cityicon">
                                  <p style="font-size: 15px;"> 
                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                      ${data[i].Location__c}
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                                  </p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>`;

                boxDiv.innerHTML += cardTemplate;
            }

            // Add click event listener to each card
            let cards2 = this.template.querySelectorAll('.box1');

            for (let i = 0; i < cards2.length; i++) {
                cards2[i].addEventListener('click', (event) => {
                    let DivId = event.currentTarget.dataset.id;
                    console.log('DivID', DivId);

                    this[NavigationMixin.Navigate]({
                        type: 'comm__namedPage',
                        attributes: {
                            name: this.templatePage
                        },
                        state: {
                            c__divID: DivId
                        }
                    });
                });
            }
        }
    }



    //------Reset button funcation-------------------
    resetbttn() {
        const location = this.template.querySelector('.location');
        const department = this.template.querySelector('.department');
        const searchBar2 = this.template.querySelector('.filter');
        const searchDiv2 = this.template.querySelector('.row');
        const cards2 = searchDiv2.querySelectorAll('.col-6');

        // Set dropdowns to "All"
        location.value = 'All';
        department.value = 'All';
        searchBar2.value = '';

        for (let i = 0; i < cards2.length; i++) {
            const cardDept2 = cards2[i].className.toUpperCase().trim();
            const cardLoc2 = cards2[i].querySelector('.cityicon').innerText.trim().toUpperCase();
            const title2 = cards2[i].querySelector('.positionName').innerHTML.toUpperCase();

            // Display all cards
            cards2[i].style.display = "";
        }

        // Remove any existing no-results message
        const existingMessages = searchDiv2.querySelectorAll('.no-results-message');
        existingMessages.forEach(message => message.remove());

        // Call searchPosition() to ensure proper filtering
        this.searchPosition();
    }


}