import { LightningElement, track, api } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity2';
import showtestimonialList from '@salesforce/apex/testimonialsClass.showtestimonials';

export default class TestimonialFinal extends LightningElement {
    @api selectTestimonial;
    @api heading;
    @api headingClr;

    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;

    @track carouselItems = [];

    // Flags to check if Flickity is initialized for each carousel
    flickityInitialized1 = false;
    flickityInitialized2 = false;
    flickityInitialized3 = false;

    connectedCallback() {
        if (this.selectTestimonial === '1st Testimonial') {
            this.showhideFirst = true;
        } else if (this.selectTestimonial === '2nd Testimonial') {
            this.showhideSecond = true;
        } else if (this.selectTestimonial === '3rd Testimonial') {
            this.showhideThird = true;
        }

        this.loadTestimonials();
    }

    renderedCallback() {
        this.template
        .querySelector("div")
        .style.setProperty("--my-mainHeadingClr", this.headingClr);

        if (this.showhideFirst && !this.flickityInitialized1) {
            this.loadFlickity1();
        }
        if (this.showhideSecond && !this.flickityInitialized2) {
            this.loadFlickity2();
        }
        if (this.showhideThird && !this.flickityInitialized3) {
            this.loadFlickity3();
        }
    }

    loadTestimonials() {
        showtestimonialList()
            .then(result => {
                this.carouselItems = result.map(item => ({
                    id: item.Id,
                    name: item.Name,
                    description: item.Discription__c,
                    imageUrl: item.image_url__c
                }));
            })
            .catch(error => {
                console.error('Error fetching testimonial data:', error);
            });
    }

    loadFlickity1() {
        loadScript(this, FLICK + '/flickity/jquery.min.js')
            .then(() => loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'))
            .then(() => loadStyle(this, FLICK + '/flickity/flickity.css'))
            .then(() => {
                $(this.template.querySelector('.carousel1')).flickity({
                    prevNextButtons: true,
                    draggable: true,
                    pageDots: true,
                    groupCells: true,
                    wrapAround: true
                });
                this.flickityInitialized1 = true;
            })
            .catch(error => {
                console.error('Error loading Flickity resources:', error);
            });
    }

    loadFlickity2() {
        loadScript(this, FLICK + '/flickity/jquery.min.js')
            .then(() => loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'))
            .then(() => loadStyle(this, FLICK + '/flickity/flickity.css'))
            .then(() => {
                $(this.template.querySelector('[data-flickity]')).flickity({
                    prevNextButtons: true,
                    autoPlay: true,
                    draggable: true,
                    wrapAround: true,
                    pageDots: false
                });
                this.flickityInitialized2 = true;
            })
            .catch(error => {
                console.error('Error loading Flickity resources:', error);
            });
    }

    loadFlickity3() {
        loadScript(this, FLICK + '/flickity/jquery.min.js')
            .then(() => loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'))
            .then(() => loadStyle(this, FLICK + '/flickity/flickity.css'))
            .then(() => {
                $(this.template.querySelector('div[class="carousel3"]')).flickity({
                    prevNextButtons: true,
                    autoPlay: true,
                    draggable: true,
                    wrapAround: true,
                    pageDots: false
                });
                this.flickityInitialized3 = true;
            })
            .catch(error => {
                console.error('Error loading Flickity resources:', error);
            });
    }
}