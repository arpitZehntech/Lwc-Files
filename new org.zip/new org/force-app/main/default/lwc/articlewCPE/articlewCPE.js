import { LightningElement, api} from 'lwc';

export default class ArticlewCPE extends LightningElement {
    @api articleTitle;
    @api articleDate;
    @api articleContent;
    @api textAlignment;
    @api backgroundColor;
    @api contentRef;
    @api articleCheckbox;


    _layoutProperties;

    _layoutProperties2;



    @api
    set layoutProperties(value) {
        if (value) {
            this._layoutProperties = JSON.parse(value);
        }
    }

    get layoutProperties() {
        return this._layoutProperties;
    }

    setStyles() {
        let articleCSS = this.template.host.style;
        articleCSS.setProperty('--dxp-g-root', this.backgroundColor);
        articleCSS.setProperty('text-align', this.textAlignment);

        if (this.layoutProperties) {
            articleCSS.setProperty('border-style', this.layoutProperties.borderStyle);
            articleCSS.setProperty('border-width', this.layoutProperties.borderWeight + 'px');
            articleCSS.setProperty('border-radius', this.layoutProperties.borderRadius + 'px');
            articleCSS.setProperty('height', this.layoutProperties.layoutHeight + 'px');
            articleCSS.setProperty('width', this.layoutProperties.layoutWidth + 'px');
        }
    }

    @api
    set layoutProperties2(value) {
        if (value) {
            this._layoutProperties2 = JSON.parse(value);
        }
    }

    get layoutProperties2() {
        return this._layoutProperties2;
    }

    setStyles2() {
        let articleCSS = this.template.host.style;
        articleCSS.setProperty('--dxp-g-root', this.backgroundColor);
        articleCSS.setProperty('text-align', this.textAlignment);

        if (this.layoutProperties2) {
            articleCSS.setProperty('border-style', this.layoutProperties2.borderStyle);
            articleCSS.setProperty('border-width', this.layoutProperties2.borderWeight + 'px');
            articleCSS.setProperty('border-radius', this.layoutProperties2.borderRadius + 'px');
            articleCSS.setProperty('height', this.layoutProperties2.layoutHeight + 'px');
            articleCSS.setProperty('width', this.layoutProperties2.layoutWidth + 'px');
        }
    }


    renderedCallback() {
        this.setStyles();

        this.setStyles2();
    }

}