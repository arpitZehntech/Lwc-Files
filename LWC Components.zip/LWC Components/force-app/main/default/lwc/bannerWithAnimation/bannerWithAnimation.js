import { LightningElement } from 'lwc';

export default class BannerWithAnimation extends LightningElement {}