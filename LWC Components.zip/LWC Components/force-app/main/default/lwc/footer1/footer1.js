// import { LightningElement } from 'lwc';

// export default class Footer1 extends LightningElement {}

import { LightningElement, api, wire, track } from 'lwc';
import sendEmail from '@salesforce/apex/EmailHandler.sendEmail';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_EMAIL_OBJECT from '@salesforce/schema/Subscriber__c';
import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

export default class Footer1 extends LightningElement {
    @track email = '';

    @api Block1heading;
    @api Block2heading;
    @api Block3heading;

    @api Block1SubHeading1;
    @api Block1SubHeading2;
    @api Block1SubHeading3;
    @api Block1SubHeading4;
    @api Block1SubHeading5;

    @api Block2SubHeading1;
    @api Block2SubHeading2;
    @api Block2SubHeading3;
    @api Block2SubHeading4;
    @api Block2SubHeading5;

    @api Block1SubHeading1Url;
    @api Block1SubHeading2Url;
    @api Block1SubHeading3Url;
    @api Block1SubHeading4Url;
    @api Block1SubHeading5Url;

    @api Block2SubHeading1Url;
    @api Block2SubHeading2Url;
    @api Block2SubHeading3Url;
    @api Block2SubHeading4Url;
    @api Block2SubHeading5Url;

    @api image1;
    @api image2;
    @api image3;
    @api image4;

    @api Image1Url;
    @api Image2Url;
    @api Image3Url;
    @api Image4Url;

    @api CopyrightYear;
    @api CopyrightTitle;
    @api CopyrightTitleUrl;


    handleChange(event) {
        if (event.target.name === 'emailAddress') {
            this.email = event.target.value;
        }
    }

    async handleSubscribe() {

        await this.handleSubscribe();
    }

    async handleSubscribe() {
        if (this.email) {
            const fields = {};
            fields[EMAIL_FIELD.fieldApiName] = this.email;

            const recordInput = { apiName: USER_EMAIL_OBJECT.objectApiName, fields };
            try {
                await createRecord(recordInput);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Thank you for subscribing!',
                        variant: 'success'
                    })
                );
                this.email = ''; // Clear the email field after successful subscription
            } catch (error) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            }
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please enter your email address',
                    variant: 'error'
                })
            );
        }
    }

}
