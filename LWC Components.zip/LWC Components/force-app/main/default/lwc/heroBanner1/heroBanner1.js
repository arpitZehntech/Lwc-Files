import { LightningElement } from 'lwc';

export default class HeroBanner1 extends LightningElement {}