import { LightningElement, track } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import COUNT from '@salesforce/resourceUrl/counterup';

// export default class CounterUpLWC extends LightningElement {
//     @track counters = [
//         { id: 1, value: '1,234,567' },
//         { id: 2, value: '1.99' },
//         { id: 3, value: '12345' },
//     ];

//     connectedCallback() {
//         Promise.all([
//             loadScript(this, COUNT + '/counterup/jquery-1.12.2.min.js'),
//             loadScript(this, COUNT + '/counterup/jquery.waypoints.min.js'),
//             loadScript(this, COUNT + '/counterup/jquery.counterup.min.js')
//        ]).then(() => {
//             this.counters.forEach(counter => {
//                 const counterElement = this.template.querySelector(`.counter[key="${counter.id}"]`);
//                 this.animateCounter(counterElement, counter.value);
//             });
//        }).catch(e => {
//            console.error('Error:', e);
//        });
//     }

//     animateCounter(counterElement, targetValue) {
//         const delay = 10;
//         const time = 1000;
//         const offset = 70;
//         const beginAt = 100;

//         let currentValue = 0;
//         const intervalId = setInterval(() => {
//             currentValue = Math.min(currentValue + 1, targetValue.replace(/,/g, ''));
//             counterElement.textContent = currentValue.toLocaleString();

//             if (currentValue >= targetValue.replace(/,/g, '')) {
//                 clearInterval(intervalId);
//             }
//         }, delay);
//     }
// }


// export default class CounterUpLWC extends LightningElement {
//      @track counts = [
//         { number: 45000, current: 0, label: 'Projects Completed' },
//         { number: 2500, current: 0, label: 'Coffees Consumed' },
//         { number: 40400, current: 0, label: 'Happy Customers' },
//         { number: 50900, current: 0, label: 'Lines of Code' }
//     ];

//     connectedCallback() {
//         this.startCounters();
//     }

//     startCounters() {
//         const intervalTime = 1; // Set the interval time in milliseconds
//         this.counts.forEach((item) => {
//             const intervalFunction = () => {
//                 if (item.current + 200 < item.number) {
//                     item.current += 200;
//                 } else {
//                     item.current++;
//                 }

//                 if (item.current < item.number) {
//                     setTimeout(intervalFunction, intervalTime);
//                 }
//             };

//             setTimeout(intervalFunction, intervalTime);
//         });
//     }

// }

// JavaScript (counterTest2.js)


export default class CounterUpLWC extends LightningElement {


@track odometerValue = 0;

animateOdometer() {
    const odometerElement = this.template.querySelector('.odometer');
    let currentValue = 0;

    requestAnimationFrame(() => {
        currentValue = Math.min(currentValue + 1, this.odometerValue);
        odometerElement.textContent = currentValue.toString().padStart(6, '0'); // Format as 6-digit number

        if (currentValue < this.odometerValue) {
            requestAnimationFrame(() => this.animateOdometer());
        }
    });
}

connectedCallback() {
    this.startCounters();
    this.animateOdometer(); // Start odometer animation
}

}