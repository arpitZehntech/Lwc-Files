import { LightningElement, api } from 'lwc';

export default class DynamicCompDemo extends LightningElement {

  renderedCallback() {
    this.template
      .querySelector("lightning-layout-item")
      .style.setProperty("--my-borderclr", this.bordercolor);

      this.template
      .querySelector("lightning-layout-item")
      .style.setProperty("--my-borderclr1", this.textcolor);

      this.template
      .querySelector("h1")
      .style.setProperty("--my-borderclr1", this.textcolor);

      this.template
      .querySelector("h1")
      .style.setProperty("--my-paddingtxt", this.paddingOnText);

      this.template
      .querySelector("h1")
      .style.setProperty("--my-fontsize", this.FontSize);


      this.template
      .querySelector("h1")
      .style.setProperty("--my-alignment", this.TextAllignment1);

      this.template
      .querySelector("h1")
      .style.setProperty("--my-fontFamily", this.FontFamily);

      this.template
      .querySelector("button")
      .style.setProperty("--my-borderclr2", this.bordercolor1);

      this.template
      .querySelector("button")
      .style.setProperty("--my-alignment1", this.buttonAllignment);

      this.template
      .querySelector("button")
      .style.setProperty("--my-opacity", this.opacity);

      console.log('Alignment1 : '+this.Alignment1);

  }

  @api bordercolor;
  @api textcolor;
  @api inputPropertyName;
  @api paddingOnText;
  @api FontSize;
  @api TextAllignment1;
  @api bordercolor1;
  @api buttonAllignment;
  @api opacity;
  @api FontFamily;
  @api richText;
  @api richTextProperty;
  @api Date;

  

}