import { LightningElement, api} from 'lwc';

export default class SimpleIntrestCalculator extends LightningElement {

    @api currentOutput;
    principal;
    rate;
    time;

    principalHandler(event)
    {
        this.principal = parseInt(event.target.value);
    }
    
    rateHandler(event)
    {
        this.rate = parseInt(event.target.value);
    }
    

    timeHandler(event)
    {
        this.time = parseInt(event.target.value);
    }

    handleClick()
    {
        this.currentOutput = 'Total simple intrest ='+ (this.principal*this.rate* this.time)/100;
    }
}