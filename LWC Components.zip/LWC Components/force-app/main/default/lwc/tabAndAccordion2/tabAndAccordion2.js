// import { LightningElement, wire, track, api } from 'lwc';
// import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

// export default class TabAndAccordion2 extends LightningElement {
//     @track tabs = [];
//     @api tabOrder = '';

//     @wire(fetchTabData)
//     wiredTabData({ error, data }) {
//         if (data) {
//             this.tabs = data.map(tab => ({
//                 label: tab.label,
//                 subheadings: tab.subheadings.map(subheading => ({
//                     label: subheading.label,
//                     content: subheading.content
//                 }))
//             }));
//             if (this.tabOrder) {
//                 const orderArray = this.tabOrder.split(',').map(item => item.trim());
//                 this.tabs.sort((a, b) => {
//                     return orderArray.indexOf(a.label) - orderArray.indexOf(b.label);
//                 });
//             }
//         } else if (error) {
//             console.error('Error fetching tab data:', error);
//         }
//     }

//     handleTabClick(event) {
//         const selectedTabLabel = event.target.dataset.key;
//         const allSections = this.template.querySelectorAll('.accordion');
//         allSections.forEach(section => {
//             if (section.classList.contains(selectedTabLabel)) {
//                 section.style.display = 'flex';
//             } 
//         });
//     }
// }
import { LightningElement, wire, track, api } from 'lwc';
import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

export default class TabAndAccordion2 extends LightningElement {
    @track tabs = [];
    @track visibleTabs = [];
    @track hiddenTabs = [];
    @api tabOrder = '';
    @track hasHiddenTabs = false;

    connectedCallback() {

         window.addEventListener('resize', () => {
            this.updateVisibleTabs();
        });
        
    }



    @wire(fetchTabData)
    wiredTabData({ error, data }) {
        if (data) {
            this.tabs = data.map(tab => ({
                label: tab.label,
                subheadings: tab.subheadings.map(subheading => ({
                    label: subheading.label,
                    content: subheading.content
                }))
            }));
            if (this.tabOrder) {
                const orderArray = this.tabOrder.split(',').map(item => item.trim());
                this.tabs.sort((a, b) => {
                    return orderArray.indexOf(a.label) - orderArray.indexOf(b.label);
                });
            }
            this.updateVisibleTabs();
        } else if (error) {
            console.error('Error fetching tab data:', error);
        }
    }

    updateVisibleTabs() {
        if (window.innerWidth <= 600) {
            this.visibleTabs = this.tabs.slice(0, 2);
            this.hiddenTabs = this.tabs.slice(2);
            this.hasHiddenTabs = this.hiddenTabs.length > 0;
        } else {
            this.visibleTabs = [...this.tabs];
            this.hiddenTabs = [];
            this.hasHiddenTabs = false;
        }
    }

    handleTabClick(event) {
        const selectedTabLabel = event.target.dataset.key;
        const allSections = this.template.querySelectorAll('.accordion');
        allSections.forEach(section => {
            if (section.classList.contains(selectedTabLabel)) {
                section.style.display = 'flex';
            }
        });
    }

    handleMoreItemClick(event) {
        this.visibleTabs = [...this.visibleTabs, ...this.hiddenTabs];
        this.hiddenTabs = [];
        this.hasHiddenTabs = false;
    }


    
}
