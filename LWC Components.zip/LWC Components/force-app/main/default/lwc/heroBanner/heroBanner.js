import { LightningElement, api, track } from 'lwc';

export default class HeroBanner extends LightningElement {
    @api backgroundImageUrl;
    @api heading;
    @api headingClr;
    @api subheading;
    @api subheadingClr;
    @api buttonClr;
    @api buttonText;
    @api buttonTextClr;
    @api buttonborderClr;
    @api buttonTextClrHvr;
    @api buttonClrHvr;
    @api buttonBorderRadius;
    @api textAlign;
    @api buttonRedirectUrl;

    @track hasText = false;

    get heroImageStyle() {
        return `background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${this.backgroundImageUrl});`;
    }

    renderedCallback() {
        if (this.buttonText) {
            this.hasText = true;
        } else {
            this.hasText = false;
        }

        this.template.querySelector("div").style.setProperty("--my-headingClr", this.headingClr);
        this.template.querySelector("div").style.setProperty("--my-subheadingClr", this.subheadingClr);
        this.template.querySelector("div").style.setProperty("--my-buttonClr", this.buttonClr);
        this.template.querySelector("div").style.setProperty("--my-buttonTextClr", this.buttonTextClr);
        this.template.querySelector("div").style.setProperty("--my-buttonborderClr", this.buttonborderClr);
        this.template.querySelector("div").style.setProperty("--my-buttonClrHvr", this.buttonClrHvr);
        this.template.querySelector("div").style.setProperty("--my-buttonTextClrHvr", this.buttonTextClrHvr);
        this.template.querySelector("div").style.setProperty("--my-buttonBorderRadius", this.buttonBorderRadius);
        this.template.querySelector("div").style.setProperty("--my-textAlign", this.textAlign);
    }

    get buttonTextEmpty() {
        return !this.buttonText;
    }
}
