import { LightningElement, api, track, wire } from 'lwc';
import showcustomerReviewList from '@salesforce/apex/customerReviewClass.showcustomerReview';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity1';

export default class CustomerReviews extends LightningElement {
    @api selectCustomerReview;

    @api mainHeading;
    @api mainHeadingClr;
    @api text1;
    @api textClr;

    @api backgroundclr1;
    @api backgroundclr2;
    @api boxbackgroundclr;
    @api textclr1;
    @api textFontFamily1;
    @api textFontFamily2;
    @api completionLineclr;
    @api fontSize1;
    @api fontSize2;
    @api fontSize3;
    @api fontSize4;
    @api customFontFamily1;
    @api customFontFamily2;
    @api starColor2;

    @api starfontSize2;

    @api backgroundclr3;
    @api boxbackgroundclr1;
    @api textclr3;
    @api fontSize5;
    @api textFontFamily3;
    @api fontSize6;
    @api completionCircleclr1;
    @api completionCircleclr2;
    @api starColor;
    @api starfontSize;

    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;

    @track testimonials = [];
    @track testimonialText;
    @track userPhoto;
    @track userName;
    @track idx = 0;
    @track carouselItems = [];
    intervalId;
    testimonialsLoaded = false;

    @track stars = [];

    connectedCallback() {
        if (this.selectCustomerReview === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectCustomerReview === 'Theme 2') {
            this.showhideSecond = true;
        } else if (this.selectCustomerReview === 'Theme 3') {
            this.showhideThird = true;
        }
        
        this.updateTestimonial();
        setInterval(() => this.updateTestimonial(), 10000);

        Promise.all([this.loadTestimonials(), this.loadFlickity4()])
            .then(() => this.initializeFlickity('.carousel4'))
            .catch(error => {
                console.error('Error loading resources:', error);
            });
    }

    renderedCallback() {
        const container = this.template.querySelector("div");

        if (container && !this.testimonialsLoaded) {
            container.style.setProperty("--my-mainHeadingClr", this.mainHeadingClr);
            container.style.setProperty("--my-textClr", this.textClr);

            container.style.setProperty("--my-backgroundclr1", this.backgroundclr1);
            container.style.setProperty("--my-backgroundclr2", this.backgroundclr2);
            container.style.setProperty("--my-boxbackgroundclr", this.boxbackgroundclr);
            container.style.setProperty("--my-textclr1", this.textclr1);
            container.style.setProperty("--my-completionLineclr", this.completionLineclr);
            container.style.setProperty("--my-fontSize1", this.fontSize1);
            container.style.setProperty("--my-fontSize2", this.fontSize2);
            container.style.setProperty("--my-fontSize3", this.fontSize3);
            container.style.setProperty("--my-fontSize4", this.fontSize4);

            container.style.setProperty("--my-starColor2", this.starColor2);
            container.style.setProperty("--my-starfontSize2", this.starfontSize2);

            container.style.setProperty("--my-backgroundclr3", this.backgroundclr3);
            container.style.setProperty("--my-boxbackgroundclr1", this.boxbackgroundclr1);
            container.style.setProperty("--my-textclr3", this.textclr3);
            container.style.setProperty("--my-fontSize5", this.fontSize5);
            container.style.setProperty("--my-textFontFamily3", this.textFontFamily3);
            container.style.setProperty("--my-fontSize6", this.fontSize6);
            container.style.setProperty("--my-completionCircleclr1", this.completionCircleclr1);
            container.style.setProperty("--my-completionCircleclr2", this.completionCircleclr2);
            container.style.setProperty("--my-starColor", this.starColor);
            container.style.setProperty("--my-starfontSize", this.starfontSize);

            if (this.customFontFamily1) {
                container.style.setProperty('--my-textFontFamily1', this.customFontFamily1);
            } else {
                container.style.setProperty('--my-textFontFamily1', this.textFontFamily1);
            }

            if (this.customFontFamily2) {
                container.style.setProperty('--my-textFontFamily2', this.customFontFamily2);
            } else {
                container.style.setProperty('--my-textFontFamily2', this.textFontFamily2);
            }

            this.testimonialsLoaded = true;
        }
    }

    @wire(showcustomerReviewList)
    wiredTestimonials({ error, data }) {
        if (data) {
            this.testimonials = data;
            this.updateTestimonial();
        } else if (error) {
            console.error('Error fetching testimonial data:', error);
        }
    }

    updateTestimonial() {
        if (this.testimonials && this.testimonials.length > 0) {
            const testimonial = this.testimonials[this.idx];
            this.testimonialText = testimonial?.Text__c;
            this.userPhoto = testimonial?.image_url__c;
            this.userName = testimonial?.Name;
            this.stars = this.generateStars(testimonial.stars__c);
            this.idx = (this.idx + 1) % this.testimonials.length;
        }
    }

    loadFlickity4() {
        return Promise.all([
            loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
            loadStyle(this, FLICK + '/flickity/flickity.css'),
        ]);
    }

    initializeFlickity(selector) {
        const screenWidth = window.innerWidth;
        let prevNextButtonsEnabled = true;

        if (screenWidth < 768) {
            prevNextButtonsEnabled = false;
        }

        const flickityOptions = {
            prevNextButtons: prevNextButtonsEnabled,
            autoPlay: true,
            draggable: true,
            wrapAround: true,
            pageDots: true,
        };
    
        const flickityInstance = new Flickity(this.template.querySelector(selector), flickityOptions);
    }

    loadTestimonials() {
        return showcustomerReviewList()
            .then(result => {
                this.carouselItems = result.map(item => ({
                    key: item.Id,
                    text: item.Text__c,
                    imageUrl: item.image_url__c,
                    caption: item.Name,
                    stars: this.generateStars(item.stars__c)
                }));
            })
            .catch(error => {
                console.error('Error fetching testimonial data:', error);
            });
    }

    generateStars(starsCount) {
        let stars = [];
        // If starsCount is greater than 5, set it to 5 to avoid more than 5 stars
        starsCount = Math.min(starsCount, 5);

        // Push filled stars
        for (let i = 0; i < starsCount; i++) {
            stars.push({ icon: '★', altText: 'Star', title: 'Star' });
        }

        // Push remaining stars with favorite_alt icon
        for (let i = starsCount; i < 5; i++) {
            stars.push({ icon: '☆', altText: 'Star', title: 'Star' });
        }

        return stars;
    }

}