import { LightningElement, api, wire, track } from 'lwc';
import sendEmail from '@salesforce/apex/EmailHandler.sendEmail';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_EMAIL_OBJECT from '@salesforce/schema/Subscriber__c';
import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

export default class Subscribe2 extends LightningElement {
    @track email = '';

    handleChange(event) {
        if (event.target.name === 'emailAddress') {
            this.email = event.target.value;
        }
    }

    async handleSubscribeAndSendEmail() {
        // Call handleSubscribe
      
        await this.sendEmailHandler();

          await this.handleSubscribe();
    }

    async handleSubscribe() {
        if (this.email) {
            const fields = {};
            fields[EMAIL_FIELD.fieldApiName] = this.email;

            const recordInput = { apiName: USER_EMAIL_OBJECT.objectApiName, fields };
            try {
                await createRecord(recordInput);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Thank you for subscribing!',
                        variant: 'success'
                    })
                );
                this.email = ''; // Clear the email field after successful subscription
            } catch (error) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            }
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please enter your email address',
                    variant: 'error'
                })
            );
        }
    }
    
    async sendEmailHandler() {
        if (!this.email) return; // Exit if email is empty

        // send mail
        console.log("Sending email to", this.email);
        try {
            await sendEmail({ toAddress: this.email, subject: "Subject", body: "Thank you for subscribing!"});
            console.log('Email sent successfully');
        } catch (error) {
            console.error('Error sending email:', error);
        }
    }
}
