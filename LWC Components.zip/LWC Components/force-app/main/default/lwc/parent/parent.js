import { LightningElement } from 'lwc';

export default class Parent extends LightningElement {}