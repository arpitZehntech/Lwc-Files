// // import { LightningElement, wire, track, api } from "lwc";
// // import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
// // import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
// // import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
// // import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

// // export default class PortfolioGallery2 extends LightningElement {
// //     @track itemClasses = {};

// //     @api MainHeading;
// //     @api MainHeadingClr;

// //     @api btnTextClr;
// //     @api btnBackGroundClr;
// //     @api btnBorderClr;
// //     @api btnBackGroundClrHvr;
// //     @api btnTextClrHvr;


// //     @track PortfolioObj;
// //     @track filteredPortfolioObj;
// //     @track columns = [
// //         { label: 'Name', fieldName: 'Name', type: 'text' },
// //         { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
// //     ];
// //     PortfolioRecordTypeId;
// //     Portfolios = [];


// //     renderedCallback() {
// //         this.template
// //             .querySelector("div")
// //             .style.setProperty("--my-MainHeadingClr", this.MainHeadingClr);

// //         if (this.btnTextClr) {
// //             const buttons = this.template.querySelectorAll(".filter a");
// //             buttons.forEach(button => {
// //                 if (this.btnBackGroundClr) {
// //                     button.style.setProperty("--my-btnBackGroundClr", this.btnBackGroundClr);
// //                 }
// //                 if (this.btnBorderClr) {
// //                     button.style.setProperty("--my-btnBorderClr", this.btnBorderClr);
// //                 }
// //                 if (this.btnBackGroundClrHvr) {
// //                     button.style.setProperty("--my-btnBackGroundClrHvr", this.btnBackGroundClrHvr);
// //                 }
// //                 if (this.btnTextClrHvr) {
// //                     button.style.setProperty("--my-btnTextClrHvr", this.btnTextClrHvr);
// //                 }
// //             });
// //         }


// //     }


// //     @wire(showPortfolioGallery)
// //     wiredPortfolio({ error, data }) {
// //         if (data) {
// //             this.PortfolioObj = data.map(item => ({
// //                 Id: item.Id,
// //                 Name: item.Name,
// //                 image_url__c: item.image_url__c,
// //                 Type__c: item.Type__c
// //             }));
// //             this.filteredPortfolioObj = [...this.PortfolioObj];
// //             this.updateItemClasses();
// //         } else if (error) {
// //             this.error = error;
// //         }
// //     }

// //     updateItemClasses() {
// //         this.filteredPortfolioObj.forEach((item, index) => {
// //             if (!item.class) {
// //                 const itemClass = this.generateItemClass(index);
// //                 item.class = itemClass;
// //             }
// //         });
// //     }
// //     generateItemClass(item) {
// //         const img = new Image();
// //         img.src = item.image_url__c;

// //         img.onload = () => {
// //             const width = img.width;
// //             const height = img.height;

// //             const aspectRatio = width / height;

// //             if (aspectRatio > 3 / 2) {
// //                 item.class = 'wide';
// //             } else if (aspectRatio > 63 / 82) {
// //                 item.class = 'tall';
// //             } else if (aspectRatio > 64 / 41) {
// //                 item.class = 'big';
// //             } else {
// //                 item.class = '';
// //             }
// //             this.itemClasses[item.Id] = item.class;
// //         };
// //     }


// //     @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
// //     wiredObjectInfo({ error, data }) {
// //         if (data) {
// //             this.PortfolioRecordTypeId = data.defaultRecordTypeId;
// //             this.error = undefined;
// //         } else if (error) {
// //             this.error = error;
// //             this.PortfolioRecordTypeId = undefined;
// //         }
// //     }

// //     @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
// //     wiredPicklistValues({ error, data }) {
// //         if (data) {
// //             this.Portfolios = data.values.map(picklistValue => ({
// //                 label: picklistValue.label,
// //                 value: picklistValue.value,
// //                 class: 'btn', // Adjust as per your requirements
// //                 href: '#' + picklistValue.value // Adjust as per your requirements
// //             }));
// //             this.error = undefined;
// //         } else if (error) {
// //             this.error = error;
// //             this.Portfolios = undefined;
// //         }
// //     }

// //     handleButtonClick(event) {
// //         const buttonValue = event.target.getAttribute('data-value');
// //         if (buttonValue === 'All') {
// //             this.filteredPortfolioObj = this.PortfolioObj;
// //             this.updateItemClasses(); // Update classes based on aspect ratios
// //         } else {
// //             this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
// //         }
// //     }
// // }


// import { LightningElement, wire, track, api } from "lwc";
// import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
// import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
// import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
// import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

// export default class Portfolio_gallery extends LightningElement {
//     @track itemClasses = {};

//     @api MainHeading = '';
//     @api MainHeadingClr;
//     @api title = '';

//     @api btnTextClr;
//     @api btnBackGroundClr;
//     @api btnBorderClr; 
//     @api btnBackGroundClrHvr;
//     @api btnTextClrHvr;


//     @track PortfolioObj;
//     @track filteredPortfolioObj;
//     @track columns = [
//         { label: 'Name', fieldName: 'Name', type: 'text' },
//         { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
//     ];
//     PortfolioRecordTypeId;
//     Portfolios = [];


//     renderedCallback() {
//         this.template
//             .querySelector("div")
//             .style.setProperty("--my-MainHeadingClr", this.MainHeadingClr);

//         // if (this.btnTextClr) {
//         //     const buttons = this.template.querySelectorAll(".filter a");
//         //     buttons.forEach(button => {
//         //         if (this.btnBackGroundClr) {
//         //             button.style.setProperty("--my-btnBackGroundClr", this.btnBackGroundClr);
//         //         }
//         //         if (this.btnBorderClr) {
//         //             button.style.setProperty("--my-btnBorderClr", this.btnBorderClr);
//         //         }
//         //         if (this.btnBackGroundClrHvr) {
//         //             button.style.setProperty("--my-btnBackGroundClrHvr", this.btnBackGroundClrHvr);
//         //         }
//         //         if (this.btnTextClrHvr) {
//         //             button.style.setProperty("--my-btnTextClrHvr", this.btnTextClrHvr);
//         //         }
//         //     });
//         // }

//         const buttons = this.template.querySelectorAll(".filter a");
//         buttons.forEach(button => {
//             if (this.btnBackGroundClr) {
//                 button.style.setProperty("--my-btnBackGroundClr", this.btnBackGroundClr);
//             }
//             if (this.btnBorderClr) {
//                 button.style.setProperty("--my-btnBorderClr", this.btnBorderClr);
//             }
//             if (this.btnBackGroundClrHvr) {
//                 button.style.setProperty("--my-btnBackGroundClrHvr", this.btnBackGroundClrHvr);
//             }
//             if (this.btnTextClr) {
//                 button.style.setProperty("--my-btnTextClr", this.btnTextClr);
//             }
//             if (this.btnTextClrHvr) {
//                 button.style.setProperty("--my-btnTextClrHvr", this.btnTextClrHvr);
//             }
//         });

//     }


//     @wire(showPortfolioGallery)
//     wiredPortfolio({ error, data }) {
//         if (data) {
//             this.PortfolioObj = data.map(item => ({
//                 Id: item.Id,
//                 Name: item.Name,
//                 image_url__c: item.image_url__c,
//                 Type__c: item.Type__c
//             }));
//             this.filteredPortfolioObj = [...this.PortfolioObj];
//         } else if (error) {
//             this.error = error;
//         }
//     }


//     @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
//     wiredObjectInfo({ error, data }) {
//         if (data) {
//             this.PortfolioRecordTypeId = data.defaultRecordTypeId;
//             this.error = undefined;
//         } else if (error) {
//             this.error = error;
//             this.PortfolioRecordTypeId = undefined;
//         }
//     }

//     @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
//     wiredPicklistValues({ error, data }) {
//         if (data) {
//             this.Portfolios = data.values.map(picklistValue => ({
//                 label: picklistValue.label,
//                 value: picklistValue.value,
//                 class: 'btn', // Adjust as per your requirements
//                 href: '#' + picklistValue.value // Adjust as per your requirements
//             }));
//             this.error = undefined;
//         } else if (error) {
//             this.error = error;
//             this.Portfolios = undefined;
//         }
//     }

//     handleButtonClick(event) {
//         const buttonValue = event.target.getAttribute('data-value');
//         if (buttonValue === 'All') {
//             this.filteredPortfolioObj = this.PortfolioObj;
//         } else {
//             this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
//         }
//     }
// }

import { LightningElement, wire, track, api } from "lwc";
import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

export default class PortfolioGallery extends LightningElement {
    @api MainHeading = '';
    @api MainHeadingClr;
    @api title;
    @api btnTextClr;
    @api btnBackGroundClr;
    @api btnBorderClr;
    @api btnBackGroundClrHvr;
    @api btnTextClrHvr;

    @track PortfolioObj;
    @track visiblePortfolioObj;
    @track remainingCount = 0;
    @track showLoadMoreButton = false;

    @track filteredPortfolioObj;

    PortfolioRecordTypeId;
    Portfolios = [];

    connectedCallback() {
        this.loadPortfolioData();
    }

    loadPortfolioData() {
        showPortfolioGallery()
            .then(result => {
                this.PortfolioObj = result.map(item => ({
                    Id: item.Id,
                    Name: item.Name,
                    image_url__c: item.image_url__c,
                    Type__c: item.Type__c,
                    class: 'image'
                }));
                this.updateVisiblePortfolio();
            })
            .catch(error => {
                console.error('Error fetching portfolio data: ', error);
            });
    }

    @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
    wiredObjectInfo({ error, data }) {
        if (data) {
            this.PortfolioRecordTypeId = data.defaultRecordTypeId;
        } else if (error) {
            console.error('Error fetching object info: ', error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.Portfolios = data.values.map(picklistValue => ({
                label: picklistValue.label,
                value: picklistValue.value,
                class: 'btn',
                href: '#' + picklistValue.value
            }));
        } else if (error) {
            console.error('Error fetching picklist values: ', error);
        }
    }

    updateVisiblePortfolio() {
        this.visiblePortfolioObj = this.PortfolioObj.slice(0, 6);
        this.showLoadMoreButton = this.PortfolioObj.length > 6;
    }

    loadMoreImages() {
        const nextIndex = this.visiblePortfolioObj.length;
        const additionalImages = this.PortfolioObj.slice(nextIndex, nextIndex + 6);
        this.visiblePortfolioObj = [...this.visiblePortfolioObj, ...additionalImages];
        this.updatePlusButtonVisibility();
    }

    updatePlusButtonVisibility() {
        this.remainingCount = Math.max(0, this.PortfolioObj.length - this.visiblePortfolioObj.length);
        this.showLoadMoreButton = this.remainingCount > 0;
    }

    handleButtonClick(event) {
        const buttonValue = event.target.dataset.value;
        if (buttonValue === 'All') {
            this.visiblePortfolioObj = this.PortfolioObj;
        } else {
            this.visiblePortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
        }
    }
}
