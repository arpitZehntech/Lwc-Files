import { LightningElement, track ,api} from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import COUNT from '@salesforce/resourceUrl/counterup';

export default class CounterTest extends LightningElement {

  @api contentId;
  @api bntLabel
    @track counts = [
        { number: 4500, current: 0, label: 'Projects Completed', image: '/resources/project_completed_image.jpg' },
        { number: 5000, current: 0, label: 'Coffees Consumed', image: '/resources/project_completed_image.jpg' },
        { number: 4040, current: 0, label: 'Happy Customers', image: '/resources/project_completed_image.jpg' },
        { number: 50900, current: 0, label: 'Lines of Code', image: '/resources/project_completed_image.jpg' }
    ];

    connectedCallback() {
        this.startCounters();
    }

    startCounters() {
        const intervalTime = 1; // Set the default interval time in milliseconds
        const intervalTimeForSmallValues = 50; // Set a faster interval time for values less than 150

        // Find the maximum number of iterations needed to finish all counters at the same time
        const maxIterations = Math.max(...this.counts.map(item => Math.ceil(item.number / 150)));

        // Execute the interval function for each counter
        this.counts.forEach((item) => {
            const incrementValue = Math.ceil(item.number / maxIterations);
            const currentIntervalTime = item.number < 150 ? intervalTimeForSmallValues : intervalTime;

            const intervalFunction = () => {
                item.current += incrementValue;

                if (item.current < item.number) {
                    setTimeout(intervalFunction, currentIntervalTime);
                }
            };

            intervalFunction();
        });
    }
    }
    
    //     connectedCallback() {
    //     Promise.all([
    //          loadScript(this, COUNT + '/counterup/jquery.min.js'),
    //          loadScript(this, COUNT + '/counterup/jquery.counterup.min.js'),
    //          loadScript(this, COUNT + '/counterUp/jquery.waypoints.min.js')
    //     ]).then(() => {
    //         // Initialize the counterUp library
    //         this.animateCounters();

    //         // Add counterUp initialization after the animation
    //         this.initCounterUp();
    //     }).catch(e => {
    //         console.log('Error:' + e);
    //     });
    // }

    // animateCounters() {
    //         const counters = this.template.querySelectorAll('.c-counter');
    //         counters.forEach(counterElement => {
    //                 const startValue = 0;
    //         const endValue = parseInt(counterElement.dataset.value, 10);
    //         const duration = 2000;
    //         const increment = Math.floor(endValue / (duration / 10));

    //         let currentValue = startValue;

    //         const updateCounter = () => {
    //             counterElement.textContent = currentValue.toLocaleString();
    //             currentValue += increment;

    //             if (currentValue <= endValue) {
    //                 requestAnimationFrame(updateCounter);
    //             } else {
    //                 counterElement.textContent = endValue.toLocaleString();
    //             }
    //         };

    //         requestAnimationFrame(updateCounter);
    //     });
    // }

    // initCounterUp() {
    //     // Initialize counterUp for each counter element
    //     const counterElements = this.template.querySelectorAll('div.c-counter');
    //     counterElements.forEach(element => {
    //         $(element).counterUp({
    //             delay: 10,
    //             time: 2000
    //         });
    //     });
    // }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // @track ProjectsCompleted = 0;
    // @track CoffeesConsumed = 0;
    // @track HappyCustomers = 0;
    // @track LinesofCode = 0;

    // connectedCallback() {
    //     this.numCounter("CoffeesConsumed", 44, 10);
    //     this.numCounter("HappyCustomers", 12, 100);
    //     this.numCounter("ProjectsCompleted", 43, 10);
    //     this.numCounter("LinesofCode", 43, 10);
    // }

    // numCounter(tagId, maxCount, speed) {
    //     let initialNumber = 0;
    //     const counterDelay = setInterval(() => {
    //         this.template.querySelector(`#${tagId}`).innerHTML = initialNumber;
    //         initialNumber++;
    //     }, speed);
        
    //     const totalTime = () => {
    //         clearInterval(counterDelay);
    //     };
        
    //     const totalPeriod = speed * maxCount;
    //     setTimeout(totalTime, totalPeriod);
    // }