// import { LightningElement ,api} from 'lwc';
// import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
// import FLICK from '@salesforce/resourceUrl/flickity';

// export default class LogoCarouselChild1 extends LightningElement {
    
//     @api logo1;
//     @api logo2 ;
//     @api logo3 ;
//     @api logo4 ;
//     @api logo5 ;
//     @api logo6 ;
//     @api boolean1 ;
//     @api cell_align1;
//     @api contain1;
//     @api draggable1;
//     @api wrap_around1;
//     @api auto_play1;
//     @api prev_next_buttons1;

//     connectedCallback() {
//         Promise.all([
//             loadScript(this, FLICK + '/flickity/jquery.min.js'),
//             loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
//         ])
//             .then(() => {
//                 return Promise.all([
//                     loadStyle(this, FLICK + '/flickity/flickity.css'),
//                 ]);
//             })
//             .then(() => {
//                 // Flickity prototype extension
//                 Flickity.prototype.getSelectedCellIndexes = function () {
//                     return this.selectedCells.map(function (cell) {
//                         return this.cells.indexOf(cell);
//                     }, this);
//                 };

//                 // Flickity initialization in Lightning Web Component
//                 $(this.template.querySelector('div[class="carousel"]')).flickity({
//                     // imagesLoaded: false,
//                     cellAlign: this.cell_align1,
//                     // percentPosition: false,
//                     // initialIndex: 1,
//                     contain: this.contain1,
//                     wrapAround: this.wrap_around1,
//                     // lazyLoad: false,
//                     pageDots: this.boolean1,
//                     // groupCells: false,
//                     draggable: this.draggable1,
//                     prevNextButtons: this.prev_next_buttons1,
//                     autoPlay: this.auto_play1,
//                     selectedAttraction: 0.2,
//                     friction: 0.8
//                 });
//             })
//             .catch((e) => {
//                 console.log('Error:' + e);
//             });
//     }
// }


import { LightningElement ,api} from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity';

export default class LogoCarouselChild1 extends LightningElement {
    
    @api logo1;
    @api logo2 ;
    @api logo3 ;
    @api logo4 ;
    @api logo5 ;
    @api logo6 ;
    @api boolean1 ;
    @api cell_align1;
    @api contain1;
    @api draggable1;
    @api wrap_around1;
    @api auto_play1;
    @api prev_next_buttons1;

    connectedCallback() {
        Promise.all([
            loadScript(this, FLICK + '/flickity/jquery.min.js'),
            loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
        ])
            // .then(() => {
            //     return Promise.all([
            //         // loadStyle(this, FLICK + '/flickity/flickity.css'),
            //     ]);
            // })
            .then(() => {
                // Flickity prototype extension
                Flickity.prototype.getSelectedCellIndexes = function () {
                    return this.selectedCells.map(function (cell) {
                        return this.cells.indexOf(cell);
                    }, this);
                };

                $(this.template.querySelector('div[class="grid-slide-wrap"]')).flickity({
             
                        // imagesLoaded: false,
                    cellAlign: this.cell_align1,
                    // percentPosition: false,
                    // initialIndex: 1,
                    contain: this.contain1,
                    wrapAround: this.wrap_around1,
                    // lazyLoad: false,
                    pageDots: this.boolean1,
                    // groupCells: false,
                    draggable: this.draggable1,
                    prevNextButtons: this.prev_next_buttons1,
                    autoPlay: this.auto_play1,
                    selectedAttraction: 0.2,
                    friction: 0.8
                  });
            })
            .catch((e) => {
                console.log('Error:' + e);
            });
    }
}