import { LightningElement } from 'lwc';
export default class HelloWorld extends LightningElement {

  // greeting = 'World';
  // handleClick(event) {
  //   this.greeting = this.template.querySelector("Lightning-input").value;
  // }

  firstName = '';
  lastName = '';
  

   handleClick(event) {
     
    var input = this.template.querySelectorAll("Lightning-input");

    input.forEach(function(element){

      if(element.name == 'fname')
      {
        this.firstName = element.value;
      }
      else if(element.name == 'lname')
      {
        this.lastName = element.value;
      }
    },this);
   }

}