// import { LightningElement, track } from 'lwc';

// export default class tabAndAccordion3 extends LightningElement {

//     @track activeTabValue = 'TAB 1';
//     accordion1ActiveSection = null;
//     accordion2ActiveSection = null;

//     handleTabChange(event) {
//         this.activeTabValue = event.detail.value;
//         // Reset accordion active section when tab changes
//         this.accordion1ActiveSection = null;
//         this.accordion2ActiveSection = null;
//     }
// }

import { LightningElement, wire, track,api} from 'lwc';
import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

export default class TabAndAccordion3 extends LightningElement {
    @track tabs = [];
    @api tabOrder = '';

    @track activeTabValue = 'TAB 1';
    accordion1ActiveSection = null;
    accordion2ActiveSection = null;

   

    @wire(fetchTabData)
    wiredTabData({ error, data }) {
        if (data) {
            this.tabs = data.map(tab => ({
                label: tab.label,
                subheadings: tab.subheadings.map(subheading => ({
                    label: subheading.label,
                    content: subheading.content
                }))
            }));
            // Check if the tab order property is set
            if (this.tabOrder) {
                // Split the tab order string into an array
                const orderArray = this.tabOrder.split(',').map(item => item.trim());
                // Sort the tabs based on the order specified in the tab order property
                this.tabs.sort((a, b) => {
                    return orderArray.indexOf(a.label) - orderArray.indexOf(b.label);
                });
            }
        } else if (error) {
            console.error('Error fetching tab data:', error);
        }
    }

    handleTabChange(event) {
        this.activeTabValue = event.detail.value;
        // Reset accordion active section when tab changes
        this.accordion1ActiveSection = null;
        this.accordion2ActiveSection = null;
    }

}

