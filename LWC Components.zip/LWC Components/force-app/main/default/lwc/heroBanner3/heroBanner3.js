
// bannerCarousel.js
import { LightningElement } from 'lwc';

export default class HeroBanner3 extends LightningElement {
    carouselId = 'mainBanner';
    carouselInterval = 7000;

    carouselItems = [
        {
            key: 0,
            index: 0,
            active: 'active',
            imageUrl: 'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
            title: '1st slide label',
            content: 'Some representative placeholder content for the first slide.',
            buttons: [
                { key: 0, label: 'Lorem Ipsum', classes: 'btn btn-secondary px-lg-5 px-md-4 px-2 py-2 rounded-0 border' },
                { key: 1, label: 'Dolor Iseter', classes: 'btn btn-success px-lg-5 px-md-4 px-2 py-2 rounded-0 border' }
            ]
        },
        {
            key: 1,
            index: 1,
            active: '',
            imageUrl: 'https://images.pexels.com/photos/206359/pexels-photo-206359.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
            title: '2nd slide label',
            content: 'Some representative placeholder content for the second slide.',
            buttons: [
                { key: 0, label: 'Button 1', classes: 'btn btn-secondary px-lg-5 px-md-4 px-2 py-2 rounded-0 border' },
                { key: 1, label: 'Button 2', classes: 'btn btn-success px-lg-5 px-md-4 px-2 py-2 rounded-0 border' }
            ]
        },
        {
            key: 2,
            index: 2,
            active: '',
            imageUrl: 'https://images.pexels.com/photos/933054/pexels-photo-933054.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
            title: '3rd slide label',
            content: 'Some representative placeholder content for the third slide.',
            buttons: [
                { key: 0, label: 'Button 1', classes: 'btn btn-secondary px-lg-5 px-md-4 px-2 py-2 rounded-0 border' },
                { key: 1, label: 'Button 2', classes: 'btn btn-success px-lg-5 px-md-4 px-2 py-2 rounded-0 border' }
            ]
        },
        // Add more carousel items as needed
    ];
}
