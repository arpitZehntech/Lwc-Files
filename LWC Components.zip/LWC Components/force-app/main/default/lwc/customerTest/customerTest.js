import { LightningElement, track, wire } from 'lwc';
import showcustomerReviewList from '@salesforce/apex/customerReviewClass.showcustomerReview';

export default class CustomerTest extends LightningElement {
    @track testimonialText;
    @track userPhoto;
    @track userName;
    @track stars = [];

    idx = 0;

    @wire(showcustomerReviewList)
    testimonials;

    connectedCallback() {
        this.updateTestimonial();
        setInterval(() => this.updateTestimonial(), 10000);
    }

    updateTestimonial() {
        if (this.testimonials && this.testimonials.data && this.testimonials.data.length > 0) {
            const testimonial = this.testimonials.data[this.idx];
            this.testimonialText = testimonial.Text__c;
            this.userPhoto = testimonial.image_url__c;
            this.userName = testimonial.Name;

            this.stars = this.generateStars(testimonial.stars__c);

            this.idx = (this.idx + 1) % this.testimonials.data.length;
        }
    }

    generateStars(starsCount) {
        let stars = [];
        // If starsCount is greater than 5, set it to 5 to avoid more than 5 stars
        starsCount = Math.min(starsCount, 5);

        // Push filled stars
        for (let i = 0; i < starsCount; i++) {
            stars.push({ icon: '★', altText: 'Star', title: 'Star' });
        }

        // Push remaining stars with favorite_alt icon
        for (let i = starsCount; i < 5; i++) {
            stars.push({ icon: '☆', altText: 'Star', title: 'Star' });
        }

        return stars;
    }
}
