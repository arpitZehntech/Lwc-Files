import { LightningElement, track } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import showcustomerReviewList from '@salesforce/apex/customerReviewClass.showcustomerReview';
import FLICK from '@salesforce/resourceUrl/flickity';

export default class Customer_Reviews2 extends LightningElement {
    
    @track carouselItems = [];

    connectedCallback() {
        this.loadFlickity4();
        this.loadTestimonials();
    }



    
    loadFlickity4() {
        loadScript(this, FLICK + '/flickity/jquery.min.js')
            .then(() => {
                return loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js');
            })
            .then(() => {
                return loadStyle(this, FLICK + '/flickity/flickity.css');
            })
            .then(() => {
                // Initialize Flickity with the appropriate options
                this.initializeFlickity();
            })
            .catch(error => {
                console.error('Error loading Flickity resources:', error);
            });
    }

    initializeFlickity() {
        // const screenWidth = window.innerWidth;
        // let prevNextButtonsEnabled = true; // Default value for prevNextButtons

        // if (screenWidth >= 768) {
        //     // PrevNextButtons are disabled for screen widths greater than or equal to 768px
        //     prevNextButtonsEnabled = false;
        // }

        // Initialize Flickity with the appropriate options
        $(this.template.querySelector('div[class="carousel4"]')).flickity({
            prevNextButtons: true,
            autoPlay: true,
            draggable: true,
            wrapAround: true,
            pageDots: true,
        });
    }

    loadTestimonials() {
        showcustomerReviewList()
            .then(result => {
                this.carouselItems = result.map(item => ({
                    key: item.Id,
                    text: item.Text__c,
                    imageUrl: item.image_url__c,
                    caption: item.Name,
                    stars: this.generateStars(item.stars__c) // Generate stars dynamically based on numeric value
                }));
            })
            .catch(error => {
                console.error('Error fetching testimonial data:', error);
            });
    }

    generateStars(starsCount) {
        let stars = [];
        // If starsCount is greater than 5, set it to 5 to avoid more than 5 stars
        starsCount = Math.min(starsCount, 5);

        // Push filled stars
        for (let i = 0; i < starsCount; i++) {
            stars.push({ icon: 'utility:favorite', altText: 'Star', title: 'Star' });
        }

        // Push remaining stars with favorite_alt icon
        for (let i = starsCount; i < 5; i++) {
            stars.push({ icon: 'utility:favorite_alt', altText: 'Star', title: 'Star' });
        }

        return stars;
    }
}
