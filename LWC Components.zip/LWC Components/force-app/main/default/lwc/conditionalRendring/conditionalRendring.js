import { LightningElement } from 'lwc';

export default class ConditionalRendring extends LightningElement {

    
    areDetailVisible = false;

    handleChange(event)
    {
        this.areDetailVisible = event.target.checked;
    }
}