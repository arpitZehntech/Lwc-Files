// import { LightningElement } from 'lwc';

// const testimonials = [
//     {
//         name: 'Miyah Myles',
        
//         photo: 'https://patelcom3-dev-ed--c.vf.force.com/resource/1706709229000/imgUrl',
//         text:
//             "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. This guy is an amazing developer. He stresses on good, clean code and pays heed to the details. I love developers who respect each and every aspect of a throughly thought out design and do their best to put it in code. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
//     },
//     {
//         name: 'Iida Niskanen',
       
//         photo: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1051&q=80',
//         text:
//             "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. This guy is an amazing developer. He stresses on good, clean code and pays heed to the details. I love developers who respect each and every aspect of a throughly thought out design and do their best to put it in code. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
//     },
//     {
//         name: 'Miyah Myles',
       
//         photo: 'https://images.unsplash.com/photo-1577880216142-8549e9488dad?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80',
//         text:
//             "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. This guy is an amazing developer. He stresses on good, clean code and pays heed to the details. I love developers who respect each and every aspect of a throughly thought out design and do their best to put it in code. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
//     },
//     {
//         name: 'Miyah Myles',
        
//         photo: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d',
//         text:
//             "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. This guy is an amazing developer. He stresses on good, clean code and pays heed to the details. I love developers who respect each and every aspect of a throughly thought out design and do their best to put it in code. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
//     },
//     {
//         name: 'Miyah Myles',
      
//         photo: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61',
//         text:
//             "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. This guy is an amazing developer. He stresses on good, clean code and pays heed to the details. I love developers who respect each and every aspect of a throughly thought out design and do their best to put it in code. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
//     },
  
// ];

// export default class Customer_Reviews1 extends LightningElement {
//     idx = 0;

//     connectedCallback() {
//         this.updateTestimonial();
//         setInterval(this.updateTestimonial.bind(this), 9200);
//     }

//     updateTestimonial() {
//         const testimonial = testimonials[this.idx];
//         this.testimonialText = testimonial.text;
//         this.userPhoto = testimonial.photo;
//         this.userName = testimonial.name;
     
//         this.idx = (this.idx + 1) % testimonials.length;
//     }
// }

import { LightningElement, track, wire } from 'lwc';
import showcustomerReviewList from '@salesforce/apex/customerReviewClass.showcustomerReview';

export default class Customer_Reviews1 extends LightningElement {

    
    @track testimonialText;
    @track userPhoto;
    @track userName;
    idx = 0;

    @wire(showcustomerReviewList)
    testimonials;

    connectedCallback() {
        this.updateTestimonial();
        setInterval(() => this.updateTestimonial(), 10000);
    }

    updateTestimonial() {
        if (this.testimonials && this.testimonials.data) {
            const testimonial = this.testimonials.data[this.idx];
            this.testimonialText = testimonial.Text__c;
            this.userPhoto = testimonial.image_url__c;
            this.userName = testimonial.Name;

            this.idx = (this.idx + 1) % this.testimonials.data.length;
        }
    }
}
