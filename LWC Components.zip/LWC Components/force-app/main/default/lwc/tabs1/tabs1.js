import { LightningElement, wire } from 'lwc';
import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

export default class Tabs1 extends LightningElement {
    tabs = [];

    @wire(fetchTabData)
    wiredTabData({ error, data }) {
        if (data) {
            this.tabs = data.map((tab, index) => ({
                label: tab.label,
                checked: tab.checked,
                activeSections: [], // Initialize activeSections
                subheadings: tab.subheadings.map(subheading => ({
                    label: subheading.label,
                    content: subheading.content
                })),
                cssClass: `tab-content tab-content-${index + 1} typography` // Dynamic CSS class
            }));
        } else if (error) {
            console.error('Error fetching tab data:', error);
        }
    }

    handleSectionToggle(event) {
        const tabLabel = event.target.dataset.tabid;
        const activeSections = event.detail.openSections;
        
        // Update active sections for the specific tab
        this.tabs = this.tabs.map(tab => {
            if (tab.label === tabLabel) {
                tab.activeSections = activeSections;
            }
            return tab;
        });
    }

    handleTabChange(event) {
        const tabLabel = event.target.dataset.tabid;
        
        // Update checked status for the specific tab
        this.tabs = this.tabs.map(tab => {
            tab.checked = tab.label === tabLabel;
            return tab;
        });
    }
}
