import { LightningElement, api } from 'lwc';

export default class PortfolioLightbox extends LightningElement {
    @api isLightboxOpen = false;
    @api imageUrl;

    closeLightbox() {
        const closeEvent = new CustomEvent('close');
        this.dispatchEvent(closeEvent);
    }
}