import { LightningElement } from 'lwc';

export default class HideShow extends LightningElement {

    isVisible = true;

    handleChange()
    {
        if(this.isVisible == true)
        {
            this.isVisible = false;
        }
        else{
            this.isVisible = true;
        }
    }
}