import { LightningElement ,api} from 'lwc';

export default class Child extends LightningElement {

    // upperCaseItemName = 'defaut value';

    // @api
    // get itemName()
    // {
    //     return this.upperCaseItemName;
    // }

    // set itemName(value)
    // {
    //     this.upperCaseItemName = value.toUpperCase();
    // }

    // @api
    // firstName = 'arpit';

}