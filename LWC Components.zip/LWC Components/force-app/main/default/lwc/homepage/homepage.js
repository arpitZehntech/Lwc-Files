import { LightningElement, track,api} from 'lwc';

export default class Homepage extends LightningElement {
    // @track isHovered = false;

    // handleMouseOver() {
    //     this.isHovered = true;
    // }

    // handleMouseOut() {
    //     this.isHovered = false;
    // }
    // @api backgroundImg;
    @api textContent;
    @api textContentClr;

    renderedCallback()
    {
        this.template.querySelector("div").style.setProperty("--my-textContentClr",this.textContentClr);
    }

}
