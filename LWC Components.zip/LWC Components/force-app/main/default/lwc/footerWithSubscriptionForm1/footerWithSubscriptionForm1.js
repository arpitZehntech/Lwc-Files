import { LightningElement, api, track } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_EMAIL_OBJECT from '@salesforce/schema/Subscriber__c';
import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

export default class FooterWithSubscriptionForm1 extends LightningElement {

    @api selectfooter;

    @track showhideFirst = false;
    @track showhideSecond = false;

    @track email = '';

    @api block1heading;
    @api block2heading;
    @api block3heading;

    @api block1SubHeading1;
    @api block1SubHeading2;
    @api block1SubHeading3;
    @api block1SubHeading4;
    @api block1SubHeading5;

    @api block2SubHeading1;
    @api block2SubHeading2;
    @api block2SubHeading3;
    @api block2SubHeading4;
    @api block2SubHeading5;
    @api block2SubHeading6;
    @api block2SubHeading7;
    @api block2SubHeading8;


    @api block1SubHeading1Url;
    @api block1SubHeading2Url;
    @api block1SubHeading3Url;
    @api block1SubHeading4Url;
    @api block1SubHeading5Url;

    @api block2SubHeading1Url;
    @api block2SubHeading2Url;
    @api block2SubHeading3Url;
    @api block2SubHeading4Url;
    @api block2SubHeading5Url;
    @api block2SubHeading6Url;
    @api block2SubHeading7Url;
    @api block2SubHeading8Url;


    @api image1Footer1;
    @api image2Footer1;
    @api image3Footer1;
    @api image4Footer1;

    @api image1UrlFooter1;
    @api image2UrlFooter1;
    @api image3UrlFooter1;
    @api image4UrlFooter1;

    @api copyrightYear;
    @api copyrightTitle;
    @api copyrightTitleUrl;

    @api componyLogo;
    @api textUnderLogo;
    @api textUnderSubscribe;

    @api image1Footer2;
    @api image2Footer2;
    @api image3Footer2;



    @api footer2mainheading1;
    @api footer2mainheading2;
    @api footer2mainheading3;

    @api footer2mainheading1Content1;
    @api footer2mainheading2Content2;
    @api footer2mainheading3Content3;

    @api footer1Backgroundclr1half;
    @api footer1Backgroundclr2half;
    @api footer1blockheadingclr;
    @api footer1SubHeadingclr;
    @api footer1SubHeadingclrHvr;
    @api footer1Copyrightclr;
    @api footer1CopyrightTitelclr;
    @api footer1CopyrightTitelclrHvr;

    @api footer2Backgroundclr;
    @api footer2Headingclr;
    @api footer2SubHeadingclr;
    @api footer2mainheadingclr;
    @api footer2mainheadingContentclr;
    @api footer2textclr;
    @api footer2CopyrightBgclr;
    @api footer2Copyrightclr;
    @api footer2CopyrightTitleClr;
    @api footer2SubHeadingclrHvr;


    @api theme2HeadUnderlineClr;
    @api theme1HeadUnderlineClr;

    @api subscribeInputBoxClr;
    @api subscribeInputTextClr;
    @api subscribeInputPlaceHolderClr;



    @api subscribeInputBox2Clr;
    @api subscribeInputText2Clr;
    @api subscribeInputBoxBorder2Clr;

    @api subscribeInputButton2Clr;
    @api subscribeInputButtonBorder2Clr;



    connectedCallback() {

        if (this.selectfooter === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectfooter === 'Theme 2') {
            this.showhideSecond = true;
        }

    }

    renderedCallback() {
        
        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1Backgroundclr1half", this.footer1Backgroundclr1half);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1Backgroundclr2half", this.footer1Backgroundclr2half);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1blockheadingclr", this.footer1blockheadingclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1SubHeadingclr", this.footer1SubHeadingclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1SubHeadingclrHvr", this.footer1SubHeadingclrHvr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1Copyrightclr", this.footer1Copyrightclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1CopyrightTitelclr", this.footer1CopyrightTitelclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer1CopyrightTitelclrHvr", this.footer1CopyrightTitelclrHvr);





        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2Backgroundclr", this.footer2Backgroundclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2Headingclr", this.footer2Headingclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2SubHeadingclr", this.footer2SubHeadingclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2mainheadingclr", this.footer2mainheadingclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2mainheadingContentclr", this.footer2mainheadingContentclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2textclr", this.footer2textclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2CopyrightBgclr", this.footer2CopyrightBgclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2Copyrightclr", this.footer2Copyrightclr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2CopyrightTitleClr", this.footer2CopyrightTitleClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-footer2SubHeadingclrHvr", this.footer2SubHeadingclrHvr);


        this.template
        .querySelector("div")
        .style.setProperty("--my-theme2HeadUnderlineClr", this.theme2HeadUnderlineClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-theme1HeadUnderlineClr", this.theme1HeadUnderlineClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputBoxClr", this.subscribeInputBoxClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputTextClr", this.subscribeInputTextClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputPlaceHolderClr", this.subscribeInputPlaceHolderClr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputBox2Clr", this.subscribeInputBox2Clr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputText2Clr", this.subscribeInputText2Clr);

        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputBoxBorder2Clr", this.subscribeInputBoxBorder2Clr);
        
        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputButton2Clr", this.subscribeInputButton2Clr);

        
        this.template
        .querySelector("div")
        .style.setProperty("--my-subscribeInputButtonBorder2Clr", this.subscribeInputButtonBorder2Clr);

    }

    handleChange(event) {
        if (event.target.name === 'emailAddress') {
            this.email = event.target.value;
        }
    }

    async handleSubscribe() {
        if (this.email) {
            const fields = {};
            fields[EMAIL_FIELD.fieldApiName] = this.email;

            const recordInput = { apiName: USER_EMAIL_OBJECT.objectApiName, fields };
            try {
                await createRecord(recordInput);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Thank you for subscribing!',
                        variant: 'success'
                    })
                );
                this.email = ''; // Clear the email field after successful subscription
            } catch (error) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            }
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please enter your email address',
                    variant: 'error'
                })
            );
        }
    }

}
