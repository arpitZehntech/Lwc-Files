// import { LightningElement, wire, track } from "lwc";
// import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
// import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
// import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
// import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

// export default class PortfolioGallery2 extends LightningElement {
//   @track PortfolioObj;
//   @track filteredPortfolioObj;
//   @track columns = [
//     { label: 'Name', fieldName: 'Name', type: 'text' },
//     { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
//   ];
//   PortfolioRecordTypeId;
//   Portfolios;
//   error;

//   @wire(showPortfolioGallery)
//   wiredPortfolio({error, data}) {
//     if (data) {
//       this.PortfolioObj = data.map(item => ({
//         Id: item.Id,
//         Name: item.Name,
//         image_url__c: item.image_url__c,
//         Type__c: item.Type__c 
//       }));
//       this.filteredPortfolioObj = this.PortfolioObj;
//     } else if (error) {
//       this.error = error;
//     }
//   }

//   @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
//   wiredObjectInfo({error, data}) {
//     if (data) {
//       this.PortfolioRecordTypeId = data.defaultRecordTypeId;
//       this.error = undefined;
//     } else if (error) {
//       this.error = error;
//       this.PortfolioRecordTypeId = undefined;
//     }
//   }

//   @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
//   wiredPicklistValues({error, data}) {
//     if (data) {
//       this.Portfolios = data.values;
//       this.error = undefined;
//     } else if (error) {
//       this.error = error;
//       this.Portfolios = undefined;
//     }
//   }

//   handleButtonClick(event) {
//     const buttonValue = event.target.value;
//     if (buttonValue === 'All') {
//       this.filteredPortfolioObj = this.PortfolioObj; 
//     } else {
//       this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
//       console.log("buttonValue :" +buttonValue);
//     }
//   }
// }
import { LightningElement, wire, track } from "lwc";
import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

export default class PortfolioGallery2 extends LightningElement {
    @track PortfolioObj;
    @track filteredPortfolioObj;
    @track columns = [
        { label: 'Name', fieldName: 'Name', type: 'text' },
        { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
    ];
    PortfolioRecordTypeId;
    Portfolios = [];

    @wire(showPortfolioGallery)
    wiredPortfolio({error, data}) {
        if (data) {
            this.PortfolioObj = data.map((item, index) => ({
                Id: item.Id,
                Name: item.Name,
                image_url__c: item.image_url__c,
                Type__c: item.Type__c,
                class: this.generateItemClass(index) // Generate class dynamically
            }));
            this.filteredPortfolioObj = this.PortfolioObj;
        } else if (error) {
            this.error = error;
        }
    }

    generateItemClass(index) {
        return 'item-' + (index % 5 + 1);
    }

    @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
    wiredObjectInfo({error, data}) {
        if (data) {
            this.PortfolioRecordTypeId = data.defaultRecordTypeId;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.PortfolioRecordTypeId = undefined;
        }
    }

    @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
    wiredPicklistValues({error, data}) {
        if (data) {
            this.Portfolios = data.values.map(picklistValue => ({
                label: picklistValue.label,
                value: picklistValue.value,
                class: 'btn', // Adjust as per your requirements
                href: '#' + picklistValue.value // Adjust as per your requirements
            }));
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.Portfolios = undefined;
        }
    }

    handleButtonClick(event) {
        const buttonValue = event.target.getAttribute('data-value');
        if (buttonValue === 'All') {
            this.filteredPortfolioObj = this.PortfolioObj;
        } else {
            this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
            console.log("buttonValue :" +buttonValue);
        }
    }

    itemStyle(imageUrl) {
        return `background-image: url('${imageUrl}')`;
    }
}