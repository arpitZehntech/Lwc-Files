// import { LightningElement, track } from 'lwc';
// import sendEmail from '@salesforce/apex/EmailHandler.sendEmail';
// import { createRecord } from 'lightning/uiRecordApi';
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import SUBSCRIBER_OBJECT from '@salesforce/schema/Subscriber__c';
// import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

// export default class Subscribe1 extends LightningElement {
//     @track email = '';

//     handleEmailChange(event) {
//         this.email = event.target.value;
//     }

//     async handleSubscribe() {
//         if (this.email) {
//             const fields = {};
//             fields[EMAIL_FIELD.fieldApiName] = this.email;

//             const recordInput = { apiName: SUBSCRIBER_OBJECT.objectApiName, fields };
//             try {
//                 await createRecord(recordInput);
//                 // Send email using Apex method
//                 await this.sendSubscriptionEmail();
//                 this.dispatchEvent(
//                     new ShowToastEvent({
//                         title: 'Success',
//                         message: 'Thank you for subscribing!',
//                         variant: 'success'
//                     })
//                 );
//                 this.email = ''; // Clear the email field after successful subscription
//             } catch (error) {
//                 this.dispatchEvent(
//                     new ShowToastEvent({
//                         title: 'Error',
//                         message: error.body.message || 'Unknown error',
//                         variant: 'error'
//                     })
//                 );
//             }
//         } else {
//             this.dispatchEvent(
//                 new ShowToastEvent({
//                     title: 'Error',
//                     message: 'Please enter your email address',
//                     variant: 'error'
//                 })
//             );
//         }
//     }

// }


import { LightningElement, api, wire, track } from 'lwc';
import sendEmail from '@salesforce/apex/EmailHandler.sendEmail';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_EMAIL_OBJECT from '@salesforce/schema/Subscriber__c';
import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

export default class Subscribe1 extends LightningElement {
    @track email = '';


    
    handleChange(event) {
        if (event.target.name === 'emailAddress') {
            this.email = event.target.value;
        }
    }

    async handleSubscribe() {
 
          await this.handleSubscribe();
    }

    async handleSubscribe() {
        if (this.email) {
            const fields = {};
            fields[EMAIL_FIELD.fieldApiName] = this.email;

            const recordInput = { apiName: USER_EMAIL_OBJECT.objectApiName, fields };
            try {
                await createRecord(recordInput);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Thank you for subscribing!',
                        variant: 'success'
                    })
                );
                this.email = ''; // Clear the email field after successful subscription
            } catch (error) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            }
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please enter your email address',
                    variant: 'error'
                })
            );
        }
    }

}
