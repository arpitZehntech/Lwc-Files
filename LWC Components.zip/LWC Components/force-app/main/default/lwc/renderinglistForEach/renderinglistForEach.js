import { LightningElement } from 'lwc';

export default class RenderinglistForEach extends LightningElement {

    contacts = [
        {
            Id : 1,
            Name : 'arpit',
            Title : 'Founder'
        },
        {
            Id : 2,
            Name : 'mohit',
            Title : 'CEO'
        },  {
            Id : 3,
            Name : 'aashish',
            Title : 'Manager'
        }
    ];
}