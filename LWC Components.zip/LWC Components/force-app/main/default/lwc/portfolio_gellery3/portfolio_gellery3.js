// import { LightningElement, wire, track } from "lwc";
// import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
// import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
// import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
// import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

// export default class PortfolioGallery2 extends LightningElement {

// @track PortfolioObj;
// @track filteredPortfolioObj;
// @track columns = [
//     { label: 'Name', fieldName: 'Name', type: 'text' },
//     { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
// ];
// PortfolioRecordTypeId;
// Portfolios = [];

// @wire(showPortfolioGallery)
// wiredPortfolio({error, data}) {
//     if (data) {
//         this.PortfolioObj = data.map((item, index) => ({
//             Id: item.Id,
//             Name: item.Name,
//             image_url__c: item.image_url__c,
//             Type__c: item.Type__c,
//             class: this.generateItemClass(index + 1) // Generate class dynamically
//         }));
//         this.filteredPortfolioObj = this.PortfolioObj;
//     } else if (error) {
//         this.error = error;
//     }
// }

// generateItemClass(index) {
//     switch(index) {
//         case 1:
//             return 'card card-tall card-wide';
//         case 2:
//             return 'card card-tall';
//         case 7:
//             return 'card card-wide';
//         default:
//             return 'card';
//     }
// }

// @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
// wiredObjectInfo({error, data}) {
//     if (data) {
//         this.PortfolioRecordTypeId = data.defaultRecordTypeId;
//         this.error = undefined;
//     } else if (error) {
//         this.error = error;
//         this.PortfolioRecordTypeId = undefined;
//     }
// }

// @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
// wiredPicklistValues({error, data}) {
//     if (data) {
//         this.Portfolios = data.values.map(picklistValue => ({
//             label: picklistValue.label,
//             value: picklistValue.value,
//             class: 'btn', // Adjust as per your requirements
//             href: '#' + picklistValue.value // Adjust as per your requirements
//         }));
//         this.error = undefined;
//     } else if (error) {
//         this.error = error;
//         this.Portfolios = undefined;
//     }
// }

// handleButtonClick(event) {
//     const buttonValue = event.target.getAttribute('data-value');
//     if (buttonValue === 'All') {
//         this.filteredPortfolioObj = this.PortfolioObj;
//     } else {
//         this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
//         console.log("buttonValue :" +buttonValue);
//     }
// }
// }










import { LightningElement, wire, track } from "lwc";
import { getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass.showPortfolioGallery';
import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

export default class PortfolioGallery3 extends LightningElement {
//     @track itemClasses = {};
//     @track PortfolioObj;
//     @track filteredPortfolioObj;
//     @track columns = [
//         { label: 'Name', fieldName: 'Name', type: 'text' },
//         { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
//     ];
//     PortfolioRecordTypeId;
//     Portfolios = [];


//     @wire(showPortfolioGallery)
//     wiredPortfolio({ error, data }) {
//         if (data) {
//             this.PortfolioObj = data.map(item => ({
//                 Id: item.Id,
//                 Name: item.Name,
//                 image_url__c: item.image_url__c,
//                 Type__c: item.Type__c
//             }));
//             this.filteredPortfolioObj = [...this.PortfolioObj];
//             this.updateItemClasses();
//         } else if (error) {
//             this.error = error;
//         }
//     }
//     updateItemClasses() {
//         this.filteredPortfolioObj.forEach(item => {
//             if (!item.class) { // Check if class is not already set
//                 this.generateItemClass(item);
//             }
//         });
//         var test = this.template.querySelector('.gridclass');
//         test.classList.add('grid-wrapper');

//         if (test.classList.contains('grid-wrapper1')) {
//             // Remove the class 'grid-wrapper1' from the divElement
//             test.classList.remove('grid-wrapper1');
//         }
//     }
//     generateItemClass(index) {
//         switch (index) {
//             case 3:
//                 return 'tall';
//             case 4:
//                 return 'wide';
//             case 6:
//                 return 'tall';
//             case 7:
//                 return 'big';
//             case 9:
//                 return 'wide';
//             case 11:
//                 return 'tall';
//             case 16:
//                 return 'wide';
//             case 19:
//                 return 'wide';
//             case 25:
//                 return 'tall';
//             default:
                
//         }
//     }
//     // generateItemClass(item) {
//     //     const img = new Image();
//     //     img.src = item.image_url__c;

//     //     img.onload = () => {
//     //         const width = img.width;
//     //         const height = img.height;

//     //         const aspectRatio = width / height;

//     //         if (aspectRatio > 3 / 2) {
//     //             item.class = 'wide';
//     //         } else if (aspectRatio > 63 / 82) {
//     //             item.class = 'tall';
//     //         } else if (aspectRatio > 64 / 41) {
//     //             item.class = 'big';
//     //         }
//     //     };

//     //     this.itemClasses[item.Id] = item.class; // Store class in the array
//     // }

//     @wire(getObjectInfo, { objectApiName: PORTFOLIO_OBJECT })
//     wiredObjectInfo({ error, data }) {
//         if (data) {
//             this.PortfolioRecordTypeId = data.defaultRecordTypeId;
//             this.error = undefined;
//         } else if (error) {
//             this.error = error;
//             this.PortfolioRecordTypeId = undefined;
//         }
//     }

//     @wire(getPicklistValues, { recordTypeId: "$PortfolioRecordTypeId", fieldApiName: PORTFOLIO_FIELD })
//     wiredPicklistValues({ error, data }) {
//         if (data) {
//             this.Portfolios = data.values.map(picklistValue => ({
//                 label: picklistValue.label,
//                 value: picklistValue.value,
//                 class: 'btn', // Adjust as per your requirements
//                 href: '#' + picklistValue.value // Adjust as per your requirements
//             }));
//             this.error = undefined;
//         } else if (error) {
//             this.error = error;
//             this.Portfolios = undefined;
//         }
//     }

//     // injectCustomStylesForOtherBtn() {
//     //     console.log('injectCustom style called');
//     //     const style = document.createElement('style');
//     //     style.textContent = `

//     //     img {
//     //         max-width: 100%;
//     //         height: auto;
//     //         vertical-align: middle;
//     //         display: inline-block;
//     //     }
//     //         .grid-wrapper1 .img {
//     //             width: 96%;
//     //             height: 95%;
//     //             object-fit: cover;
//     //             border-radius: 5px;
//     //         }

//     //         .grid-wrapper1 {
//     //             display: flex;
//     //             justify-content: center;
//     //             align-items: center;
//     //             flex-direction: row;

//     //             align-content: normal;
//     //             margin: 2px;
//     //             padding: 3rem 0;
//     //         }
//     //     `;
//     //     this.template.querySelector('.grid-wrapper1').appendChild(style);
//     // }

//     //     injectCustomStylesForAll() {
//     //         console.log('injectCustomStylesForAll style called');
//     //         const style = document.createElement('style');
//     //         style.textContent = `

//     // img {
//     // 	max-width: 100%;
//     // 	height: auto;
//     // 	vertical-align: middle;
//     // 	display: inline-block;
//     // }

//     // /* Main CSS */
//     // .grid-wrapper > div {
//     // 	display: flex;
//     // 	justify-content: center;
//     // 	align-items: center;
//     // }
//     // .grid-wrapper .img {
//     // 	width: 100%;
//     // 	height: 100%;
//     // 	object-fit: cover;
//     // 	border-radius: 5px;
//     // }

//     // .grid-wrapper {
//     // 	display: grid;
//     // 	grid-gap: 10px;
//     // 	grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
//     // 	grid-auto-rows: 200px;
//     // 	grid-auto-flow: dense;
//     //   padding: 3rem 0;
//     // }
//     // .grid-wrapper .wide {
//     // 	grid-column: span 2;
//     // }
//     // .grid-wrapper .tall {
//     // 	grid-row: span 2;
//     // }
//     // .grid-wrapper .big {
//     // 	grid-column: span 2;
//     // 	grid-row: span 2;
//     // }
//     //         `;
//     //         this.template.querySelector('.grid-wrapper').appendChild(style);
//     //     }


//     handleButtonClick(event) {
//         const buttonValue = event.target.getAttribute('data-value');
//         if (buttonValue === 'All') {
//             this.filteredPortfolioObj = this.PortfolioObj;
//             this.updateItemClasses(); // Update classes based on aspect ratios
//             // this.injectCustomStylesForAll();

//         } else {
//             this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
//             // Assign 'tall' class directly without recalculating
//             //   this.filteredPortfolioObj.forEach(item => item.class = 'grid-wrapper1');
//             // this.injectCustomStylesForOtherBtn();
//             var test = this.template.querySelector('.gridclass');
//             // Check if the divElement has the class 'temp'
//             if (test.classList.contains('grid-wrapper')) {
//                 // Remove the class 'temp' from the divElement
//                 test.classList.remove('grid-wrapper');
//             }

//             test.classList.add('grid-wrapper1');
//         }

//         // // Apply stored classes for consistency
//         this.filteredPortfolioObj.forEach(item => {
//             item.class = this.itemClasses[item.Id];
//         });
//     }


}