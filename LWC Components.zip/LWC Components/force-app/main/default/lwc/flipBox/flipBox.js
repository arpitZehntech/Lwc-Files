import { LightningElement, api } from 'lwc';

export default class FlipBox extends LightningElement {
    @api firstflipbox;
    @api firstcardimageurl;
    @api firstcardfronttext;
    @api fistcardbacktext;
    @api secondcardimageurl;
    @api secondcardfronttext;
    @api secondcardbacktext;
    @api firstcardbackgroundcolor;
    @api firstcardfronttextcolor;
    @api firstcardfontsize;
    @api borderradius;
    @api fontweight;
    @api fontstyle;
    @api secondcardfontstyle;
    @api secondcardfontweight;
    @api secondcardborderradius;
    @api secondcardfontsize;
    @api secondcardfronttextcolor;
    @api secondcardbackgroundcolor;

    renderedCallback() {
        this.template
            .querySelector("div")
            .style.setProperty("--my-bgcolor", this.firstcardbackgroundcolor);
        this.template
            .querySelector("div")
            .style.setProperty("--my-txtcolor", this.firstcardfronttextcolor);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontsize", this.firstcardfontsize);
        this.template
            .querySelector("div")
            .style.setProperty("--my-borderradius", this.borderradius);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontweight", this.fontweight);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontstyle", this.fontstyle);
        
        // <------Second card css------> //

        this.template
            .querySelector("div")
            .style.setProperty("--my-bgcolor1", this.secondcardbackgroundcolor);
        this.template
            .querySelector("div")
            .style.setProperty("--my-txtcolor1", this.secondcardfronttextcolor);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontsize1", this.secondcardfontsize);
        this.template
            .querySelector("div")
            .style.setProperty("--my-borderradius1", this.secondcardborderradius);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontweight1", this.secondcardfontweight);
        this.template
            .querySelector("div")
            .style.setProperty("--my-fontstyle1", this.secondcardfontstyle);
    }

    flip() {
        // Add your flip logic here
        // For example, toggle a CSS class for flipping
        const flipBoxInner = this.template.querySelector('.flip-box-inner');
        flipBoxInner.classList.toggle('flipped');
    }
}