import { LightningElement, api } from 'lwc';

export default class PortfolioGalleryItem extends LightningElement {
    @api image;

    handleClick() {
        const event = new CustomEvent('imageclick', {
            detail: this.image
        });
        this.dispatchEvent(event);
    }
}