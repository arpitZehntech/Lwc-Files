import { LightningElement, api, track } from 'lwc';

import jqueryTest from "@salesforce/resourceUrl/jqueryTest";

import { loadScript } from 'lightning/platformResourceLoader';

export default class ImageWithAnimatedText extends LightningElement {
  @api imageSrc = 'https://elementsreadycom2d42d.zapwp.com/q:i/r:0/wp:1/w:445/u:https://elementsready.com/wp-content/uploads/2021/05/Group-1188.png'; // Image source URL
  @api heading1 = ''; // Heading text

  @api heading2 = 'Marketing Agency In Usa'; // Heading text
  @api text = 'Greatly explain attempt perhaps in feeling he. House men taste bed not drawn joy. Through enquire however do equally herself at. Greatly way old may you present improve.'; // Paragraph text

  handleLearnMore() {
    // Handle Learn More button click event
    console.log('Learn More button clicked');
    // You can emit an event here or perform any other action
  }


// @track currentWordIndex = 0;
//  @track currentWordIndex = 0;
//     @track currentWord;
//     words = ['Typewriter', 'Creating', 'Effect', 'Speed', 'Progress', 'References'];

//     connectedCallback() {
//         // Initial typing of the first word
//         this.typeNextWord();

//         // Schedule typing and deleting every 3 seconds
//         this.intervalId = setInterval(() => {
//             // Delete the word
//             this.currentWord = '';
//             // Type the next word after a delay
//             setTimeout(this.typeNextWord.bind(this), 500);
//         }, 3000);
//     }

//     typeNextWord() {
//         this.currentWord = this.words[this.currentWordIndex];
//         this.currentWordIndex = (this.currentWordIndex + 1) % this.words.length;
//     }

//     disconnectedCallback() {
//         // Clear the interval when the component is removed
//         clearInterval(this.intervalId);
//     }



}

