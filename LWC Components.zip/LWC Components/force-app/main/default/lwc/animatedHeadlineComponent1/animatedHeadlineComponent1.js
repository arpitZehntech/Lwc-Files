// import { LightningElement, api, track } from 'lwc';

// export default class AnimatedHeadlineComponent1 extends LightningElement {
//     @api selectTheme;
//     @api heading = '';
//     @api subheading = '';
//     @api headingclr;
//     @api imageurl = '';
//     @api headingfontfamily;
//     @api subheadingfontfamily;
//     @api subheadingcolor;
//     @api redirectUrl;
//     @api buttonText;
//     @api buttonColor;
//     @api buttonBorderColor;
//     @api buttonTextColor;

//     @track showhideFirst = false;
//     @track showhideSecond = false;
//     @track hasText = false;

//     @api typewriterValues;
//     @track typewriterIndex = 0;

//     @api highlightText = '';
//     @api highlightColor = '';

//     @api backgroundImg;
//     @api backgroundColor;


//     get backgroundImageStyle() {
//         return `background-image: url(${this.backgroundImg});`;
//     }

//     connectedCallback() {
//         if (this.selectTheme === 'Theme 1') {
//             this.showhideFirst = true;
//         } else if (this.selectTheme === 'Theme 2') {
//             this.showhideSecond = true;
//         }
//         this.hasText = !!this.buttonText;

//         if (this.typewriterValues && this.highlightText) {
//             this.updateHighlightText();
//             this.startTypewriterAnimation();
//         }
//     }

//     updateHighlightText() {
//         const values = this.typewriterValues.split(',');
//         const currentValue = values[this.typewriterIndex];
//         this.heading = this.heading.replace(this.highlightText, currentValue);
//         this.highlightText = currentValue;
//     }

//     startTypewriterAnimation() {
//         const values = this.typewriterValues.split(',');
//         setInterval(() => {
//             this.typewriterIndex = (this.typewriterIndex + 1) % values.length;
//             this.updateHighlightText();
//         }, 3000);
//     }

//     get anchorClass() {
//         return this.hasText ? 'withText' : 'noText';
//     }

//     get headingParts() {
//         if (!this.highlightText || !this.heading) {
//             return [];
//         }
//         const parts = this.heading.split(new RegExp(`(${this.highlightText})`, 'gi'));
//         return parts.map((part, index) => ({
//             key: index,
//             text: part,
//             class: part.toLowerCase() === this.highlightText.toLowerCase() ? 'highlighted' : '',
//             style: part.toLowerCase() === this.highlightText.toLowerCase() ? `color: ${this.highlightColor};` : ''
//         }));
//     }

//     renderedCallback() {
//         const divElement = this.template.querySelector('.Div');
//         divElement.style.setProperty("--my-headingclr", this.headingclr);
//         divElement.style.setProperty("--my-headingfontfamily", this.headingfontfamily);
//         divElement.style.setProperty("--my-subheadingfontfamily", this.subheadingfontfamily);
//         divElement.style.setProperty("--my-subheadingcolor", this.subheadingcolor);
//         divElement.style.setProperty("--my-buttonColor", this.buttonColor);
//         divElement.style.setProperty("--my-buttonTextColor", this.buttonTextColor);
//         divElement.style.setProperty("--my-buttonBorderColor", this.buttonBorderColor);

//         divElement.style.setProperty("--my-backgroundColor", this.backgroundColor);


//         const values = this.typewriterValues.split(',');
//         const keyframes = `@keyframes textrotate {
//             ${values.map((value, index) => `
//                 ${index * (100 / values.length)}% {
//                     content: '${value}';
//                 }
//                 ${(index + 1) * (100 / values.length)}% {
//                     content: '${values[(index + 1) % values.length]}';
//                 }
//             `).join('')}
//         }`;

//         // Create a style element
//         const style = document.createElement('style');

//         // Set its content to the dynamic keyframes
//         style.textContent = keyframes;

//         // Get the head element of the document
//         const head = document.head || document.getElementsByTagName('head')[0];

//         // Append the style element to the head
//         head.appendChild(style);
//     }
// }
import { LightningElement, api, track } from 'lwc';

export default class AnimatedHeadlineComponent1 extends LightningElement {
    @api selectTheme;
    @api heading = '';
    @api subheading = '';
    @api headingclr;
    @api imageurl = '';
    @api headingfontfamily;
    @api subheadingfontfamily;
    @api subheadingcolor;
    @api redirectUrl;
    @api buttonText;
    @api buttonColor;
    @api buttonBorderColor;
    @api buttonTextColor;

    @track showhideFirst = false;
    @track showhideSecond = false;
    @track hasText = false;

    @api typewriterValues;
    @track typewriterIndex = 0;
    @track isTyping = true;

    @api highlightText = '';
    @api highlightColor = '';

    @api backgroundImg;
    @api backgroundColor;

    @api typewriterVariant;
    @api typewriterPeriod;

    get backgroundImageStyle() {
        return `background-image: url(${this.backgroundImg});`;
    }

    connectedCallback() {
        if (this.selectTheme === 'Theme 1') {
            this.showhideFirst = true;
        } else if (this.selectTheme === 'Theme 2') {
            this.showhideSecond = true;
        }
        this.hasText = !!this.buttonText;

        if (this.typewriterValues && this.highlightText) {
            this.updateHighlightText();
            if (this.typewriterVariant === 'variant1') {
                this.startTypewriterAnimation();
            } else if (this.typewriterVariant === 'variant2') {
                this.startTypewriterAnimationVariant2();
            }
        }
    }

    updateHighlightText() {
        const values = this.typewriterValues.split(',');
        const currentValue = values[this.typewriterIndex];
        this.heading = this.heading.replace(this.highlightText, currentValue);
        this.highlightText = currentValue;
    }

    startTypewriterAnimation() {
        const values = this.typewriterValues.split(',');
        const duration = this.typewriterPeriod;;
        const interval = duration / (values.length - 1);

        setInterval(() => {
            if (this.isTyping) {
                this.typewriterIndex = (this.typewriterIndex + 1) % values.length;
                this.updateHighlightText();
            }
        }, interval);
    }

    // startTypewriterAnimationVariant2() {
    //     var TxtType = function(el, toRotate, period) {
    //         this.toRotate = toRotate;
    //         this.el = el;
    //         this.loopNum = 0;
    //         this.period = parseInt(period, 10) || 2000;
    //         this.txt = '';
    //         this.tick();
    //         this.isDeleting = false;
    //     };

    //     TxtType.prototype.tick = function() {
    //         var i = this.loopNum % this.toRotate.length;
    //         var fullTxt = this.toRotate[i];

    //         if (this.isDeleting) {
    //         this.txt = fullTxt.substring(0, this.txt.length - 1);
    //         } else {
    //         this.txt = fullTxt.substring(0, this.txt.length + 1);
    //         }

    //         this.el.innerHTML = '<span>'+this.txt+'</span>';

    //         var that = this;
    //         var delta = 200 - Math.random() * 100;

    //         if (this.isDeleting) { delta /= 2; }

    //         if (!this.isDeleting && this.txt === fullTxt) {
    //         delta = this.period;
    //         this.isDeleting = true;
    //         } else if (this.isDeleting && this.txt === '') {
    //         this.isDeleting = false;
    //         this.loopNum++;
    //         delta = 500;
    //         }

    //         setTimeout(function() {
    //         that.tick();
    //         }, delta);
    //     };

    //     window.onload = function() {
    //         var elements = document.getElementsByClassName('highlighted');
    //         for (var i=0; i<elements.length; i++) {
    //             var toRotate = elements[i].getAttribute('typewriterValues');
    //             var period = elements[i].getAttribute(2000);
    //             if (toRotate) {
    //               new TxtType(elements[i], JSON.parse(toRotate), period);
    //             }
    //         }

    //     };
    // }
    // startTypewriterAnimationVariant2() {
    //     const textArray = this.typewriterValues.split(',');
    //     let textArrayIndex = 0;
    //     let charIndex = 0;

    //     const updateText = () => {
    //         // Check if textArrayIndex is within bounds
    //         if (textArrayIndex < textArray.length) {
    //             // Check if charIndex is within bounds
    //             if (charIndex <= textArray[textArrayIndex].length) {
    //                 // Update highlightText with the current substring
    //                 this.highlightText = textArray[textArrayIndex].slice(0, charIndex);
    //                 charIndex++;
    //                 // Schedule the next update
    //                 setTimeout(updateText, 150);
    //             } else {
    //                 // Move to the next text in the array
    //                 textArrayIndex = (textArrayIndex + 1) % textArray.length;
    //                 // Reset charIndex
    //                 charIndex = 0;
    //                 // Schedule the next update after a delay
    //                 setTimeout(updateText, 3000);
    //             }
    //         }
    //     };

    //     // Start the typewriter animation
    //     updateText();
    // }


    delWriter(text, i, cb) {
        if (i >= 0) {
          this.highlightText = text.substring(0, i);
          // Consistent delay for backspace effect
          const backspaceDelay = 50; // Adjust as needed
          setTimeout(() => {
            this.delWriter(text, i - 1, cb);
          }, backspaceDelay);
        } else if (typeof cb === 'function') {
          setTimeout(cb, 1000);
        }
      }
      
      typeWriter(text, i, cb) {
        if (i <= text.length) {
          this.highlightText = text.substring(0, i);
          // Consistent delay for typing effect
          const typingDelay = 100; // Adjust as needed
          setTimeout(() => {
            this.typeWriter(text, i + 1, cb);
          }, typingDelay);
        } else if (typeof cb === 'function') {
          setTimeout(cb, 1000);
        }
      }
      
      startWriter(index) {
        if (!this.typewriterValues) return;
        const textArray = this.typewriterValues.split(',');
      
        if (index >= textArray.length) {
          // Restart from the beginning after completing all words
          index = 0;
        }
      
        const currentText = textArray[index];
        // Start typing the current word
        this.typeWriter(currentText, 0, () => {
          // After typing, start deleting word
          this.delWriter(currentText, currentText.length, () => {
            // Move to the next word by incrementing the index
            this.startWriter(index + 1);
          });
        });
      }
      
      startTypewriterAnimationVariant2() {
        setTimeout(() => {
          this.startWriter(0);
        }, 3000);
      }
      
    
    stopTypewriterAnimation() {
        this.isTyping = false;
    }

    replaceHighlightedText(newText) {
        this.isTyping = false;
        this.heading = this.heading.replace(this.highlightText, newText);
        this.highlightText = newText;
    }

    get anchorClass() {
        return this.hasText ? 'withText' : 'noText';
    }

    get headingParts() {
        if (!this.highlightText || !this.heading) {
            return [];
        }
        const parts = this.heading.split(new RegExp(`(${this.highlightText})`, 'gi'));
        return parts.map((part, index) => ({
            key: index,
            text: part,
            class: part.toLowerCase() === this.highlightText.toLowerCase() ? 'highlighted' : '',
            style: part.toLowerCase() === this.highlightText.toLowerCase() ? `color: ${this.highlightColor};` : ''
        }));
    }

    renderedCallback() {
        const divElement = this.template.querySelector('.Div');
        divElement.style.setProperty("--my-headingclr", this.headingclr);
        divElement.style.setProperty("--my-headingfontfamily", this.headingfontfamily);
        divElement.style.setProperty("--my-subheadingfontfamily", this.subheadingfontfamily);
        divElement.style.setProperty("--my-subheadingcolor", this.subheadingcolor);
        divElement.style.setProperty("--my-buttonColor", this.buttonColor);
        divElement.style.setProperty("--my-buttonTextColor", this.buttonTextColor);
        divElement.style.setProperty("--my-buttonBorderColor", this.buttonBorderColor);
        divElement.style.setProperty("--my-backgroundColor", this.backgroundColor);

        if (this.typewriterVariant === 'variant2') {
            const css = document.createElement("style");
            css.type = "text/css";
            css.innerHTML = ".highlighted{ border-right: 0.08em solid #FC7318}";
            this.template.querySelector('div').appendChild(css);
        }
    }
}
