import { LightningElement, wire, track,api} from 'lwc';
import fetchTabData from '@salesforce/apex/TabAndAccordionController.fetchTabData';

export default class TabAndAccordion1 extends LightningElement {
    @track tabs = [];
    @api tabOrder = '';

    @wire(fetchTabData)
    wiredTabData({ error, data }) {
        if (data) {
            this.tabs = data.map(tab => ({
                label: tab.label,
                subheadings: tab.subheadings.map(subheading => ({
                    label: subheading.label,
                    content: subheading.content
                }))
            }));
            // Check if the tab order property is set
            if (this.tabOrder) {
                // Split the tab order string into an array
                const orderArray = this.tabOrder.split(',').map(item => item.trim());
                // Sort the tabs based on the order specified in the tab order property
                this.tabs.sort((a, b) => {
                    return orderArray.indexOf(a.label) - orderArray.indexOf(b.label);
                });
            }
        } else if (error) {
            console.error('Error fetching tab data:', error);
        }
    }

}
