import { LightningElement, track, api } from 'lwc';

export default class Counter_up extends LightningElement {
    @api SelectCounter;
    @track showhideFirst = false;
    @track showhideSecond = false;
    @track showhideThird = false;
    @track showhideFourth = false;

    @api Count1;
    @api Count2;
    @api Count3;
    @api Count4;

    number1;
    number2;
    number3;
    number4;

    current1;
    current2;
    current3;
    current4;

    @api title1;
    @api title2;
    @api title3;
    @api title4;

    label1;
    label2;
    label3;
    label4;

    @api LogoImg1;
    @api LogoImg2;
    @api LogoImg3;
    @api LogoImg4;

    image1;
    image2;
    image3;
    image4;

    @api BoxBgColor1;
    @api BoxBgColor2;
    @api BoxBgColor3;
    @api BoxBgColor4;

    CellBgColor1;
    CellBgColor2;
    CellBgColor3;
    CellBgColor4;

    @api LogoBgcolor1;
    @api LogoBgcolor2;
    @api LogoBgcolor3;
    @api LogoBgcolor4;

    imgbgColor1;
    imgbgColor2;
    imgbgColor3;
    imgbgColor4;

    @api MainHeading1;
    @api MainHeading2;
    @api MainHeading3;
    @api MainHeading4;

    @api MainHeading1Clr;
    @api MainHeading2Clr;
    @api MainHeading3Clr;
    @api MainHeading4Clr;

    @api Text1;
    @api Text2;
    @api Text3;
    @api Text4;

    @api TextClr1;
    @api TextClr2;
    @api TextClr3;
    @api TextClr4;


    @api mainBgColor;
    @api BackgroundImg;

    @api BoxBgColor;
    @api LogoBgcolor;

    @api NumberColor1;
    @api NumberColor2;
    @api NumberColor3;
    @api NumberColor4;


    @api TitleColor1;
    @api TitleColor2;
    @api TitleColor3;
    @api TitleColor4;

    @track counts = [];

    renderedCallback() {
        
        this.template
        .querySelector("div")
        .style.setProperty("--my-heading1", this.MainHeading1Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading2", this.MainHeading2Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading3", this.MainHeading3Clr);
    this.template
        .querySelector("div")
        .style.setProperty("--my-heading4", this.MainHeading4Clr);


    this.template
        .querySelector("div")
        .style.setProperty("--my-text1", this.TextClr1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text2", this.TextClr2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text3", this.TextClr3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-text4", this.TextClr4);



    this.template
        .querySelector("div")
        .style.setProperty("--my-BgColor", this.mainBgColor);

    this.template
        .querySelector("div")
        .style.setProperty("--my-BgImage", `url(${this.BackgroundImg})`);

    this.template
        .querySelector("div")
        .style.setProperty("--my-boxBgColor", this.BoxBgColor);

    this.template
        .querySelector("div")
        .style.setProperty("--my-LogoBgcolor", this.LogoBgcolor);


    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor1", this.NumberColor1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor2", this.NumberColor2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor3", this.NumberColor3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-numberColor4", this.NumberColor4);



    this.template
        .querySelector("div")
        .style.setProperty("--my-TitleColor1", this.TitleColor1);
    this.template
        .querySelector("div")
        .style.setProperty("--my-TitleColor2", this.TitleColor2);
    this.template
        .querySelector("div")
        .style.setProperty("--my-TitleColor3", this.TitleColor3);
    this.template
        .querySelector("div")
        .style.setProperty("--my-TitleColor4", this.TitleColor4);
    }

    // setCssVariables() {


    // }

    connectedCallback() {

        this.number1 = this.Count1;
        this.number2 = this.Count2;
        this.number3 = this.Count3;
        this.number4 = this.Count4;

        this.current1 = 0;
        this.current2 = 0;
        this.current3 = 0;
        this.current4 = 0;

        this.label1 = this.title1;
        this.label2 = this.title2;
        this.label3 = this.title3;
        this.label4 = this.title4;

        this.image1 = this.LogoImg1;
        this.image2 = this.LogoImg2;
        this.image3 = this.LogoImg3;
        this.image4 = this.LogoImg4;

        this.CellBgColor1 = this.BoxBgColor1;
        this.CellBgColor2 = this.BoxBgColor2;
        this.CellBgColor3 = this.BoxBgColor3;
        this.CellBgColor4 = this.BoxBgColor4;

        this.imgbgColor1 = this.LogoBgcolor1;
        this.imgbgColor2 = this.LogoBgcolor2;
        this.imgbgColor3 = this.LogoBgcolor3;
        this.imgbgColor4 = this.LogoBgcolor4;


        this.counts = [
            this.generateCountItem(this.number1, this.current1, this.label1, this.image1, this.CellBgColor1, this.imgbgColor1),
            this.generateCountItem(this.number2, this.current2, this.label2, this.image2, this.CellBgColor2, this.imgbgColor2),
            this.generateCountItem(this.number3, this.current3, this.label3, this.image3, this.CellBgColor3, this.imgbgColor3),
            this.generateCountItem(this.number4, this.current4, this.label4, this.image4, this.CellBgColor4, this.imgbgColor4),

        ];

        if (this.SelectCounter === '1st Counter') {
            this.showhideFirst = true;
        } else if (this.SelectCounter === '2nd Counter') {
            this.showhideSecond = true;
        } else if (this.SelectCounter === '3rd Counter') {
            this.showhideThird = true;
        } else if (this.SelectCounter === '4th Counter') {
            this.showhideFourth = true;
        }

        this.startCounters();

    }

    generateCountItem(number, current, label, image, boxBgrColor, imgbgColor) {

        // console.log('Debug: number current fourth', { number, current });

        return {
            number: number,
            current: current,
            label: label,
            image: image,
            boxBg1Color: 'background-color:' + boxBgrColor,
            imgbgColor: 'background-color:' + imgbgColor,
        };
    }

    startCounters() {
        const intervalTime = 1; // Set the default interval time in milliseconds
        const intervalTimeForSmallValues = 100; // Set a faster interval time for values less than 150

        // Find the maximum number of iterations needed to finish all counters at the same time
        const maxIterations = Math.max(...this.counts.map(item => Math.ceil(item.number / 150)));

        // Execute the interval function for each counter
        this.counts.forEach((item) => {
            const incrementValue = Math.ceil(item.number / maxIterations);
            const currentIntervalTime = item.number < 150 ? intervalTimeForSmallValues : intervalTime;

            const intervalFunction = () => {
                const remainingIncrement = item.number - item.current;
                item.current += Math.min(incrementValue, remainingIncrement);

                // Log the current value
                console.log(`${item.label} Current Value: ${item.current}`);

                if (item.current < item.number) {
                    setTimeout(intervalFunction, currentIntervalTime);
                }
            };

            intervalFunction();
        });
    }


}