// import { LightningElement, api, track } from 'lwc';

// export default class Footer extends LightningElement {

//     @api Selectfooter;

//     @track showhideFirst = false;
//     @track showhideSecond = false;

//     connectedCallback() {

//         if (this.Selectfooter === '1st Footer') {
//             this.showhideFirst = true;
//         } else if (this.Selectfooter === '2nd Footer') {
//             this.showhideSecond = true;
//         }

//     }
// }

// import { LightningElement } from 'lwc';

// export default class Footer1 extends LightningElement {}

import { LightningElement, api, wire, track } from 'lwc';
import sendEmail from '@salesforce/apex/EmailHandler.sendEmail';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_EMAIL_OBJECT from '@salesforce/schema/Subscriber__c';
import EMAIL_FIELD from '@salesforce/schema/Subscriber__c.Email__c';

export default class Footer extends LightningElement {

    @api Selectfooter;

    @track showhideFirst = false;
    @track showhideSecond = false;

    @track email = '';

    @api Block1heading;
    @api Block2heading;
    @api Block3heading;

    @api Block1SubHeading1;
    @api Block1SubHeading2;
    @api Block1SubHeading3;
    @api Block1SubHeading4;
    @api Block1SubHeading5;

    @api Block2SubHeading1;
    @api Block2SubHeading2;
    @api Block2SubHeading3;
    @api Block2SubHeading4;
    @api Block2SubHeading5;
    @api Block2SubHeading6;
    @api Block2SubHeading7;
    @api Block2SubHeading8;


    @api Block1SubHeading1Url;
    @api Block1SubHeading2Url;
    @api Block1SubHeading3Url;
    @api Block1SubHeading4Url;
    @api Block1SubHeading5Url;

    @api Block2SubHeading1Url;
    @api Block2SubHeading2Url;
    @api Block2SubHeading3Url;
    @api Block2SubHeading4Url;
    @api Block2SubHeading5Url;
    @api Block2SubHeading6Url;
    @api Block2SubHeading7Url;
    @api Block2SubHeading8Url;


    @api image1Footer1;
    @api image2Footer1;
    @api image3Footer1;
    @api image4Footer1;

    @api Image1UrlFooter1;
    @api Image2UrlFooter1;
    @api Image3UrlFooter1;
    @api Image4UrlFooter1;

    @api CopyrightYear;
    @api CopyrightTitle;
    @api CopyrightTitleUrl;

   @api ComponyLogo;
   @api TextUnderLogo;
   @api TextUnderSubscribe;

   @api image1Footer2;
   @api image2Footer2;
   @api image3Footer2;



  @api footer2mainheading1;
  @api footer2mainheading2;
  @api footer2mainheading3;

@api footer2mainheading1Content1;
@api footer2mainheading2Content2;
@api footer2mainheading3Content3;



    connectedCallback() {

        if (this.Selectfooter === '1st Footer') {
            this.showhideFirst = true;
        } else if (this.Selectfooter === '2nd Footer') {
            this.showhideSecond = true;
        }

    }

    handleChange(event) {
        if (event.target.name === 'emailAddress') {
            this.email = event.target.value;
        }
    }

    async handleSubscribe() {

        await this.handleSubscribe();
    }

    async handleSubscribe() {
        if (this.email) {
            const fields = {};
            fields[EMAIL_FIELD.fieldApiName] = this.email;

            const recordInput = { apiName: USER_EMAIL_OBJECT.objectApiName, fields };
            try {
                await createRecord(recordInput);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Thank you for subscribing!',
                        variant: 'success'
                    })
                );
                this.email = ''; // Clear the email field after successful subscription
            } catch (error) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            }
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please enter your email address',
                    variant: 'error'
                })
            );
        }
    }

}
