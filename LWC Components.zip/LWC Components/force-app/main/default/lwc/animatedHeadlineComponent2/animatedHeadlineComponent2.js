import { LightningElement, api, track } from 'lwc';

export default class AnimatedHeadlineComponent2 extends LightningElement {
    @api selectTheme;
    @api heading = '';
    @api subheading = '';
    @api imageurl = '';
    @api redirectUrl;
    @api buttonText;
    @api typewriterValues;
    @api highlightText;
    @api highlightColor;

    @track showhideFirst = false;
    @track hasText = false;
    @track currentIndex = 0; // Track the index of the current word being animated
    @track isTyping = false; // Track whether typewriter animation is active

    connectedCallback() {
        this.showhideFirst = this.selectTheme === 'Theme 1';
        this.hasText = !!this.buttonText;

        if (Array.isArray(this.typewriterValues) && this.typewriterValues.length > 0 && this.highlightText) {
            this.startTypewriterAnimation();
        }
    }

    startTypewriterAnimation() {
        const typedText = this.template.querySelector(".highlighted");
        const cursor = this.template.querySelector(".cursor");

        const textArray = this.typewriterValues.map(word => `${word}...`);

        let textArrayIndex = 0;
        let charIndex = 0;

        this.isTyping = true; // Start the animation

        const erase = () => {
            if (charIndex > 0) {
                cursor.classList.remove('blink');
                typedText.textContent = textArray[textArrayIndex].slice(0, charIndex - 1);
                charIndex--;
                setTimeout(erase, 80);
            } else {
                cursor.classList.add('blink');
                textArrayIndex++;
                if (textArrayIndex > textArray.length - 1) {
                    textArrayIndex = 0;
                }
                setTimeout(type, 1000);
            }
        }

        const type = () => {
            if (charIndex <= textArray[textArrayIndex].length - 1) {
                cursor.classList.remove('blink');
                typedText.textContent += textArray[textArrayIndex].charAt(charIndex);
                charIndex++;
                setTimeout(type, 120);
            } else {
                cursor.classList.add('blink');
                setTimeout(erase, 1000);
            }
        }

        type();
    }

    get anchorClass() {
        return this.hasText ? 'withText' : 'noText';
    }

    get headingParts() {
        if (!this.highlightText || !this.heading) {
            return [];
        }
        const parts = this.heading.split(new RegExp(`(${this.highlightText})`, 'gi'));
        return parts.map((part, index) => ({
            key: index,
            text: part,
            class: part.toLowerCase() === this.highlightText.toLowerCase() ? 'highlighted' : '',
            style: part.toLowerCase() === this.highlightText.toLowerCase() ? `color: ${this.highlightColor};` : ''
        }));
    }

    get typewriterClass() {
        return 'typewriter'; // Always apply the 'typewriter' class
    }
}
