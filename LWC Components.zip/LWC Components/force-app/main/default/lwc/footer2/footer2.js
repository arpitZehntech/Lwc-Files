import { LightningElement } from 'lwc';

export default class Footer2 extends LightningElement {}