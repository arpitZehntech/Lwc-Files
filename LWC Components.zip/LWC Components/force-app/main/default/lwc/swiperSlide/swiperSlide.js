// swiperDemo.js
import { LightningElement, track } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import SWIPER from '@salesforce/resourceUrl/swiper';

export default class SwiperDemo extends LightningElement {
    @track swiper;

    connectedCallback() {
        Promise.all([
      
            loadScript(this, SWIPER + '/swiper/jquery.min.js'),
            loadScript(this, SWIPER + '/swiper/swiper-bundle.min.js'),
            loadScript(this, SWIPER + '/swiper/swiper-bundle.min.mjs'),
            loadStyle(this, SWIPER + '/swiper/swiper-bundle.min.css'),
        ])
        .then(() => {
            this.initializeSwiper();
        })
        .catch(error => {
            console.error('Error loading Swiper library', error);
        });
    }

    initializeSwiper() {
  // Assuming jQuery is already included

$(document).ready(function() {
    var swiper = new SWIPER('.mySwiper', {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
});

    }
}