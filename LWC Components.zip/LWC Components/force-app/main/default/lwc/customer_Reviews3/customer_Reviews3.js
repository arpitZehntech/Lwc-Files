import { LightningElement, track } from 'lwc';

export default class Customer_Reviews3 extends LightningElement {
    @track teamMembers = [
        {
            Id: 1,
            name: 'Carry Johnshon',
            imageUrl: 'https://images.unsplash.com/photo-1495603889488-42d1d66e5523?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=130&ixid=eyJhcHBfaWQiOjF9&ixlib=rb-1.2.1&q=80&w=130',
            role: 'Web developer',
            stars: 'fas fa-star text-warning'.repeat(4)
        },
        {
            Id: 2,
            name: 'Alex Carry',
            imageUrl: 'https://images.unsplash.com/photo-1582003457856-20898dd7e1ea?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=130&ixid=eyJhcHBfaWQiOjF9&ixlib=rb-1.2.1&q=80&w=130',
            role: 'Web developer',
            stars: 'fas fa-star text-warning'.repeat(3)
        },
        {
            Id: 3,
            name: 'John Smith',
            imageUrl: 'https://images.unsplash.com/photo-1492447166138-50c3889fccb1?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=130&ixid=eyJhcHBfaWQiOjF9&ixlib=rb-1.2.1&q=80&w=130',
            role: 'Web developer',
            stars: 'fas fa-star text-warning'.repeat(5)
        },
        {
            Id: 4,
            name: 'George Alex',
            imageUrl: 'https://i.picsum.photos/id/836/130/130.jpg?hmac=Sot_REUw5W-XSuE6FmCjT9JenhZfiNqZYs3AQbfrZsc',
            role: 'Web developer',
            stars: 'fas fa-star text-warning'.repeat(2)
        }
    ];
}
