import { LightningElement } from 'lwc';

export default class CarouselTest1 extends LightningElement {

    imageUrl = 'https://images.unsplash.com/photo-1577880216142-8549e9488dad?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80';
    imageAlt = 'Image description';
    captionText = 'Natalia Dretington<br>Photography and Social';
}
