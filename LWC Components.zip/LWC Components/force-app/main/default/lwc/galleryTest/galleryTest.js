import { LightningElement, wire, api, track } from 'lwc';
import getPicklistValues from '@salesforce/apex/PortfolioGalleryClass1.getFilteredPicklistValues';
import showPortfolioGallery from '@salesforce/apex/PortfolioGalleryClass1.showPortfolioGallery';
import PORTFOLIO_OBJECT from "@salesforce/schema/Portfolio__c";
import PORTFOLIO_FIELD from "@salesforce/schema/Portfolio__c.Type__c";

export default class GalleryTest extends LightningElement {
    // Properties
    @api mainheading = '';
    @api mainheadingclr;
    @api btnTextClr;
    @api btnBackGroundClr;
    @api btnBorderClr; 
    @api btnBackGroundClrHvr;
    @api btnTextClrHvr;
    @track itemClasses = {};
    @track visiblePortfolioObj;
    @track remainingCount = 0;
    @track showLoadMoreButton = false;
    @track PortfolioObj;
    @track filteredPortfolioObj;
    @track columns = [
        { label: 'Name', fieldName: 'Name', type: 'text' },
        { label: 'Image URL', fieldName: 'image_url__c', type: 'text' }
    ];
    PortfolioRecordTypeId;
    @track picklistValues = []; // Used for Apex approach
    @track isUsingApex = true; // Flag to control template rendering (Apex or non-Apex)

    // Lifecycle Hooks
    renderedCallback() {
        const buttons = this.template.querySelectorAll(".btn");
        buttons.forEach(button => {
            if (this.btnTextClr) {
                button.style.setProperty("--my-btnTextClr", this.btnTextClr);
            }
            if (this.btnBackGroundClr) {
                button.style.setProperty("--my-btnBackGroundClr", this.btnBackGroundClr);
            }
            if (this.btnBorderClr) {
                button.style.setProperty("--my-btnBorderClr", this.btnBorderClr);
            }
            if (this.btnBackGroundClrHvr) {
                button.style.setProperty("--my-btnBackGroundClrHvr", this.btnBackGroundClrHvr);
            }
            if (this.btnTextClrHvr) {
                button.style.setProperty("--my-btnTextClrHvr", this.btnTextClrHvr);
            }
        });
    }

    // Wire Methods
    @wire(getPicklistValues, { isGuestUser: { context: this } })
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.picklistValues = data;
        } else if (error) {
            // Handle errors gracefully
            console.error(error);
        }
    }

    @wire(showPortfolioGallery)
    wiredPortfolio({ error, data }) {
        if (data) {
            this.PortfolioObj = data.map(item => ({
                Id: item.Id,
                Name: item.Name,
                image_url__c: item.image_url__c,
                Type__c: item.Type__c
            }));
            this.filteredPortfolioObj = [...this.PortfolioObj];
        } else if (error) {
            this.error = error;
        }
    }

    // Event Handlers
    handleButtonClick(event) {
        event.preventDefault(); // Prevent default behavior of anchor tag
        const buttonValue = event.target.getAttribute('data-value');
        if (buttonValue === 'All') {
            this.filteredPortfolioObj = this.PortfolioObj;
        } else {
            this.filteredPortfolioObj = this.PortfolioObj.filter(item => item.Type__c === buttonValue);
        }
    }
}
