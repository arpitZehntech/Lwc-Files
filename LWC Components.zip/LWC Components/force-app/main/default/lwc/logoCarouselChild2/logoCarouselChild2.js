// logoCarouselChild2.js

import { LightningElement, track ,api} from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity';

export default class LogoCarouselChild2 extends LightningElement {
    @track carouselItems = []; // Add your carousel items here

    @api logo1;
    @api logo2 ;
    @api logo3 ;
    @api logo4 ;
    @api logo5 ;
    @api logo6 ;
    @api boolean1 ;
    @api cell_align1;
    @api contain1;
    @api draggable1;
    @api wrap_around1;
    @api auto_play1;
    @api prev_next_buttons1;
    @api left_to_right;
    // @api bordercolor




    connectedCallback() {
     
        Promise.all([
            loadScript(this, FLICK + '/flickity/jquery.min.js'),
            loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),

        ])
            .then(() => {
                return Promise.all([
                    loadStyle(this, FLICK + '/flickity/flickity.css'),
                ]);
            })
            .then(() => {
                // Flickity prototype extension
                Flickity.prototype.getSelectedCellIndexes = function () {
                    return this.selectedCells.map(function (cell) {
                        return this.cells.indexOf(cell);
                    }, this);
                };

                // Flickity initialization in Lightning Web Component
                const flickityElement = this.template.querySelector('.grid-slide-wrap');
                const flkty = new Flickity(flickityElement, {
                      // imagesLoaded: false,
                      cellAlign: this.cell_align1,
                      // percentPosition: false,
                      // initialIndex: 1,
                      contain: this.contain1,
                      wrapAround: this.wrap_around1,
                      // lazyLoad: false,
                      pageDots: this.boolean1,
                      // groupCells: false,
                      draggable: this.draggable1,
                      prevNextButtons: this.prev_next_buttons1,
                      autoPlay: this.auto_play1,
                      selectedAttraction: 0.2,
                      friction: 0.8,
                      rightToLeft: this.left_to_right,
                    
                });

                flkty.on('select', () => {
                });
            })
            .catch((e) => {
                console.error('Error:', e);
            });
    }
}