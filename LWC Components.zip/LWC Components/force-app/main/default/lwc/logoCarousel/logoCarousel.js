import { LightningElement, api, track  } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import FLICK from '@salesforce/resourceUrl/flickity';

export default class LogoCarousel extends LightningElement {

    @api speedControl; 
    @api selectSlider;
    flickity = null;
    isPaused = false;
    @api tickerSpeed ;

    @api logo1 ;
    @api logo2 ;
    @api logo3 ;
    @api logo4 ;
    @api logo5 ;
    @api logo6 ;

    @api cellAlign;
    @api contain;
    @api draggable;
    @api wrapAround;
    @api autoPlay;
    @api prevNextButtons;
    @api rightToLeft;
    @api pageDots;
    @api background;
    // @api borderclr;
    backgroundColor;

    @track customclass = 'grid-slide-inner';

      showhide = false;

    renderedCallback() {    
    }

    connectedCallback() {
 
        Promise.all([
            loadScript(this, FLICK + '/flickity/jquery.min.js'),
            loadScript(this, FLICK + '/flickity/flickity.pkgd.min.js'),
            
        ]).then(() => {
            Promise.all([
                loadStyle(this, FLICK + '/flickity/flickity.css'),

            ]).then(() => {

                if(this.selectSlider === '1st Slider'){               
                this.initializeFlickity();
                this.addEventListeners();
                this.tickerSpeed = this.speedControl;
                this.startTicker();
                this.customclass = 'grid-slide-inner';
                this.backgroundColor = 'background:'+this.background;
                }

                if(this.selectSlider === '2nd Slider'){
                    
                this.secondSlider();
                this.customclass = 'slider2css grid-slide-inner';
                
                //   console.log('background ' + this.background);
                  this.backgroundColor = 'background:'+this.background;
                }

            }).catch(e => {
                console.log('Error: ' + e);
            });
        }).catch(e => {
            console.log('Error: ' + e);
        });
    }

    initializeFlickity() {
        this.flickity = new Flickity(this.template.querySelector('.grid-slide-wrap'), {
            autoPlay: this.autoPlay,
             imagesLoaded: true,
            prevNextButtons: this.prevNextButtons,
            pageDots: this.pageDots,
            draggable: this.draggable,
            wrapAround: this.wrapAround,
            contain: this.contain,
            cellAlign: this.cellAlign,
            selectedAttraction: 0.015,
            friction: 0.25,
            rightToLeft: this.rightToLeft,
           
            
        });
        this.flickity.x = 0;
    }

    update() {
        if (this.isPaused) return;
        if (this.flickity.slides) {
            this.flickity.x = (this.flickity.x - this.tickerSpeed) % this.flickity.slideableWidth;
            this.flickity.selectedIndex = this.flickity.dragEndRestingSelect();
            this.flickity.updateSelectedSlide();
            this.flickity.settle(this.flickity.x);
        }
        window.requestAnimationFrame(this.update.bind(this));
    }

    pause() {
        this.isPaused = true;
    }

    play() {
        if (this.isPaused) {
            this.isPaused = false;
            window.requestAnimationFrame(this.update.bind(this));
        }
    }

    addEventListeners() {
        this.template.querySelector('.grid-slide-wrap').addEventListener('mouseenter', this.pause.bind(this), false);
        this.template.querySelector('.grid-slide-wrap').addEventListener('focusin', this.pause.bind(this), false);
        this.template.querySelector('.grid-slide-wrap').addEventListener('mouseleave', this.play.bind(this), false);
        this.template.querySelector('.grid-slide-wrap').addEventListener('focusout', this.play.bind(this), false);

        this.flickity.on('dragStart', () => {
            this.isPaused = false;
        });
    }

    startTicker() {
       
        this.update();
     
    }

    secondSlider(){

        Flickity.prototype.getSelectedCellIndexes = function () {
            return this.selectedCells.map(function (cell) {
                return this.cells.indexOf(cell);
            }, this);
        };

        const flickityElement = this.template.querySelector('.grid-slide-wrap');
        const flkty = new Flickity(flickityElement, {
            autoPlay: this.autoPlay,
            imagesLoaded: true,
            prevNextButtons: this.prevNextButtons,
            pageDots: this.pageDots,
            draggable: this.draggable,
            wrapAround: this.wrapAround,
            contain: this.contain,
            cellAlign: this.cellAlign,
            selectedAttraction: 0.2,
            friction: 0.8,
            rightToLeft: this.rightToLeft,
            
        });

        flkty.on('select', () => {
        });
    }
    

    
}