import { LightningElement, api, track } from 'lwc';

export default class AnimatedHeadlineComponent extends LightningElement {

  @api heading = '';
  @api subheading = '';
  @api headingclr;
  @api imageurl = '';
  @api headingfontfamily;
  @api subheadingfontfamily;
  @api subheadingcolor;
  @api redirectUrl;
  @api buttonText;
  @api buttonColor;
  @api buttonBorderColor;
  @api buttonTextColor;

  @track hasText = false;

  @api typewriterValues;
  @track typewriterIndex = 0;
  @track isTyping = true;

  @api highlightText = '';
  @api highlightColor = '';

  @api backgroundImg;
  @api backgroundColor;

  @api typewriterVariant;
  @api typewriterPeriod;

  // get backgroundImageStyle() {
  //   return `background-image: url(${this.backgroundImg});`;
  // }
  get backgroundImageStyle() {
    if (window.innerWidth > 768) {
      return `background-image: url(${this.backgroundImg});`;
    } else {
      return '';
    }
  }
  
  
  connectedCallback() {

    this.hasText = !!this.buttonText;

    if (this.typewriterValues && this.highlightText) {
      this.updateHighlightText();
      if (this.typewriterVariant === 'Type 1') {
        this.startTypewriterAnimation();
      } else if (this.typewriterVariant === 'Type 2') {
        this.startTypewriterAnimationVariant2();
      }
      else if (this.typewriterVariant === 'Type 3') {
        this.startTypewriterAnimationVariant3();
      }
      else if (this.typewriterVariant === 'Type 4') {
        this.startTypewriterAnimationVariant4();
      }
      // else if (this.typewriterVariant === 'Type 5') {
      //   this.startTypewriterAnimationVariant5();
      // }
    }
  }

  updateHighlightText() {
    const values = this.typewriterValues.split(',');
    const currentValue = values[this.typewriterIndex];
    this.heading = this.heading.replace(this.highlightText, currentValue);
    this.highlightText = currentValue;
  }

  startTypewriterAnimation() {
    const values = this.typewriterValues.split(',');
    const duration = this.typewriterPeriod;;
    const interval = duration / (values.length - 1);

    setInterval(() => {
      if (this.isTyping) {
        this.typewriterIndex = (this.typewriterIndex + 1) % values.length;
        this.updateHighlightText();
      }
    }, interval);
  }


  startTypewriterAnimationVariant2() {
    // Wait until the element is present in the DOM
    const waitForElement = setInterval(() => {
      const typeWriterElement = this.template.querySelector('.highlighted');
      if (typeWriterElement) {
        clearInterval(waitForElement); // Stop waiting once the element is found
  
        const values = this.typewriterValues.split(',').map(text => text.trim());
        let currentTextIndex = 0;
        let currentCharIndex = 0;
        let isDeleting = false;
  
        const type = () => {
          const currentText = values[currentTextIndex];
          const typewriterPeriod = this.typewriterPeriod || 2000; // Default to 2000 if typewriterPeriod is not provided
  
          if (isDeleting) {
            typeWriterElement.textContent = currentText.substring(0, currentCharIndex - 1);
            currentCharIndex--;
          } else {
            typeWriterElement.textContent = currentText.substring(0, currentCharIndex + 1);
            currentCharIndex++;
          }
  
          if (!isDeleting && currentCharIndex === currentText.length) {
            isDeleting = true;
            setTimeout(type, typewriterPeriod);
          } else if (isDeleting && currentCharIndex === 0) {
            isDeleting = false;
            currentTextIndex = (currentTextIndex + 1) % values.length;
            setTimeout(type, typewriterPeriod);
          } else {
            setTimeout(type, 100); // Default typing speed setTimeout(type, typewriterPeriod); 
          }
        };
  
        type();
      }
    }, 100); // Check every 100ms for the element
  }
  

  startTypewriterAnimationVariant3() {
    const waitForElement = setInterval(() => {
      const typeWriterElement = this.template.querySelector('.highlighted');
      if (typeWriterElement) {
        clearInterval(waitForElement);
  
        const values = this.typewriterValues.split(',').map(text => text.trim());
        let currentTextIndex = 0;
        let fadeIn = true;
  
        const fadeInOut = () => {
          const currentText = values[currentTextIndex];
          typeWriterElement.textContent = currentText;
          if (fadeIn) {
            fadeInEffect(typeWriterElement, () => {
              setTimeout(() => {
                fadeOutEffect(typeWriterElement, () => {
                  currentTextIndex = (currentTextIndex + 1) % values.length;
                  fadeInOut();
                });
              }, 1000); // Adjust timing between fade in and fade out
            });
          } else {
            fadeIn = true;
            fadeInOut();
          }
          fadeIn = !fadeIn;
        };
  
        const fadeInEffect = (element, callback) => {
          element.style.opacity = '0';
          let opacity = 0;
          const fadeInInterval = setInterval(() => {
            opacity += 0.1;
            element.style.opacity = opacity;
            if (opacity >= 1) {
              clearInterval(fadeInInterval);
              callback();
            }
          }, 200); // Adjust the fade-in speed
        };
  
        const fadeOutEffect = (element, callback) => {
          let opacity = 1;
          const fadeOutInterval = setInterval(() => {
            opacity -= 0.1;
            element.style.opacity = opacity;
            if (opacity <= 0) {
              clearInterval(fadeOutInterval);
              callback();
            }
          }, 200); // Adjust the fade-out speed
        };
  
        fadeInOut();
      }
    }, 100);
  }


  startTypewriterAnimationVariant4() {
    const waitForElement = setInterval(() => {
      const highlightedElement = this.template.querySelector('.highlighted');
      if (highlightedElement) {
        clearInterval(waitForElement);
  
        const texts = this.typewriterValues.split(',').map(text => text.trim());
  
        const morphTime = 1.5; // Increase the morphTime to 2 seconds (adjust as needed)
        const cooldownTime = 0.50;
  
        let textIndex = texts.length - 1;
        let time = new Date();
        let morph = 0;
        let cooldown = cooldownTime;
  
        function doMorph() {
          morph -= cooldown;
          cooldown = 0;
  
          let fraction = morph / morphTime;
  
          if (fraction > 1) {
            cooldown = cooldownTime;
            fraction = 1;
          }
  
          setMorph(fraction);
        }
  
        function setMorph(fraction) {
          highlightedElement.style.filter = `blur(${Math.min(8 / fraction - 8, 100)}px)`;
          highlightedElement.style.opacity = `${Math.pow(fraction, 0.4) * 100}%`;
          highlightedElement.textContent = texts[textIndex % texts.length];
        }
  
        function doCooldown() {
          morph = 0;
        }
  
        function animate() {
          requestAnimationFrame(animate);
  
          let newTime = new Date();
          let shouldIncrementIndex = cooldown > 0;
          let dt = (newTime - time) / 1000;
          time = newTime;
  
          cooldown -= dt;
  
          if (cooldown <= 0) {
            if (shouldIncrementIndex) {
              textIndex++;
            }
  
            doMorph();
          } else {
            doCooldown();
          }
        }
  
        animate();
      }
    }, 100);
  }
  
 

// startTypewriterAnimationVariant5() {
//   const highlightedElements = this.template.querySelectorAll('.highlighted');

//   const values = this.typewriterValues.split(',').map(text => text.trim());
//   let currentTextIndex = 0;

//   const fadeInOut = () => {
//     highlightedElements.forEach((element, index) => {
//       const currentText = values[(currentTextIndex + index) % values.length];
//       element.textContent = currentText;
//     });

//     currentTextIndex = (currentTextIndex + 1) % values.length;
//     setTimeout(fadeInOut, 2000); // Adjust the delay for fade effect (milliseconds)
//   };

//   fadeInOut(); // Start the animation loop
// }

  // 
  stopTypewriterAnimation() {
    this.isTyping = false;
  }

  replaceHighlightedText(newText) {
    this.isTyping = false;
    this.heading = this.heading.replace(this.highlightText, newText);
    this.highlightText = newText;
  }

  get anchorClass() {
    return this.hasText ? 'withText' : 'noText';
  }

  get headingParts() {
    if (!this.highlightText || !this.heading) {
      return [];
    }
    const parts = this.heading.split(new RegExp(`(${this.highlightText})`, 'gi'));
    return parts.map((part, index) => ({
      key: index,
      text: part,
      class: part.toLowerCase() === this.highlightText.toLowerCase() ? 'highlighted' : '',
      style: part.toLowerCase() === this.highlightText.toLowerCase() ? `color: ${this.highlightColor};` : ''
    }));
  }

  renderedCallback() {
    const divElement = this.template.querySelector('.Div');
    divElement.style.setProperty("--my-headingclr", this.headingclr);
    divElement.style.setProperty("--my-headingfontfamily", this.headingfontfamily);
    divElement.style.setProperty("--my-subheadingfontfamily", this.subheadingfontfamily);
    divElement.style.setProperty("--my-subheadingcolor", this.subheadingcolor);
    divElement.style.setProperty("--my-buttonColor", this.buttonColor);
    divElement.style.setProperty("--my-buttonTextColor", this.buttonTextColor);
    divElement.style.setProperty("--my-buttonBorderColor", this.buttonBorderColor);
    divElement.style.setProperty("--my-backgroundColor", this.backgroundColor);

    if (this.typewriterVariant === 'Type 2') {
      const css = document.createElement("style");
      css.type = "text/css";
      css.innerHTML = ".highlighted{ border-right: 0.08em solid #FC7318}";
      this.template.querySelector('div').appendChild(css);
    }
    

    // const isType5Selected = this.typewriterVariant === 'Type 5';

    // // Remove existing CSS for Type 5 animation if not selected
    // const existingStyle = document.querySelector("#type5AnimationStyle");
    // if (!isType5Selected && existingStyle) {
    //   existingStyle.remove();
    // }
  
    // Inject CSS animation dynamically only if Type 5 is selected
    // if (isType5Selected) {
    //   const style = document.createElement("style");
    //   style.id = "type5AnimationStyle";
    //   style.textContent = `
    //     .highlighted {
    //       display: -webkit-inline-box;
    //       animation: flip 2s infinite;
    //       animation-delay: calc(.2s * var(--i));
    //     }
  
    //     @keyframes flip {
    //       0%, 80% {
    //         transform: rotateY(360deg);
    //       }
    //     }
    //   `;
    //   document.head.appendChild(style);
  
    //   // Call startTypewriterAnimationVariant5() after CSS injection
    //   this.startTypewriterAnimationVariant5();
    // }
  }
}
