import { LightningElement } from 'lwc';

export default class Homepage1 extends LightningElement {}