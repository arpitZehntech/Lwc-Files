({
	DoInit : function(component, event, helper) {
        var data = {'name':'arpit',
                    'email':'arpit@gmail.com'}
        
        component.set("v.jsObject",data)
		component.set("v.vr1", "this value from controller components")
        component.set("v.vr2", "['v5','v6','v7']")
        
        component.set("v.userData",
                      {
                          'myString1':'this is string',
                          'myInteger1': 2024
                      })
	}
})