({
	UpdateParent : function(component, event, helper) {
		component.set("v.parentVar","updated parent value");
	},
    onParentVarChange : function(component, event, helper) {
        
		console.log("parent value has change");
    	console.log("old value"+ event.getParam("old value"));
   		console.log("new value"+ event.getParam("value"));
        
	}
})