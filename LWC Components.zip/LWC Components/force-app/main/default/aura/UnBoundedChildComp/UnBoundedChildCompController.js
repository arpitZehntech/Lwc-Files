({
	updateChildVar : function(component, event, helper) {
        component.set("v.childVar","update child var");
		
	}
})