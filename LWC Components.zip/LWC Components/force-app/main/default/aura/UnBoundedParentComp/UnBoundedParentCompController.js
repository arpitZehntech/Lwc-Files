({
	updateParentVar : function(component, event, helper) {
		
        component.set("v.parentVar", "updated parent attribute");
	}
})